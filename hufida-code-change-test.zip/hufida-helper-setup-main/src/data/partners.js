export const partners = [
  {
    name: "Green Earth Initiative",
    logo: "https://images.unsplash.com/photo-1497644083578-611b798c60f3",
    partnerType: "Environmental",
    website: "https://www.greenearthinitiative.org",
    description: "A global organization dedicated to environmental conservation and sustainable development.",
    location: "Nairobi, Kenya"
  },
  {
    name: "Tech for Africa",
    logo: "https://images.unsplash.com/photo-1519389950473-47ba0277781c",
    partnerType: "Technology",
    website: "https://www.techforafrica.com",
    description: "Empowering African communities through innovative technological solutions.",
    location: "Lagos, Nigeria"
  },
  {
    name: "Global Health Alliance",
    logo: "https://images.unsplash.com/photo-1576091160550-2173dba999ef",
    partnerType: "Healthcare",
    website: "https://www.globalhealthalliance.org",
    description: "Working to improve healthcare access and outcomes across Africa.",
    location: "Accra, Ghana"
  },
  {
    name: "Education for All",
    logo: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b",
    partnerType: "Education",
    website: "https://www.educationforall.org",
    description: "Promoting equal access to quality education throughout African nations.",
    location: "Cape Town, South Africa"
  },
  {
    name: "African Development Bank",
    logo: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab",
    partnerType: "Financial",
    website: "https://www.afdb.org",
    description: "Supporting economic development and social progress in African countries.",
    location: "Abidjan, Ivory Coast"
  },
  {
    name: "REWAC",
    logo: "https://images.unsplash.com/photo-1532996122724-e3c354a0b15b",
    partnerType: "Environmental",
    website: "https://rewac.org/",
    description: "Promoting sustainable waste management and environmental conservation in Africa.",
    location: "Kigali, Rwanda"
  },
  {
    name: "World Green Building Council",
    logo: "https://images.unsplash.com/photo-1449157291145-7efd050a4d0e",
    partnerType: "Sustainability",
    website: "https://worldgbc.org/wgbw24-events-map/",
    description: "Advancing sustainable building practices and green infrastructure globally.",
    location: "Johannesburg, South Africa"
  },
  {
    name: "TechConcept Lab",
    logo: "https://images.unsplash.com/photo-1487058792275-0ad4aaf24ca7",
    partnerType: "Technology",
    website: "https://techconceptlab.com/",
    description: "Providing innovative technological solutions and digital transformation services.",
    location: "Dar es Salaam, Tanzania"
  },
  {
    name: "British Council Library Bamenda",
    logo: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570",
    partnerType: "Education",
    website: "https://library.britishcouncil.org/",
    description: "Providing educational resources and cultural exchange opportunities in Bamenda, Cameroon.",
    location: "Bamenda, Cameroon"
  }
];