import React from 'react';
import { motion } from "framer-motion";
import { Search } from 'lucide-react';
import { Input } from "@/components/ui/input";

const PartnerSearch = ({ searchTerm, onSearchChange }) => {
  return (
    <motion.div 
      className="relative w-full max-w-md mx-auto mb-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-deepGreen-300" size={20} />
      <Input
        type="text"
        placeholder="Search partners..."
        value={searchTerm}
        onChange={(e) => onSearchChange(e.target.value)}
        className="pl-10 bg-deepGreen-800/50 border-deepGreen-700 text-deepGreen-100 placeholder:text-deepGreen-400"
      />
    </motion.div>
  );
};

export default PartnerSearch;