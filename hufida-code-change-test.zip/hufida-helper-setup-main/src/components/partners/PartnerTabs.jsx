import React from 'react';
import { motion } from "framer-motion";
import { TabsList, TabsTrigger } from "@/components/ui/tabs";

const PartnerTabs = ({ types, selectedType, onTypeChange }) => {
  console.log('Rendering PartnerTabs with types:', types);
  
  return (
    <TabsList 
      className="w-full flex flex-wrap justify-center gap-3 bg-deepGreen-800/50 p-6 rounded-xl backdrop-blur-lg border border-deepGreen-700/50"
    >
      {types.map((type) => (
        <TabsTrigger
          key={type}
          value={type}
          onClick={() => {
            console.log('Tab clicked:', type);
            onTypeChange(type);
          }}
          className={`
            px-6 py-2.5 rounded-lg text-base font-medium
            data-[state=active]:bg-deepGreen-600 
            data-[state=active]:text-white 
            data-[state=active]:shadow-lg
            transition-all duration-300 
            hover:bg-deepGreen-700/70
            backdrop-blur-sm
          `}
        >
          <motion.span
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            {type.charAt(0).toUpperCase() + type.slice(1)}
          </motion.span>
        </TabsTrigger>
      ))}
    </TabsList>
  );
};

export default PartnerTabs;