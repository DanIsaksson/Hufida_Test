import React from 'react';
import { motion } from "framer-motion";
import { Skeleton } from "@/components/ui/skeleton";

const PartnerLoadingSkeleton = () => (
  <motion.div 
    className="space-y-3"
    initial={{ opacity: 0.5 }}
    animate={{ 
      opacity: [0.3, 0.7],
      scale: [0.98, 1.02],
    }}
    transition={{ 
      duration: 1.5,
      repeat: Infinity,
      repeatType: "reverse",
    }}
  >
    <div className="relative">
      <Skeleton className="h-24 w-24 rounded-lg mx-auto bg-deepGreen-600/30" />
      <motion.div
        className="absolute inset-0 bg-gradient-to-r from-transparent via-deepGreen-400/10 to-transparent"
        animate={{
          x: ['-100%', '100%'],
        }}
        transition={{
          duration: 1.5,
          repeat: Infinity,
          ease: "linear",
        }}
      />
    </div>
    <Skeleton className="h-6 w-3/4 mx-auto bg-deepGreen-600/30" />
    <Skeleton className="h-4 w-1/2 mx-auto bg-deepGreen-600/30" />
    <div className="flex justify-center space-x-2">
      <Skeleton className="h-4 w-4 rounded-full bg-deepGreen-600/30" />
      <Skeleton className="h-4 w-20 bg-deepGreen-600/30" />
    </div>
  </motion.div>
);

export default PartnerLoadingSkeleton;