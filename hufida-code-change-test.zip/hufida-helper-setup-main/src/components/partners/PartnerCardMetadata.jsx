/**
 * @component PartnerCardMetadata
 * @description Renders metadata information about a partner organization,
 * including location and partnership type with interactive hover effects.
 * 
 * @example
 * ```jsx
 * <PartnerCardMetadata
 *   partner={{
 *     location: "City, Country",
 *     partnerType: "Technology"
 *   }}
 * />
 * ```
 * 
 * @param {Object} props
 * @param {Object} props.partner - Partner information object
 * @param {string} props.partner.location - Organization location
 * @param {string} props.partner.partnerType - Type of partnership
 */
import React from 'react';
import { motion } from "framer-motion";
import { MapPin, Building2 } from 'lucide-react';

const PartnerCardMetadata = ({ partner }) => {
  return (
    <div className="space-y-2 mt-4">
      {partner.location && (
        <motion.div 
          className="flex items-center gap-2 text-sm text-deepGreen-200 p-2 rounded-lg hover:bg-deepGreen-700/50 transition-colors w-fit"
          whileHover={{ x: 5 }}
        >
          <MapPin size={16} className="flex-shrink-0" />
          <span>{partner.location}</span>
        </motion.div>
      )}
      <motion.div 
        className="flex items-center gap-2 text-sm text-deepGreen-200 p-2 rounded-lg hover:bg-deepGreen-700/50 transition-colors w-fit"
        whileHover={{ x: 5 }}
      >
        <Building2 size={16} className="flex-shrink-0" />
        <span>{partner.partnerType} Partner</span>
      </motion.div>
    </div>
  );
};

export default PartnerCardMetadata;