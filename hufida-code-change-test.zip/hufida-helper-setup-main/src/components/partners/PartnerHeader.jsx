import React from 'react';
import { motion } from "framer-motion";
import { Building2, Globe, MapPin } from 'lucide-react';

const PartnerHeader = () => (
  <motion.div 
    className="text-center mb-16 space-y-6"
    initial={{ opacity: 0, y: -20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5 }}
  >
    <h1 className="text-5xl font-bold mb-6 text-white tracking-tight">Our Partners</h1>
    <p className="text-xl text-deepGreen-100 max-w-3xl mx-auto leading-relaxed">
      HUFIDA collaborates with various organizations to maximize our impact and reach. Together, we're driving innovation and sustainable development across Africa.
    </p>
    <div className="flex flex-wrap justify-center gap-6 mt-8">
      <motion.div 
        whileHover={{ scale: 1.05 }}
        className="flex items-center gap-3 text-deepGreen-100 bg-deepGreen-800/50 px-6 py-3 rounded-xl backdrop-blur-lg border border-deepGreen-700/50"
      >
        <Globe className="h-5 w-5" />
        <span>Global Impact</span>
      </motion.div>
      <motion.div 
        whileHover={{ scale: 1.05 }}
        className="flex items-center gap-3 text-deepGreen-100 bg-deepGreen-800/50 px-6 py-3 rounded-xl backdrop-blur-lg border border-deepGreen-700/50"
      >
        <Building2 className="h-5 w-5" />
        <span>Trusted Partners</span>
      </motion.div>
      <motion.div 
        whileHover={{ scale: 1.05 }}
        className="flex items-center gap-3 text-deepGreen-100 bg-deepGreen-800/50 px-6 py-3 rounded-xl backdrop-blur-lg border border-deepGreen-700/50"
      >
        <MapPin className="h-5 w-5" />
        <span>Local Presence</span>
      </motion.div>
    </div>
  </motion.div>
);

export default PartnerHeader;