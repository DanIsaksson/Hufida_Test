import React, { Suspense } from 'react';
import { motion } from "framer-motion";
import { responsiveGridStyles } from '../../utils/styleUtils';
import PartnerLoadingSkeleton from './PartnerLoadingSkeleton';
import PartnerCard from '../PartnerCard';

const PartnerGrid = ({ partners }) => {
  if (!partners?.length) {
    return (
      <div className="text-center text-deepGreen-100 py-12">
        No partners found.
      </div>
    );
  }

  return (
    <motion.div
      initial="hidden"
      animate="visible"
      variants={{
        visible: {
          transition: {
            staggerChildren: 0.1,
          },
        },
      }}
      className={`${responsiveGridStyles({ cols: 3 })} gap-8`}
    >
      {partners.map((partner) => (
        <Suspense key={partner.id} fallback={<PartnerLoadingSkeleton />}>
          <PartnerCard partner={partner} />
        </Suspense>
      ))}
    </motion.div>
  );
};

export default PartnerGrid;