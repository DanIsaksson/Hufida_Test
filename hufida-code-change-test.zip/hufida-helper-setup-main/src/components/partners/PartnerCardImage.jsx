/**
 * @component PartnerCardImage
 * @description Handles the display and loading states of partner organization logos
 * with fallback placeholder and loading animations.
 * 
 * @example
 * ```jsx
 * const [imageLoaded, setImageLoaded] = useState(false);
 * const [imageError, setImageError] = useState(false);
 * 
 * <PartnerCardImage
 *   partner={{ name: "Example Corp", logo: "/logo.png" }}
 *   imageLoaded={imageLoaded}
 *   setImageLoaded={setImageLoaded}
 *   imageError={imageError}
 *   setImageError={setImageError}
 * />
 * ```
 * 
 * @param {Object} props
 * @param {Object} props.partner - Partner object containing logo URL and name
 * @param {boolean} props.imageLoaded - State indicating if image has loaded
 * @param {Function} props.setImageLoaded - Function to update image loaded state
 * @param {boolean} props.imageError - State indicating if image failed to load
 * @param {Function} props.setImageError - Function to update image error state
 */
import React from 'react';
import { motion, AnimatePresence } from "framer-motion";
import { LazyLoadImage } from 'react-lazy-load-image-component';
import 'react-lazy-load-image-component/src/effects/blur.css';

const PartnerCardImage = ({ partner, imageLoaded, setImageLoaded, imageError, setImageError }) => {
  const placeholderImage = "/placeholder.svg";

  const handleImageLoad = () => {
    console.log(`Image loaded for ${partner.name}`);
    setImageLoaded(true);
  };

  const handleImageError = (e) => {
    console.log(`Image error for ${partner.name}, using placeholder`);
    e.target.onerror = null;
    e.target.src = placeholderImage;
    setImageError(true);
  };

  return (
    <AnimatePresence mode="wait">
      <motion.div 
        key={imageLoaded ? 'loaded' : 'loading'}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.3 }}
        className="relative w-28 h-28 overflow-hidden rounded-xl bg-white/10"
      >
        <LazyLoadImage
          src={partner.logo}
          alt={`${partner.name} logo`}
          effect="blur"
          className={`
            w-full h-full object-cover transition-all duration-500
            ${imageLoaded ? 'group-hover:scale-110' : ''}
            ${imageError ? 'object-contain p-2' : 'object-cover'}
          `}
          placeholderSrc={placeholderImage}
          beforeLoad={() => console.log(`Loading image for ${partner.name}`)}
          afterLoad={handleImageLoad}
          onError={handleImageError}
        />
        {!imageLoaded && !imageError && (
          <motion.div
            className="absolute inset-0 flex items-center justify-center bg-deepGreen-800/50"
            animate={{ 
              opacity: [0.5, 1],
              scale: [0.98, 1.02],
            }}
            transition={{ 
              duration: 1.5,
              repeat: Infinity,
              repeatType: "reverse",
            }}
          >
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-transparent via-deepGreen-400/20 to-transparent"
              animate={{
                x: ['-100%', '100%'],
              }}
              transition={{
                duration: 1.5,
                repeat: Infinity,
                ease: "linear",
              }}
            />
            <span className="text-deepGreen-100 relative z-10">Loading...</span>
          </motion.div>
        )}
      </motion.div>
    </AnimatePresence>
  );
};

export default PartnerCardImage;