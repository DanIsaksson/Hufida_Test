/**
 * @component PartnerCardHeader
 * @description Renders the header section of a partner card, including the logo,
 * partner type badge, and organization name with website link.
 * 
 * @example
 * ```jsx
 * const [imageLoaded, setImageLoaded] = useState(false);
 * const [imageError, setImageError] = useState(false);
 * 
 * <PartnerCardHeader
 *   partner={{
 *     name: "Example Corp",
 *     logo: "/logo.png",
 *     partnerType: "Technology",
 *     website: "https://example.com"
 *   }}
 *   imageLoaded={imageLoaded}
 *   setImageLoaded={setImageLoaded}
 *   imageError={imageError}
 *   setImageError={setImageError}
 * />
 * ```
 * 
 * @param {Object} props
 * @param {Object} props.partner - Partner information object
 * @param {boolean} props.imageLoaded - Image loading state
 * @param {Function} props.setImageLoaded - Image loaded state setter
 * @param {boolean} props.imageError - Image error state
 * @param {Function} props.setImageError - Image error state setter
 */
import React from 'react';
import { motion } from "framer-motion";
import { ExternalLink } from 'lucide-react';
import { CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import PartnerCardImage from './PartnerCardImage';

const PartnerCardHeader = ({ partner, imageLoaded, setImageLoaded, imageError, setImageError }) => {
  return (
    <CardHeader className="pb-2 relative">
      <div className="flex items-start justify-between mb-4">
        <PartnerCardImage 
          partner={partner}
          imageLoaded={imageLoaded}
          setImageLoaded={setImageLoaded}
          imageError={imageError}
          setImageError={setImageError}
        />
        <Badge 
          variant="outline" 
          className="bg-deepGreen-700/50 text-deepGreen-100 border-deepGreen-600 backdrop-blur-sm px-4 py-1.5 rounded-lg"
        >
          {partner.partnerType}
        </Badge>
      </div>
      <CardTitle className="text-2xl font-bold text-deepGreen-50 flex items-center justify-between group">
        <span className="truncate mr-2">{partner.name}</span>
        <Tooltip>
          <TooltipTrigger asChild>
            <motion.a 
              href={partner.website} 
              target="_blank" 
              rel="noopener noreferrer" 
              className="text-deepGreen-300 hover:text-deepGreen-100 transition-colors p-2 rounded-lg hover:bg-deepGreen-700/50"
              aria-label={`Visit ${partner.name}'s website`}
              whileHover={{ scale: 1.1 }}
            >
              <ExternalLink size={20} />
            </motion.a>
          </TooltipTrigger>
          <TooltipContent>
            <p>Visit website</p>
          </TooltipContent>
        </Tooltip>
      </CardTitle>
    </CardHeader>
  );
};

export default PartnerCardHeader;