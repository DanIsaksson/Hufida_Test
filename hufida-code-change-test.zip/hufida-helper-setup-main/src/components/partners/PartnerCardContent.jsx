/**
 * @component PartnerCardContent
 * @description Displays the main content of a partner card, including the
 * organization's description, metadata, and social media links.
 */
import React from 'react';
import { motion } from "framer-motion";
import { CardContent } from "@/components/ui/card";
import { Linkedin, Twitter, Facebook, Instagram, ExternalLink } from 'lucide-react';
import PartnerCardMetadata from './PartnerCardMetadata';
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

const SocialIcon = ({ type, url, children }) => {
  if (!url) return null;
  
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <motion.a
          href={`https://${type}.com/${url}`}
          target="_blank"
          rel="noopener noreferrer"
          className="text-deepGreen-300 hover:text-deepGreen-100 transition-colors"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
        >
          {children}
        </motion.a>
      </TooltipTrigger>
      <TooltipContent>
        <p>Visit {type} profile</p>
      </TooltipContent>
    </Tooltip>
  );
};

const PartnerCardContent = ({ partner }) => {
  const socialMedia = partner.social_media || {};
  
  return (
    <CardContent className="flex-grow pt-2 space-y-4">
      <p className="text-base text-deepGreen-100/90 line-clamp-3 hover:line-clamp-none transition-all duration-300">
        {partner.description}
      </p>
      
      <div className="flex items-center gap-4 mt-4">
        <SocialIcon type="linkedin" url={socialMedia.linkedin}>
          <Linkedin size={20} />
        </SocialIcon>
        <SocialIcon type="twitter" url={socialMedia.twitter}>
          <Twitter size={20} />
        </SocialIcon>
        <SocialIcon type="facebook" url={socialMedia.facebook}>
          <Facebook size={20} />
        </SocialIcon>
        <SocialIcon type="instagram" url={socialMedia.instagram}>
          <Instagram size={20} />
        </SocialIcon>
      </div>

      <PartnerCardMetadata partner={partner} />
      
      {partner.contact_email && (
        <motion.div 
          className="mt-4 text-sm text-deepGreen-200"
          whileHover={{ x: 5 }}
        >
          <a 
            href={`mailto:${partner.contact_email}`}
            className="flex items-center gap-2 hover:text-deepGreen-100"
          >
            <ExternalLink size={16} />
            {partner.contact_email}
          </a>
        </motion.div>
      )}
    </CardContent>
  );
};

export default PartnerCardContent;