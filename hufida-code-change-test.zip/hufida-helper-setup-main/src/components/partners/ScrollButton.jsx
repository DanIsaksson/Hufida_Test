import React from 'react';
import { motion } from "framer-motion";
import { ArrowDown } from 'lucide-react';
import { toast } from "sonner";

const ScrollButton = () => {
  const scrollToProfiles = () => {
    const element = document.getElementById('partner-profiles');
    if (element) {
      element.scrollIntoView({ 
        behavior: 'smooth' 
      });
    } else {
      toast.error("Could not find profiles section");
    }
  };

  return (
    <motion.button
      onClick={scrollToProfiles}
      className="flex items-center gap-2 mx-auto px-6 py-3 text-white bg-deepGreen-700/50 rounded-full hover:bg-deepGreen-700 transition-colors"
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
    >
      View Partner Profiles
      <ArrowDown className="h-5 w-5 animate-bounce" />
    </motion.button>
  );
};

export default ScrollButton;