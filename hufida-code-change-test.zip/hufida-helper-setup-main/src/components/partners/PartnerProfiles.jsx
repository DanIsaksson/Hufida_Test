import React, { Suspense } from 'react';
import { motion } from 'framer-motion';
import { responsiveGridStyles } from '../../utils/styleUtils';
import PartnerCard from '../PartnerCard';
import PartnerLoadingSkeleton from './PartnerLoadingSkeleton';

const PartnerProfiles = ({ partners }) => {
  return (
    <div className="py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-deepGreen-600 to-deepGreen-900">
      <div className="max-w-7xl mx-auto">
        <motion.h2 
          className="text-4xl font-bold text-center text-white mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
        >
          Partner Profiles
        </motion.h2>
        <motion.div 
          className={`${responsiveGridStyles({ cols: 3 })} gap-8`}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          viewport={{ once: true }}
        >
          {partners.map((partner) => (
            <Suspense key={partner.id} fallback={<PartnerLoadingSkeleton />}>
              <PartnerCard partner={partner} />
            </Suspense>
          ))}
        </motion.div>
      </div>
    </div>
  );
};

export default PartnerProfiles;