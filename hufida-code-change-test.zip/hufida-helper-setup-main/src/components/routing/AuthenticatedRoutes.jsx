import React from 'react';
import { Route, Navigate } from 'react-router-dom';
import { createProtectedRoutes } from '@/routes/protectedRoutes';

const AuthenticatedRoutes = ({ hasRequiredRole }) => {
  console.log('Rendering AuthenticatedRoutes');
  const protectedRoutes = createProtectedRoutes(hasRequiredRole);

  return (
    <>
      {protectedRoutes.map((route) => (
        <Route 
          key={route.path} 
          path={route.path} 
          element={
            route.requiresAuth ? (
              hasRequiredRole(route.role) ? (
                route.element
              ) : (
                <Navigate to="/profile" replace />
              )
            ) : (
              route.element
            )
          } 
        />
      ))}
    </>
  );
};

export default AuthenticatedRoutes;