import React, { createContext, useContext } from 'react';
import { useAuthState } from '../hooks/useAuthState';
import { useProfileManagement } from '../hooks/useProfileManagement';
import { useAuthSetup } from '../hooks/useAuthSetup';

const AuthContext = createContext({});

export const useAuth = () => {
  return useContext(AuthContext);
};

export const AuthProvider = ({ children }) => {
  const { user, loading, setLoading, updateUser } = useAuthState();
  const { createProfileIfNeeded } = useProfileManagement();
  
  useAuthSetup(createProfileIfNeeded, updateUser);

  const value = {
    user,
    loading,
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
};

export default AuthProvider;