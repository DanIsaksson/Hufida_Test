import React from 'react';
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { neuCardStyles } from '../utils/styleUtils';
import { ChartBar, Users, Rocket, Globe, Leaf, Droplet, Zap, Recycle } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

const ImpactStats = ({ impacts }) => {
  console.log('Rendering ImpactStats with impacts:', impacts);

  const getIcon = (category) => {
    switch (category?.toLowerCase()) {
      case 'environmental':
        return Leaf;
      case 'social':
        return Users;
      case 'reach':
        return Globe;
      case 'water':
        return Droplet;
      case 'energy':
        return Zap;
      case 'waste':
        return Recycle;
      case 'progress':
        return Rocket;
      default:
        return ChartBar;
    }
  };

  const getCategoryColor = (category) => {
    switch (category?.toLowerCase()) {
      case 'environmental':
        return 'from-green-600 to-green-400';
      case 'social':
        return 'from-blue-600 to-blue-400';
      case 'reach':
        return 'from-purple-600 to-purple-400';
      case 'water':
        return 'from-cyan-600 to-cyan-400';
      case 'energy':
        return 'from-yellow-600 to-yellow-400';
      case 'waste':
        return 'from-orange-600 to-orange-400';
      case 'progress':
        return 'from-indigo-600 to-indigo-400';
      default:
        return 'from-deepGreen-600 to-deepGreen-400';
    }
  };

  if (!impacts || impacts.length === 0) {
    return null;
  }

  return (
    <TooltipProvider>
      <div className="space-y-6">
        <motion.h2 
          className="text-3xl font-bold text-center text-deepGreen-800"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          Project Impact
        </motion.h2>
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          {impacts.map((impact, index) => {
            const Icon = getIcon(impact.category);
            const progress = impact.target_value ? (impact.current_value / impact.target_value) * 100 : 0;
            const gradientColors = getCategoryColor(impact.category);
            
            return (
              <Tooltip key={impact.id}>
                <TooltipTrigger asChild>
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    whileHover={{ scale: 1.02 }}
                    className="h-full"
                  >
                    <Card className={`${neuCardStyles({ elevation: "medium" })} bg-gradient-to-br ${gradientColors} h-full transform transition-all duration-300 hover:shadow-xl`}>
                      <CardContent className="flex flex-col items-center justify-center p-6 text-center h-full">
                        <div className="rounded-full bg-white/20 p-3 mb-4">
                          <Icon className="h-8 w-8 text-white" />
                        </div>
                        <span className="text-3xl font-bold mb-2 text-white">
                          {impact.current_value.toLocaleString()}
                          <span className="text-sm ml-1 text-white/80">{impact.unit}</span>
                        </span>
                        <span className="text-sm mb-4 text-white/90 font-medium">{impact.metric_name}</span>
                        {impact.target_value && (
                          <div className="w-full mt-2">
                            <div className="h-2 bg-white/30 rounded-full overflow-hidden">
                              <motion.div 
                                className="h-full bg-white"
                                initial={{ width: 0 }}
                                animate={{ width: `${progress}%` }}
                                transition={{ duration: 1, delay: 0.5 }}
                              />
                            </div>
                            <div className="text-xs mt-2 text-white/80">
                              Target: {impact.target_value.toLocaleString()} {impact.unit}
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </motion.div>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Current progress: {Math.round(progress)}% of target</p>
                </TooltipContent>
              </Tooltip>
            );
          })}
        </motion.div>
      </div>
    </TooltipProvider>
  );
};

export default ImpactStats;