import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { supabase } from '@/lib/supabase';
import { AlertCircle } from 'lucide-react';
import { Alert, AlertDescription } from "@/components/ui/alert";

const ProjectSelection = ({ selectedProject, setSelectedProject }) => {
  const { data: projects, isLoading, error } = useQuery({
    queryKey: ['active-projects'],
    queryFn: async () => {
      console.log('Fetching active projects for donation selection');
      const { data, error } = await supabase
        .from('projects')
        .select(`
          id,
          title,
          description,
          funding_status,
          budget
        `)
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching projects:', error);
        throw error;
      }

      console.log('Fetched projects:', data);
      return data;
    }
  });

  if (isLoading) {
    return (
      <div className="mb-12">
        <h2 className="text-2xl font-semibold mb-4 text-center">Choose a Project to Support</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="cursor-pointer hover:shadow-lg transition-shadow">
              <CardHeader>
                <Skeleton className="h-6 w-3/4" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-20 w-full mb-4" />
                <Skeleton className="h-10 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <Alert variant="destructive" className="mb-12">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          Failed to load projects. Please try again later.
        </AlertDescription>
      </Alert>
    );
  }

  if (!projects?.length) {
    return (
      <Alert className="mb-12">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          No active projects found at the moment.
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="mb-12">
      <h2 className="text-2xl font-semibold mb-4 text-center text-white">Choose a Project to Support</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {projects.map((project) => (
          <Card 
            key={project.id} 
            className={`
              cursor-pointer hover:shadow-lg transition-shadow
              ${selectedProject === project.id ? 'border-2 border-deepGreen-500' : ''}
            `}
          >
            <CardHeader>
              <CardTitle>{project.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">{project.description}</p>
              {project.budget && (
                <p className="text-sm text-deepGreen-600 mb-4">
                  Budget: ${project.budget.toLocaleString()}
                </p>
              )}
              <Button 
                className="w-full"
                variant={selectedProject === project.id ? "default" : "outline"}
                onClick={() => setSelectedProject(project.id)}
              >
                {selectedProject === project.id ? "Selected" : "Select"}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default ProjectSelection;