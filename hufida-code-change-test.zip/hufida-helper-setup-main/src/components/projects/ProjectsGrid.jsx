import React from 'react';
import { motion } from "framer-motion";
import ProjectCard from '../ProjectCard';
import { responsiveGridStyles } from '../../utils/styleUtils';

const ProjectsGrid = ({ projects, onSuggestDirection }) => {
  if (projects.length === 0) {
    return (
      <motion.p
        className="text-center text-xl text-deepGreen-100 mt-12"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        No projects found. Try adjusting your search or filter.
      </motion.p>
    );
  }

  return (
    <motion.div 
      className={`${responsiveGridStyles({ cols: 3 })} gap-8 mb-16`}
      initial="hidden"
      animate="visible"
      variants={{
        visible: {
          transition: {
            staggerChildren: 0.1,
          },
        },
      }}
    >
      {projects.map((project) => (
        <ProjectCard
          key={project.id}
          project={project}
          onSuggestDirection={onSuggestDirection}
        />
      ))}
    </motion.div>
  );
};

export default ProjectsGrid;