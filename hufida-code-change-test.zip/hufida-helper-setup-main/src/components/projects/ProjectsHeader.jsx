import React from 'react';
import { motion } from "framer-motion";

const ProjectsHeader = () => {
  return (
    <>
      <motion.h1 
        className="text-5xl font-bold mb-2 text-center text-white"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        Our Projects
      </motion.h1>
      <motion.p 
        className="mb-8 text-xl text-center text-deepGreen-100 max-w-3xl mx-auto"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        Explore our ongoing projects and initiatives that align with HUFIDA's objectives and methods. You can suggest new directions for our projects!
      </motion.p>
    </>
  );
};

export default ProjectsHeader;