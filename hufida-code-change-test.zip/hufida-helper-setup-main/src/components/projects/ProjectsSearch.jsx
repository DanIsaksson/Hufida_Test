import React from 'react';
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { motion } from "framer-motion";
import { neuInputStyles, neuCardStyles } from '../../utils/styleUtils';

const ProjectsSearch = ({ searchTerm, setSearchTerm, categoryFilter, setCategoryFilter }) => {
  return (
    <motion.div 
      className="flex flex-col sm:flex-row gap-4 mb-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.4 }}
    >
      <Input
        type="text"
        placeholder="Search projects..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className={`${neuInputStyles({ state: "default" })} flex-grow text-deepGreen-800`}
      />
      <Select value={categoryFilter} onValueChange={setCategoryFilter}>
        <SelectTrigger className={`${neuCardStyles({ elevation: "low" })} w-full sm:w-[180px] bg-deepGreen-100 text-deepGreen-800`}>
          <SelectValue placeholder="Filter by category" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="All">All Categories</SelectItem>
          <SelectItem value="Technology">Technology</SelectItem>
          <SelectItem value="Environment">Environment</SelectItem>
          <SelectItem value="Research">Research</SelectItem>
          <SelectItem value="Education">Education</SelectItem>
          <SelectItem value="Health">Health</SelectItem>
          <SelectItem value="Energy">Energy</SelectItem>
        </SelectContent>
      </Select>
    </motion.div>
  );
};

export default ProjectsSearch;