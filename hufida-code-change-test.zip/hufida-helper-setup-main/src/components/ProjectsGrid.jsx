import React from 'react';
import { motion } from "framer-motion";
import ProjectCard from '../ProjectCard';
import { responsiveGridStyles } from '../../utils/styleUtils';

const ProjectsGrid = ({ projects, onSuggestDirection }) => {
  if (projects.length === 0) {
    return (
      <motion.p
        className="text-center text-xl text-deepGreen-100 mt-12"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        No projects found. Try adjusting your search or filter.
      </motion.p>
    );
  }

  return (
    <motion.div 
      className={`${responsiveGridStyles({ cols: 3 })} gap-8 mb-16`}
      initial="hidden"
      animate="visible"
      variants={{
        visible: {
          transition: {
            staggerChildren: 0.1,
          },
        },
      }}
    >
      {projects.map((project, index) => (
        <motion.div
          key={project.id}
          variants={{
            hidden: { opacity: 0, y: 20 },
            visible: { 
              opacity: 1, 
              y: 0,
              transition: {
                type: "spring",
                damping: 12,
                stiffness: 100
              }
            }
          }}
        >
          <ProjectCard
            project={project}
            onSuggestDirection={onSuggestDirection}
          />
        </motion.div>
      ))}
    </motion.div>
  );
};

export default ProjectsGrid;