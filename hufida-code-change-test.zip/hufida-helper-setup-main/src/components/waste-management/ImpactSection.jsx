import React from 'react';
import { AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const ImpactSection = ({ impact }) => {
  return (
    <AccordionItem value="impact">
      <AccordionTrigger>Impact</AccordionTrigger>
      <AccordionContent>
        <p>{impact}</p>
      </AccordionContent>
    </AccordionItem>
  );
};

export default ImpactSection;