import React from 'react';
import { AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const ObjectivesSection = ({ objectives }) => {
  return (
    <AccordionItem value="objectives">
      <AccordionTrigger>Objectives</AccordionTrigger>
      <AccordionContent>
        <ul className="list-disc pl-5 space-y-2">
          {objectives.map((objective, index) => (
            <li key={index}>{objective}</li>
          ))}
        </ul>
      </AccordionContent>
    </AccordionItem>
  );
};

export default ObjectivesSection;