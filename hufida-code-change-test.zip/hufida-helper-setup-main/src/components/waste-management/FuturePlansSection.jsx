import React from 'react';
import { AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const FuturePlansSection = ({ future }) => {
  return (
    <AccordionItem value="future">
      <AccordionTrigger>Future Plans</AccordionTrigger>
      <AccordionContent>
        <p>{future}</p>
      </AccordionContent>
    </AccordionItem>
  );
};

export default FuturePlansSection;