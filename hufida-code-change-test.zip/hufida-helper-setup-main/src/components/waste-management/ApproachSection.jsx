import React from 'react';
import { AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const ApproachSection = ({ approach }) => {
  return (
    <AccordionItem value="approach">
      <AccordionTrigger>Approach</AccordionTrigger>
      <AccordionContent>
        <p>{approach}</p>
      </AccordionContent>
    </AccordionItem>
  );
};

export default ApproachSection;