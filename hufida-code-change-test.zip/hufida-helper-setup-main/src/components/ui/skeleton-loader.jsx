import { cn } from "@/lib/utils";

export function SkeletonLoader({ className, ...props }) {
  return (
    <div
      className={cn(
        "animate-pulse rounded-md bg-muted/50",
        className
      )}
      {...props}
    />
  );
}

export function CardSkeleton() {
  return (
    <div className="space-y-3">
      <SkeletonLoader className="h-[125px] w-full rounded-xl" />
      <div className="space-y-2">
        <SkeletonLoader className="h-4 w-[80%]" />
        <SkeletonLoader className="h-4 w-[60%]" />
      </div>
    </div>
  );
}

export function ProfileSkeleton() {
  return (
    <div className="space-y-8">
      <SkeletonLoader className="h-12 w-12 rounded-full" />
      <div className="space-y-2">
        <SkeletonLoader className="h-4 w-[250px]" />
        <SkeletonLoader className="h-4 w-[200px]" />
      </div>
      <div className="space-y-2">
        <SkeletonLoader className="h-4 w-full" />
        <SkeletonLoader className="h-4 w-[90%]" />
        <SkeletonLoader className="h-4 w-[80%]" />
      </div>
    </div>
  );
}

export function TableRowSkeleton() {
  return (
    <div className="flex items-center space-x-4 py-4">
      <SkeletonLoader className="h-12 w-12" />
      <div className="space-y-2">
        <SkeletonLoader className="h-4 w-[250px]" />
        <SkeletonLoader className="h-4 w-[200px]" />
      </div>
    </div>
  );
}

export function ProjectSkeleton() {
  return (
    <div className="space-y-6">
      <SkeletonLoader className="h-[200px] w-full rounded-xl" />
      <div className="space-y-2">
        <SkeletonLoader className="h-6 w-[300px]" />
        <SkeletonLoader className="h-4 w-[250px]" />
      </div>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <SkeletonLoader className="h-[150px] rounded-lg" />
        <SkeletonLoader className="h-[150px] rounded-lg" />
        <SkeletonLoader className="h-[150px] rounded-lg" />
      </div>
    </div>
  );
}