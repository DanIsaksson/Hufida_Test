import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { DollarSign, ArrowRight } from 'lucide-react';
import { neuCardStyles, neuButtonStyles, neuInputStyles, neuTabStyles } from '../../utils/styleUtils';

const DonationForm = ({ donationType, setDonationType, amount, setAmount, handleDonation }) => {
  const predefinedAmounts = [10, 25, 50, 100];
  const monthlyAmounts = [5, 10, 25, 50];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className={`${neuCardStyles({ elevation: "medium" })} mt-12 bg-deepGreen-700 text-white`}>
        <CardContent className="p-8">
          <Tabs value={donationType} onValueChange={setDonationType}>
            <TabsList className={`grid w-full grid-cols-2 mb-8 ${neuCardStyles({ elevation: "low" })} bg-deepGreen-600 p-1`}>
              <TabsTrigger value="one-time" className={`${neuTabStyles({ state: "default" })} text-lg`}>
                One-time Donation
              </TabsTrigger>
              <TabsTrigger value="monthly" className={`${neuTabStyles({ state: "default" })} text-lg`}>
                Monthly Donation
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="one-time">
              <h3 className="text-2xl font-semibold mb-6">Make a One-time Donation</h3>
              <p className="mb-6 text-lg">Choose an amount or enter a custom value:</p>
              <div className="grid grid-cols-2 gap-4 mb-6">
                {predefinedAmounts.map((presetAmount) => (
                  <Button
                    key={presetAmount}
                    variant={amount === presetAmount.toString() ? "default" : "outline"}
                    onClick={() => setAmount(presetAmount.toString())}
                    className={`${neuButtonStyles({ variant: "secondary", size: "lg" })} text-xl py-6`}
                  >
                    ${presetAmount}
                  </Button>
                ))}
              </div>
              <Input
                type="number"
                placeholder="Custom amount"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className={`${neuInputStyles()} mb-6 text-xl py-6 bg-deepGreen-600 text-white placeholder-deepGreen-300`}
              />
            </TabsContent>
            
            <TabsContent value="monthly">
              <h3 className="text-2xl font-semibold mb-6">Set Up Monthly Donation</h3>
              <p className="mb-6 text-lg">Choose a monthly contribution amount:</p>
              <div className="grid grid-cols-2 gap-4 mb-6">
                {monthlyAmounts.map((monthlyAmount) => (
                  <Button
                    key={monthlyAmount}
                    variant={amount === monthlyAmount.toString() ? "default" : "outline"}
                    onClick={() => setAmount(monthlyAmount.toString())}
                    className={`${neuButtonStyles({ variant: "secondary", size: "lg" })} text-xl py-6`}
                  >
                    ${monthlyAmount}/month
                  </Button>
                ))}
              </div>
              <Input
                type="number"
                placeholder="Custom monthly amount"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className={`${neuInputStyles()} mb-6 text-xl py-6 bg-deepGreen-600 text-white placeholder-deepGreen-300`}
              />
            </TabsContent>
          </Tabs>
          
          <p className="mb-6 text-lg">
            We use Revolut for secure and easy donations. Click the button below to proceed with your donation.
          </p>
          
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button 
              className={`${neuButtonStyles({ variant: "primary", size: "lg" })} w-full text-xl py-8 flex items-center justify-center`}
              onClick={handleDonation}
              disabled={!amount}
            >
              <DollarSign className="mr-2 h-6 w-6" />
              Donate ${amount || '0'} {donationType === 'monthly' ? 'Monthly' : ''} via Revolut
              <ArrowRight className="ml-2 h-6 w-6" />
            </Button>
          </motion.div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default DonationForm;