import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { neuCardStyles } from '../../utils/styleUtils';

const DonationGoal = () => {
  return (
    <motion.div 
      className="mb-16"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.4 }}
    >
      <Card className={`${neuCardStyles({ elevation: "medium" })} bg-deepGreen-700 text-white`}>
        <CardHeader>
          <CardTitle className="text-2xl text-center">Our Current Goal</CardTitle>
        </CardHeader>
        <CardContent>
          <Progress value={66} className="w-full h-8 mb-4 bg-deepGreen-600" />
          <p className="text-lg text-center font-semibold">$66,000 raised of $100,000 goal</p>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default DonationGoal;