import React from 'react';
import { motion } from 'framer-motion';
import { Heart } from 'lucide-react';

const DonationHero = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="text-center mb-12"
    >
      <h1 className="text-5xl font-bold mb-6 text-white">Support Our Cause</h1>
      <p className="mb-12 text-xl text-center text-deepGreen-100 max-w-3xl mx-auto">
        Your donations help us create positive change in Africa through innovative development approaches and humanitarian efforts.
      </p>
      <div className="flex justify-center">
        <Heart className="h-12 w-12 text-deepGreen-300 animate-pulse" />
      </div>
    </motion.div>
  );
};

export default DonationHero;