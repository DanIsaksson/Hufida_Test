import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Image, Video, File, ExternalLink } from 'lucide-react';
import { neuCardStyles } from '../../../utils/styleUtils';
import { supabase } from '@/lib/supabase';

const ContentCard = ({ content }) => {
  console.log('ContentCard rendering with content:', content);

  const getFileIcon = (fileType) => {
    if (fileType?.startsWith('image/')) return <Image className="h-5 w-5" />;
    if (fileType?.startsWith('video/')) return <Video className="h-5 w-5" />;
    return <File className="h-5 w-5" />;
  };

  const getFilePreview = (content) => {
    const file = content.project_files?.[0];
    if (!file) return null;

    const fileUrl = supabase.storage.from('project_files').getPublicUrl(file.file_path).data.publicUrl;

    if (file.file_type?.startsWith('image/')) {
      return (
        <div className="relative w-full h-48 rounded-lg overflow-hidden bg-deepGreen-50">
          <img
            src={fileUrl}
            alt={content.title}
            className="w-full h-full object-cover"
          />
        </div>
      );
    }

    if (file.file_type?.startsWith('video/')) {
      return (
        <div className="relative w-full h-48 rounded-lg overflow-hidden bg-deepGreen-50">
          <video
            controls
            className="w-full h-full object-cover"
            src={fileUrl}
          >
            Your browser does not support the video tag.
          </video>
        </div>
      );
    }

    return (
      <div className="flex items-center gap-2 text-deepGreen-600">
        <File className="h-5 w-5" />
        <span>{file.file_name}</span>
      </div>
    );
  };

  return (
    <Card key={content.id} className={neuCardStyles()}>
      <CardContent className="p-4 space-y-4">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="text-lg font-semibold text-deepGreen-800">{content.title}</h3>
            <p className="text-sm text-deepGreen-600">
              {new Date(content.created_at).toLocaleDateString()}
            </p>
          </div>
          <div className="flex items-center gap-2">
            {content.project_files?.map((file) => getFileIcon(file.file_type))}
          </div>
        </div>
        
        {getFilePreview(content)}
        
        <p className="text-deepGreen-700 whitespace-pre-wrap">{content.content}</p>
        
        {content.project_files?.length > 0 && (
          <div className="flex justify-end">
            <Button
              variant="ghost"
              size="sm"
              className="text-deepGreen-600 hover:text-deepGreen-700"
              onClick={() => {
                const fileUrl = supabase.storage
                  .from('project_files')
                  .getPublicUrl(content.project_files[0].file_path)
                  .data.publicUrl;
                window.open(fileUrl, '_blank');
              }}
            >
              View Full Size <ExternalLink className="ml-2 h-4 w-4" />
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ContentCard;