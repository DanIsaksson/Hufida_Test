import React from 'react';
import ContentCard from './ContentCard';

const ContentList = ({ contents }) => {
  console.log('ContentList rendering with contents:', contents);

  return (
    <div className="grid gap-4">
      {contents?.map((content) => (
        <ContentCard key={content.id} content={content} />
      ))}
    </div>
  );
};

export default ContentList;