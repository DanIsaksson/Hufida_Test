import React, { useState } from 'react';
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Plus, Loader2 } from 'lucide-react';
import { neuButtonStyles } from '../../../utils/styleUtils';
import FileUpload from '../files/FileUpload';
import { toast } from "sonner";

const ContentForm = ({ onSubmit, isSubmitting }) => {
  const [newContent, setNewContent] = useState({ title: '', content: '', content_type: 'article' });
  const [selectedFile, setSelectedFile] = useState(null);

  console.log('ContentForm rendering with selectedFile:', selectedFile);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ ...newContent, file: selectedFile });
    setNewContent({ title: '', content: '', content_type: 'article' });
    setSelectedFile(null);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <Input
        placeholder="Title"
        value={newContent.title}
        onChange={(e) => setNewContent({ ...newContent, title: e.target.value })}
        required
        className={neuButtonStyles({ variant: "input" })}
      />
      <Textarea
        placeholder="Content"
        value={newContent.content}
        onChange={(e) => setNewContent({ ...newContent, content: e.target.value })}
        required
        className={`min-h-[100px] ${neuButtonStyles({ variant: "input" })}`}
      />
      <FileUpload 
        onUploadComplete={setSelectedFile}
        onError={(error) => toast.error('File upload failed: ' + error.message)}
      />
      <Button 
        type="submit" 
        className={neuButtonStyles()}
        disabled={isSubmitting}
      >
        {isSubmitting ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Creating...
          </>
        ) : (
          <>
            <Plus className="mr-2 h-4 w-4" /> Add Content
          </>
        )}
      </Button>
    </form>
  );
};

export default ContentForm;