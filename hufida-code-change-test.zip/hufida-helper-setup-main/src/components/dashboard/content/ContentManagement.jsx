import React from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { toast } from "sonner";
import ContentForm from './ContentForm';
import ContentList from './ContentList';

const ContentManagement = ({ profile }) => {
  const queryClient = useQueryClient();

  console.log('ContentManagement rendering with profile:', profile);

  const { data: contents, isLoading } = useQuery({
    queryKey: ['contents', profile?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('content_items')
        .select(`
          *,
          project_files (
            id,
            file_name,
            file_path,
            file_type
          )
        `)
        .eq('creator_id', profile?.id)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data;
    },
    enabled: !!profile?.id,
  });

  const createContent = useMutation({
    mutationFn: async ({ title, content, content_type, file }) => {
      try {
        console.log('Starting content creation with data:', { title, content, content_type, file });
        
        // First create the content item
        const { data: contentItem, error: contentError } = await supabase
          .from('content_items')
          .insert([{ 
            title, 
            content, 
            content_type, 
            creator_id: profile.id 
          }])
          .select()
          .single();
        
        if (contentError) {
          console.error('Error creating content item:', contentError);
          throw contentError;
        }

        console.log('Content item created:', contentItem);

        // If we have a file, handle the file upload process
        if (file) {
          const fileExt = file.name.split('.').pop();
          const filePath = `${contentItem.id}/${Math.random()}.${fileExt}`;

          // First upload the actual file
          const { error: uploadError } = await supabase.storage
            .from('project_files')
            .upload(filePath, file);

          if (uploadError) {
            console.error('Error uploading file:', uploadError);
            throw uploadError;
          }

          console.log('File uploaded successfully, creating file record');

          // Then create the file record
          const { error: fileRecordError } = await supabase
            .from('project_files')
            .insert({
              content_id: contentItem.id,
              file_name: file.name,
              file_path: filePath,
              file_type: file.type,
              file_size: file.size,
              uploaded_by: profile.id
            });

          if (fileRecordError) {
            console.error('Error creating file record:', fileRecordError);
            throw fileRecordError;
          }

          console.log('File record created successfully');
        }

        return contentItem;
      } catch (error) {
        console.error('Error in createContent:', error);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['contents']);
      toast.success('Content created successfully');
    },
    onError: (error) => {
      console.error('Error creating content:', error);
      toast.error('Failed to create content: ' + error.message);
    },
  });

  if (isLoading) return <div>Loading...</div>;

  return (
    <div className="space-y-6">
      <ContentForm 
        onSubmit={createContent.mutate}
        isSubmitting={createContent.isLoading}
      />
      <ContentList contents={contents} />
    </div>
  );
};

export default ContentManagement;