import React from 'react';
import { motion } from "framer-motion";

const WelcomeHeader = ({ profile }) => {
  return (
    <motion.div 
      className="flex flex-col space-y-2"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <h1 className="text-2xl font-bold text-deepGreen-100">
        Welcome to your Dashboard, {profile?.full_name || 'User'}
      </h1>
      <p className="text-deepGreen-300">
        Manage your projects and engagements from this central interface
      </p>
    </motion.div>
  );
};

export default WelcomeHeader;