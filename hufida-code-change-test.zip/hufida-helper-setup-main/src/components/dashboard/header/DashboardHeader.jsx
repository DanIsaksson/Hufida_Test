import React from 'react';
import { motion } from "framer-motion";
import { LogOut, LayoutDashboard } from 'lucide-react';
import { Button } from "@/components/ui/button";
import NavigationBar from '../navigation/NavigationBar';

const DashboardHeader = ({ handleSignOut }) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-6 border-b border-border/40 bg-deepGreen-700/20 backdrop-blur-sm"
    >
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-4">
          <LayoutDashboard className="h-8 w-8 text-deepGreen-300" />
          <h1 className="text-2xl font-bold text-deepGreen-100">Partner Dashboard</h1>
        </div>
        <Button 
          variant="outline" 
          className="text-deepGreen-100 hover:bg-deepGreen-600/50 transition-all duration-300"
          onClick={handleSignOut}
        >
          <LogOut className="mr-2 h-4 w-4" />
          Sign Out
        </Button>
      </div>
      
      <NavigationBar />
    </motion.div>
  );
};

export default DashboardHeader;