import React from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { toast } from "sonner";
import { Card } from "@/components/ui/card";
import { FormProvider } from './form/context/FormProvider';
import FormSections from './form/components/FormSections';
import FormActions from './form/components/FormActions';

const ProjectForm = ({ initialData, onSuccess }) => {
  console.log('Rendering ProjectForm with initialData:', initialData);
  const queryClient = useQueryClient();
  const [isSubmitting, setIsSubmitting] = React.useState(false);

  const mutation = useMutation({
    mutationFn: async (data) => {
      if (isSubmitting) {
        console.log('Preventing duplicate submission');
        return;
      }

      setIsSubmitting(true);
      console.log('Submitting project data:', data);

      try {
        const cleanedData = {
          ...data,
          budget: data.budget === '' ? null : Number(data.budget),
          features: data.features?.map(feature => ({
            title: feature.title,
            description: feature.description,
            details: feature.details || []
          })) || [],
          target_audience: Array.isArray(data.target_audience) ? data.target_audience : [],
          tags: Array.isArray(data.tags) ? data.tags : [],
          impact_metrics: Array.isArray(data.impact_metrics) ? data.impact_metrics : [],
          objectives: Array.isArray(data.objectives) ? data.objectives : [],
          partnerships: Array.isArray(data.partnerships) ? data.partnerships : []
        };

        const { data: result, error } = await supabase
          .from('projects')
          .upsert(cleanedData)
          .select()
          .maybeSingle();

        if (error) {
          console.error('Error saving project:', error);
          throw error;
        }

        return result;
      } finally {
        setIsSubmitting(false);
      }
    },
    onSuccess: () => {
      toast.success("Project saved successfully");
      queryClient.invalidateQueries(['active-project']);
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      console.error('Error saving project:', error);
      toast.error(`Failed to save project: ${error.message}`);
      setIsSubmitting(false);
    }
  });

  const handleSubmit = (data) => {
    console.log('Form submitted with data:', data);
    if (!isSubmitting) {
      mutation.mutate(data);
    } else {
      console.log('Preventing duplicate submission while form is submitting');
    }
  };

  return (
    <Card className="p-6 bg-white/95 backdrop-blur-sm shadow-lg">
      <FormProvider 
        initialData={initialData} 
        onSubmit={handleSubmit}
        isSubmitting={isSubmitting}
      >
        <FormSections />
        <FormActions />
      </FormProvider>
    </Card>
  );
};

export default ProjectForm;