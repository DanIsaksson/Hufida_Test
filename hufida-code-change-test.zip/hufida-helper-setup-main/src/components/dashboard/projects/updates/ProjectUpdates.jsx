import React from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { format } from 'date-fns';
import { useForm } from 'react-hook-form';
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { ScrollArea } from "@/components/ui/scroll-area";
import { motion } from "framer-motion";

const ProjectUpdates = ({ projectId }) => {
  const queryClient = useQueryClient();
  const form = useForm({
    defaultValues: {
      update_type: '',
      description: '',
    }
  });

  const { data: updates, isLoading } = useQuery({
    queryKey: ['project-updates', projectId],
    queryFn: async () => {
      console.log('Fetching project updates for:', projectId);
      const { data, error } = await supabase
        .from('project_updates')
        .select(`
          *,
          profiles:updated_by (
            full_name,
            avatar_url
          )
        `)
        .eq('project_id', projectId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      console.log('Fetched updates:', data);
      return data;
    },
  });

  const createUpdate = useMutation({
    mutationFn: async (values) => {
      console.log('Creating project update:', values);
      const { data, error } = await supabase
        .from('project_updates')
        .insert({
          project_id: projectId,
          ...values,
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      toast.success('Update posted successfully');
      form.reset();
      queryClient.invalidateQueries(['project-updates', projectId]);
    },
    onError: (error) => {
      console.error('Error creating update:', error);
      toast.error('Failed to post update');
    },
  });

  const onSubmit = (data) => {
    createUpdate.mutate(data);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-deepGreen-800">
            Project Updates
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="update_type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Update Type</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select update type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="progress">Progress Update</SelectItem>
                        <SelectItem value="milestone">Milestone</SelectItem>
                        <SelectItem value="challenge">Challenge</SelectItem>
                        <SelectItem value="resource">Resource Update</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea
                        {...field}
                        placeholder="Share your project update..."
                        className="min-h-[100px]"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button 
                type="submit" 
                className="w-full"
                disabled={createUpdate.isPending}
              >
                Post Update
              </Button>
            </form>
          </Form>

          <div className="mt-8">
            <ScrollArea className="h-[400px] pr-4">
              {isLoading ? (
                <div>Loading updates...</div>
              ) : (
                <div className="space-y-4">
                  {updates?.map((update, index) => (
                    <motion.div
                      key={update.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <Card>
                        <CardContent className="p-4">
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <span className="inline-block px-2 py-1 text-sm rounded-full bg-deepGreen-100 text-deepGreen-800">
                                {update.update_type}
                              </span>
                            </div>
                            <span className="text-sm text-gray-500">
                              {format(new Date(update.created_at), 'PPp')}
                            </span>
                          </div>
                          <p className="text-gray-700 mt-2">{update.description}</p>
                          <div className="mt-2 text-sm text-gray-500">
                            Posted by {update.profiles?.full_name || 'Unknown'}
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              )}
            </ScrollArea>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ProjectUpdates;