import React from 'react';
import { FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { motion } from "framer-motion";
import { useFormContext } from './context/FormProvider';

const ProjectVisionSection = () => {
  const { form } = useFormContext();
  
  return (
    <motion.div 
      className="space-y-6"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.6 }}
    >
      <h3 className="text-xl font-semibold text-deepGreen-800">Vision & Impact</h3>
      <div className="space-y-6">
        <FormField
          control={form.control}
          name="vision"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="text-deepGreen-700 font-medium">Project Vision</FormLabel>
              <FormControl>
                <Textarea 
                  {...field} 
                  placeholder="Describe your project's long-term vision and goals"
                  className="min-h-[100px] bg-white/50 backdrop-blur-sm border-deepGreen-200 focus:border-deepGreen-400 transition-colors"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="impact"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="text-deepGreen-700 font-medium">Expected Impact</FormLabel>
              <FormControl>
                <Textarea 
                  {...field} 
                  placeholder="Describe the expected impact on children, parents, library, and community"
                  className="min-h-[100px] bg-white/50 backdrop-blur-sm border-deepGreen-200 focus:border-deepGreen-400 transition-colors"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      </div>
    </motion.div>
  );
};

export default ProjectVisionSection;