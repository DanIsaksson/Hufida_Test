import React from 'react';
import { useForm } from 'react-hook-form';
import { Form } from "@/components/ui/form";

export const FormContext = React.createContext({});

export const FormProvider = ({ children, initialData, onSubmit, isSubmitting }) => {
  console.log('Initializing FormProvider with data:', initialData);
  
  const form = useForm({
    defaultValues: initialData || {
      title: '',
      description: '',
      category: '',
      project_status: 'draft',
      start_date: null,
      end_date: null,
      target_audience: [],
      budget: '',
      funding_status: 'pending',
      approach: '',
      innovation: '',
      vision: '',
      impact: '',
      features: [],
      impact_metrics: [],
      implementation_details: '',
      objectives: [],
      partnerships: [],
      tags: []
    }
  });

  return (
    <FormContext.Provider value={{ form, isSubmitting }}>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          {children}
        </form>
      </Form>
    </FormContext.Provider>
  );
};

export const useFormContext = () => {
  const context = React.useContext(FormContext);
  if (!context) {
    throw new Error('useFormContext must be used within a FormProvider');
  }
  return context;
};