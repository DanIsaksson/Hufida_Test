import React from 'react';
import { motion } from "framer-motion";
import ImpactDescription from './impact/ImpactDescription';
import ImpactMetricsList from './impact/ImpactMetricsList';

const ImpactSection = () => {
  return (
    <motion.div 
      className="space-y-8"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.1 }}
    >
      <h3 className="text-2xl font-semibold text-deepGreen-800">Impact & Metrics</h3>
      <div className="space-y-8">
        <ImpactDescription />
        <ImpactMetricsList />
      </div>
    </motion.div>
  );
};

export default ImpactSection;