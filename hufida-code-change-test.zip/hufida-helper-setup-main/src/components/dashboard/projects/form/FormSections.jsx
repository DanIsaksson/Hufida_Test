import React from 'react';
import BasicInfoSection from '../BasicInfoSection';
import ObjectivesSection from '../ObjectivesSection';
import CategorySection from '../CategorySection';
import ImplementationSection from '../ImplementationSection';
import PartnershipsSection from '../PartnershipsSection';
import ImpactSection from '../ImpactSection';
import FeaturesSection from '../FeaturesSection';
import TagsSection from '../TagsSection';
import ProjectVisionSection from '../ProjectVisionSection';

const FormSections = () => {
  console.log('Rendering FormSections');
  
  return (
    <div className="space-y-8">
      <BasicInfoSection />
      <CategorySection />
      <ObjectivesSection />
      <ImplementationSection />
      <PartnershipsSection />
      <ImpactSection />
      <FeaturesSection />
      <ProjectVisionSection />
      <TagsSection />
    </div>
  );
};

export default FormSections;