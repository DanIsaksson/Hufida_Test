import React from 'react';
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { FormField, FormItem, FormLabel, FormControl, FormMessage, FormDescription } from "@/components/ui/form";
import { motion } from "framer-motion";
import { useFormContext } from './context/FormProvider';
import { HelpCircle } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

const BasicInfoSection = () => {
  const { form } = useFormContext();
  
  console.log('Rendering BasicInfoSection with form state:', form.formState);

  return (
    <motion.div 
      className="space-y-6"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.1 }}
    >
      <div className="flex items-center gap-2">
        <h3 className="text-xl font-semibold text-deepGreen-800">Basic Information</h3>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <HelpCircle className="h-4 w-4 text-deepGreen-600 cursor-help" />
            </TooltipTrigger>
            <TooltipContent>
              <p>Start by providing the essential details of your project</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>

      <div className="space-y-6">
        <FormField
          control={form.control}
          name="title"
          rules={{ 
            required: "Project title is required",
            minLength: {
              value: 3,
              message: "Title must be at least 3 characters"
            }
          }}
          render={({ field }) => (
            <FormItem>
              <div className="flex items-center gap-2">
                <FormLabel className="text-deepGreen-700 font-medium">
                  Project Title <span className="text-red-500">*</span>
                </FormLabel>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <HelpCircle className="h-4 w-4 text-deepGreen-600 cursor-help" />
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Choose a clear, descriptive title for your project</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
              <FormControl>
                <Input 
                  {...field} 
                  placeholder="Enter project title" 
                  className={`bg-white/50 backdrop-blur-sm border-deepGreen-200 focus:border-deepGreen-400 transition-colors
                    ${form.formState.errors.title ? 'border-red-500 focus:border-red-500' : ''}`}
                />
              </FormControl>
              <FormDescription className="text-sm text-deepGreen-600">
                This will be displayed as the main title of your project
              </FormDescription>
              <FormMessage className="text-red-500" />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="description"
          rules={{ 
            required: "Project description is required",
            minLength: {
              value: 20,
              message: "Description should be at least 20 characters"
            }
          }}
          render={({ field }) => (
            <FormItem>
              <div className="flex items-center gap-2">
                <FormLabel className="text-deepGreen-700 font-medium">
                  Description <span className="text-red-500">*</span>
                </FormLabel>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <HelpCircle className="h-4 w-4 text-deepGreen-600 cursor-help" />
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Provide a detailed description of your project's goals and scope</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
              <FormControl>
                <Textarea 
                  {...field} 
                  placeholder="Describe your project" 
                  className={`min-h-[120px] bg-white/50 backdrop-blur-sm border-deepGreen-200 focus:border-deepGreen-400 transition-colors resize-y
                    ${form.formState.errors.description ? 'border-red-500 focus:border-red-500' : ''}`}
                />
              </FormControl>
              <FormDescription className="text-sm text-deepGreen-600">
                Include key information about your project's purpose and objectives
              </FormDescription>
              <FormMessage className="text-red-500" />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField
            control={form.control}
            name="location"
            render={({ field }) => (
              <FormItem>
                <div className="flex items-center gap-2">
                  <FormLabel className="text-deepGreen-700 font-medium">Location</FormLabel>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <HelpCircle className="h-4 w-4 text-deepGreen-600 cursor-help" />
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Where will this project take place?</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                <FormControl>
                  <Input 
                    {...field} 
                    placeholder="Project location" 
                    className="bg-white/50 backdrop-blur-sm border-deepGreen-200 focus:border-deepGreen-400 transition-colors" 
                  />
                </FormControl>
                <FormDescription className="text-sm text-deepGreen-600">
                  Optional: Add the physical location of your project
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="website"
            rules={{
              pattern: {
                value: /^(https?:\/\/)?([\da-z.-]+)\.([a-z.]{2,6})([/\w .-]*)*\/?$/,
                message: "Please enter a valid URL"
              }
            }}
            render={({ field }) => (
              <FormItem>
                <div className="flex items-center gap-2">
                  <FormLabel className="text-deepGreen-700 font-medium">Website</FormLabel>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <HelpCircle className="h-4 w-4 text-deepGreen-600 cursor-help" />
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Add a link to your project's website if available</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                <FormControl>
                  <Input 
                    {...field} 
                    type="url" 
                    placeholder="Project website" 
                    className={`bg-white/50 backdrop-blur-sm border-deepGreen-200 focus:border-deepGreen-400 transition-colors
                      ${form.formState.errors.website ? 'border-red-500 focus:border-red-500' : ''}`}
                  />
                </FormControl>
                <FormDescription className="text-sm text-deepGreen-600">
                  Optional: Include your project's website URL
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
      </div>
    </motion.div>
  );
};

export default BasicInfoSection;