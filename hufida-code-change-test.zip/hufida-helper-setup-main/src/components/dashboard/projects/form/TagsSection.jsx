import React from 'react';
import { motion } from "framer-motion";
import { useFormContext } from './context/FormProvider';
import TagInput from './tags/TagInput';
import TagList from './tags/TagList';
import { TAG_FIELDS } from './tags/types';

const TagsSection = () => {
  const { form } = useFormContext();
  console.log('Rendering TagsSection');
  
  const handleRemoveItem = (index, fieldName) => {
    console.log('Removing item at index:', index, 'from field:', fieldName);
    const currentValue = form.getValues(fieldName) || [];
    const newValue = currentValue.filter((_, i) => i !== index);
    form.setValue(fieldName, newValue);
  };

  return (
    <motion.div 
      className="space-y-6"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.5 }}
    >
      <h3 className="text-xl font-semibold text-deepGreen-800">Additional Information</h3>
      <div className="space-y-6">
        <div>
          <TagInput 
            fieldName={TAG_FIELDS.TARGET_AUDIENCE.name}
            label={TAG_FIELDS.TARGET_AUDIENCE.label}
            placeholder={TAG_FIELDS.TARGET_AUDIENCE.placeholder}
            maxLength={TAG_FIELDS.TARGET_AUDIENCE.maxLength}
            maxTags={TAG_FIELDS.TARGET_AUDIENCE.maxTags}
          />
          <TagList 
            tags={form.watch(TAG_FIELDS.TARGET_AUDIENCE.name)}
            onRemove={(index) => handleRemoveItem(index, TAG_FIELDS.TARGET_AUDIENCE.name)}
            variant="secondary"
          />
        </div>

        <div>
          <TagInput 
            fieldName={TAG_FIELDS.TAGS.name}
            label={TAG_FIELDS.TAGS.label}
            placeholder={TAG_FIELDS.TAGS.placeholder}
            maxLength={TAG_FIELDS.TAGS.maxLength}
            maxTags={TAG_FIELDS.TAGS.maxTags}
          />
          <TagList 
            tags={form.watch(TAG_FIELDS.TAGS.name)}
            onRemove={(index) => handleRemoveItem(index, TAG_FIELDS.TAGS.name)}
            variant="secondary"
          />
        </div>
      </div>
    </motion.div>
  );
};

export default TagsSection;