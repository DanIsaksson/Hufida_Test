import React from 'react';
import { FormField, FormItem, FormLabel, FormControl, FormMessage, FormDescription } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Plus, X, HelpCircle } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { motion } from "framer-motion";
import { useFormContext } from './context/FormProvider';

const ObjectivesSection = () => {
  const { form } = useFormContext();
  const objectives = form.watch('objectives') || [];

  const addObjective = () => {
    console.log('Adding new objective');
    const currentObjectives = form.getValues('objectives') || [];
    form.setValue('objectives', [...currentObjectives, { title: '', description: '' }]);
  };

  const removeObjective = (index) => {
    console.log('Removing objective at index:', index);
    const currentObjectives = form.getValues('objectives') || [];
    form.setValue('objectives', currentObjectives.filter((_, i) => i !== index));
  };

  return (
    <motion.div 
      className="space-y-6"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.2 }}
    >
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-2">
          <h3 className="text-xl font-semibold text-deepGreen-800">Project Objectives</h3>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <HelpCircle className="h-4 w-4 text-deepGreen-600 cursor-help" />
              </TooltipTrigger>
              <TooltipContent>
                <p>Define clear, measurable objectives for your project</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
        <Button 
          type="button" 
          variant="outline" 
          size="sm"
          onClick={addObjective}
          className="flex items-center gap-2"
        >
          <Plus className="h-4 w-4" />
          Add Objective
        </Button>
      </div>

      <div className="space-y-6">
        {objectives.map((_, index) => (
          <div key={index} className="flex gap-4 items-start p-4 border rounded-lg bg-white/50">
            <div className="flex-1 space-y-4">
              <FormField
                control={form.control}
                name={`objectives.${index}.title`}
                rules={{ required: "Objective title is required" }}
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-deepGreen-700 font-medium">
                      Objective Title <span className="text-red-500">*</span>
                    </FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        placeholder="e.g., Increase community engagement"
                        className="bg-white/50 backdrop-blur-sm border-deepGreen-200 focus:border-deepGreen-400 transition-colors"
                      />
                    </FormControl>
                    <FormDescription>
                      Provide a clear, concise title for this objective
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name={`objectives.${index}.description`}
                rules={{ required: "Objective description is required" }}
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-deepGreen-700 font-medium">
                      Description <span className="text-red-500">*</span>
                    </FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        placeholder="Describe how you'll achieve this objective"
                        className="bg-white/50 backdrop-blur-sm border-deepGreen-200 focus:border-deepGreen-400 transition-colors"
                      />
                    </FormControl>
                    <FormDescription>
                      Detail the specific steps and methods to achieve this objective
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              onClick={() => removeObjective(index)}
              className="mt-8"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        ))}
      </div>
    </motion.div>
  );
};

export default ObjectivesSection;