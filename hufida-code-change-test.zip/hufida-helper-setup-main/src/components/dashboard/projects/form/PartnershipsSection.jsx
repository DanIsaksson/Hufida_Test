import React from 'react';
import { FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Plus, X } from "lucide-react";
import { motion } from "framer-motion";
import { useFormContext } from './context/FormProvider';

const PartnershipsSection = () => {
  const { form } = useFormContext();
  const partnerships = form.watch('partnerships') || [];

  const addPartnership = () => {
    const currentPartnerships = form.getValues('partnerships') || [];
    form.setValue('partnerships', [...currentPartnerships, { name: '', role: '' }]);
  };

  const removePartnership = (index) => {
    const currentPartnerships = form.getValues('partnerships') || [];
    form.setValue('partnerships', currentPartnerships.filter((_, i) => i !== index));
  };

  return (
    <motion.div 
      className="space-y-6"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.4 }}
    >
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-semibold text-deepGreen-800">Partnerships</h3>
        <Button 
          type="button" 
          variant="outline" 
          size="sm"
          onClick={addPartnership}
          className="flex items-center gap-2"
        >
          <Plus className="h-4 w-4" />
          Add Partnership
        </Button>
      </div>

      <div className="space-y-4">
        {partnerships.map((_, index) => (
          <div key={index} className="flex gap-4 items-start">
            <div className="flex-1 space-y-4">
              <FormField
                control={form.control}
                name={`partnerships.${index}.name`}
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Partner Name</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="Enter partner organization name" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name={`partnerships.${index}.role`}
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Partner Role</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="Describe partner's role in the project" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              onClick={() => removePartnership(index)}
              className="mt-8"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        ))}
      </div>
    </motion.div>
  );
};

export default PartnershipsSection;