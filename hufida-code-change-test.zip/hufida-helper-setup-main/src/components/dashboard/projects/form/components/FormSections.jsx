import React from 'react';
import BasicInfoSection from '../basic-info/BasicInfoSection';
import ObjectivesSection from '../ObjectivesSection';
import CategorySection from '../CategorySection';
import ImplementationSection from '../ImplementationSection';
import PartnershipsSection from '../PartnershipsSection';
import ImpactSection from '../ImpactSection';
import FeaturesSection from '../FeaturesSection';
import ProjectVisionSection from '../ProjectVisionSection';
import TagsSection from '../TagsSection';

const FormSections = () => {
  console.log('Rendering FormSections');
  
  return (
    <div className="space-y-8 text-gray-800">
      <BasicInfoSection />
      <CategorySection />
      <ObjectivesSection />
      <ImplementationSection />
      <PartnershipsSection />
      <ImpactSection />
      <FeaturesSection />
      <ProjectVisionSection />
      <TagsSection />
    </div>
  );
};

export default FormSections;