import React from 'react';
import { Button } from "@/components/ui/button";
import { useFormContext } from '../context/FormProvider';
import { Loader2 } from "lucide-react";

const FormActions = () => {
  const { form, isSubmitting } = useFormContext();
  
  return (
    <div className="flex justify-end gap-4 mt-8">
      <Button 
        type="submit"
        disabled={isSubmitting}
        onClick={form.handleSubmit}
        className="bg-deepGreen-600 hover:bg-deepGreen-700"
      >
        {isSubmitting ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Saving...
          </>
        ) : (
          'Save Project'
        )}
      </Button>
    </div>
  );
};

export default FormActions;