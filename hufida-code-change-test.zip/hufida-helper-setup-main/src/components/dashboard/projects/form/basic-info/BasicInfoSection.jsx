import React from 'react';
import { motion } from "framer-motion";
import { HelpCircle } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import ProjectTitle from './ProjectTitle';
import ProjectDescription from './ProjectDescription';
import ProjectLocation from './ProjectLocation';
import ProjectWebsite from './ProjectWebsite';

const BasicInfoSection = () => {
  console.log('Rendering BasicInfoSection');

  return (
    <motion.div 
      className="space-y-6"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.1 }}
    >
      <div className="flex items-center gap-2">
        <h3 className="text-xl font-semibold text-deepGreen-800">Basic Information</h3>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <HelpCircle className="h-4 w-4 text-deepGreen-600 cursor-help" />
            </TooltipTrigger>
            <TooltipContent>
              <p>Start by providing the essential details of your project</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>

      <div className="space-y-6">
        <ProjectTitle />
        <ProjectDescription />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <ProjectLocation />
          <ProjectWebsite />
        </div>
      </div>
    </motion.div>
  );
};

export default BasicInfoSection;