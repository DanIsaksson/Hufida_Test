import React from 'react';
import { FormField, FormItem, FormLabel, FormControl, FormMessage, FormDescription } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { HelpCircle } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useFormContext } from '../context/FormProvider';

const ProjectLocation = () => {
  const { form } = useFormContext();
  
  return (
    <FormField
      control={form.control}
      name="location"
      render={({ field }) => (
        <FormItem>
          <div className="flex items-center gap-2">
            <FormLabel className="text-deepGreen-700 font-medium">Location</FormLabel>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <HelpCircle className="h-4 w-4 text-deepGreen-600 cursor-help" />
                </TooltipTrigger>
                <TooltipContent>
                  <p>Where will this project take place?</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          <FormControl>
            <Input 
              {...field} 
              placeholder="Project location" 
              className="bg-white/50 backdrop-blur-sm border-deepGreen-200 focus:border-deepGreen-400 transition-colors" 
            />
          </FormControl>
          <FormDescription className="text-sm text-deepGreen-600">
            Optional: Add the physical location of your project
          </FormDescription>
          <FormMessage />
        </FormItem>
      )}
    />
  );
};

export default ProjectLocation;