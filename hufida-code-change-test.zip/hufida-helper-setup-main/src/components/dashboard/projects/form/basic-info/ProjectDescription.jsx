import React from 'react';
import { FormField, FormItem, FormLabel, FormControl, FormMessage, FormDescription } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { HelpCircle } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useFormContext } from '../context/FormProvider';

const ProjectDescription = () => {
  const { form } = useFormContext();
  
  return (
    <FormField
      control={form.control}
      name="description"
      rules={{ 
        required: "Project description is required",
        minLength: {
          value: 20,
          message: "Description should be at least 20 characters"
        }
      }}
      render={({ field }) => (
        <FormItem>
          <div className="flex items-center gap-2">
            <FormLabel className="text-deepGreen-700 font-medium">
              Description <span className="text-red-500">*</span>
            </FormLabel>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <HelpCircle className="h-4 w-4 text-deepGreen-600 cursor-help" />
                </TooltipTrigger>
                <TooltipContent>
                  <p>Provide a detailed description of your project's goals and scope</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          <FormControl>
            <Textarea 
              {...field} 
              placeholder="Describe your project" 
              className={`min-h-[120px] bg-white/50 backdrop-blur-sm border-deepGreen-200 focus:border-deepGreen-400 transition-colors resize-y
                ${form.formState.errors.description ? 'border-red-500 focus:border-red-500' : ''}`}
            />
          </FormControl>
          <FormDescription className="text-sm text-deepGreen-600">
            Include key information about your project's purpose and objectives
          </FormDescription>
          <FormMessage className="text-red-500" />
        </FormItem>
      )}
    />
  );
};

export default ProjectDescription;