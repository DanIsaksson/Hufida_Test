import React from 'react';
import { FormField, FormItem, FormLabel, FormControl, FormMessage, FormDescription } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { HelpCircle } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useFormContext } from '../context/FormProvider';

const ProjectWebsite = () => {
  const { form } = useFormContext();
  
  return (
    <FormField
      control={form.control}
      name="website"
      rules={{
        pattern: {
          value: /^(https?:\/\/)?([\da-z.-]+)\.([a-z.]{2,6})([/\w .-]*)*\/?$/,
          message: "Please enter a valid URL"
        }
      }}
      render={({ field }) => (
        <FormItem>
          <div className="flex items-center gap-2">
            <FormLabel className="text-deepGreen-700 font-medium">Website</FormLabel>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <HelpCircle className="h-4 w-4 text-deepGreen-600 cursor-help" />
                </TooltipTrigger>
                <TooltipContent>
                  <p>Add a link to your project's website if available</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          <FormControl>
            <Input 
              {...field} 
              type="url" 
              placeholder="Project website" 
              className={`bg-white/50 backdrop-blur-sm border-deepGreen-200 focus:border-deepGreen-400 transition-colors
                ${form.formState.errors.website ? 'border-red-500 focus:border-red-500' : ''}`}
            />
          </FormControl>
          <FormDescription className="text-sm text-deepGreen-600">
            Optional: Include your project's website URL
          </FormDescription>
          <FormMessage />
        </FormItem>
      )}
    />
  );
};

export default ProjectWebsite;