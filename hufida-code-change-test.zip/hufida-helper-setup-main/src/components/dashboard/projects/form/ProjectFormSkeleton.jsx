import React from 'react';
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { motion } from "framer-motion";
import BasicInfoSkeleton from './skeleton/BasicInfoSkeleton';
import DatesSkeleton from './skeleton/DatesSkeleton';
import CategorySkeleton from './skeleton/CategorySkeleton';
import BudgetSkeleton from './skeleton/BudgetSkeleton';
import TagsSkeleton from './skeleton/TagsSkeleton';

const ProjectFormSkeleton = () => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="max-w-4xl mx-auto">
        <CardHeader className="space-y-2 border-b pb-6">
          <Skeleton className="h-8 w-1/3" />
          <Skeleton className="h-4 w-2/3" />
        </CardHeader>
        <CardContent className="space-y-6 pt-8">
          <BasicInfoSkeleton />
          <DatesSkeleton />
          <CategorySkeleton />
          <BudgetSkeleton />
          <TagsSkeleton />
          
          {/* Submit Button */}
          <div className="pt-6">
            <Skeleton className="h-12 w-full" />
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default ProjectFormSkeleton;