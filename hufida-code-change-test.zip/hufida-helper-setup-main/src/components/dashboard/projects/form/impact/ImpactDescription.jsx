import React from 'react';
import { FormField, FormItem, FormLabel, FormControl, FormMessage, FormDescription } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { HelpCircle } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { motion } from "framer-motion";
import { useFormContext } from '../context/FormProvider';

const ImpactDescription = () => {
  const { form } = useFormContext();
  
  return (
    <motion.div 
      className="space-y-6"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.2 }}
    >
      <div className="flex items-center gap-2">
        <h3 className="text-xl font-semibold text-deepGreen-800">Project Impact</h3>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <HelpCircle className="h-4 w-4 text-deepGreen-600 cursor-help" />
            </TooltipTrigger>
            <TooltipContent>
              <p>Describe how your project will make a difference</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>

      <FormField
        control={form.control}
        name="impact"
        rules={{
          required: "Impact description is required",
          minLength: {
            value: 50,
            message: "Please provide more detailed impact information"
          }
        }}
        render={({ field }) => (
          <FormItem>
            <FormLabel className="text-deepGreen-700 font-medium">
              Expected Impact <span className="text-red-500">*</span>
            </FormLabel>
            <FormControl>
              <Textarea 
                {...field} 
                placeholder="Describe the expected impact on children, parents, library, and community"
                className="min-h-[150px] bg-white/50 backdrop-blur-sm border-deepGreen-200 focus:border-deepGreen-400 transition-colors"
              />
            </FormControl>
            <FormDescription>
              Detail the specific benefits and changes your project will bring to the community
            </FormDescription>
            <FormMessage />
          </FormItem>
        )}
      />
    </motion.div>
  );
};

export default ImpactDescription;