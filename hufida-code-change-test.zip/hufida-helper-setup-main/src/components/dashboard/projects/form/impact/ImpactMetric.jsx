import React from 'react';
import { FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";
import { useFormContext } from '../context/FormProvider';

const ImpactMetric = ({ index, onRemove }) => {
  const { form } = useFormContext();
  
  return (
    <div className="flex gap-4 items-start">
      <div className="flex-1 space-y-4">
        <FormField
          control={form.control}
          name={`impact_metrics.${index}.metric_name`}
          render={({ field }) => (
            <FormItem>
              <FormLabel className="text-deepGreen-700 font-medium">Metric Name</FormLabel>
              <FormControl>
                <Input 
                  {...field} 
                  placeholder="e.g., Carbon Reduction"
                  className="bg-white/50 backdrop-blur-sm border-deepGreen-200 focus:border-deepGreen-400 transition-colors"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name={`impact_metrics.${index}.target_value`}
          render={({ field }) => (
            <FormItem>
              <FormLabel className="text-deepGreen-700 font-medium">Target Value</FormLabel>
              <FormControl>
                <Input 
                  {...field} 
                  type="number"
                  placeholder="Enter target value"
                  className="bg-white/50 backdrop-blur-sm border-deepGreen-200 focus:border-deepGreen-400 transition-colors"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name={`impact_metrics.${index}.unit`}
          render={({ field }) => (
            <FormItem>
              <FormLabel className="text-deepGreen-700 font-medium">Unit</FormLabel>
              <FormControl>
                <Input 
                  {...field} 
                  placeholder="e.g., tons, kWh"
                  className="bg-white/50 backdrop-blur-sm border-deepGreen-200 focus:border-deepGreen-400 transition-colors"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      </div>
      <Button
        type="button"
        variant="ghost"
        size="icon"
        onClick={() => onRemove(index)}
        className="mt-8"
      >
        <X className="h-4 w-4" />
      </Button>
    </div>
  );
};

export default ImpactMetric;