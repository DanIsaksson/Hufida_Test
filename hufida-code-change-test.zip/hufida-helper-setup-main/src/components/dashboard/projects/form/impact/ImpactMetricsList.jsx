import React from 'react';
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { motion } from "framer-motion";
import ImpactMetric from './ImpactMetric';
import { useFormContext } from '../context/FormProvider';

const ImpactMetricsList = () => {
  const { form } = useFormContext();
  const impact_metrics = form.watch('impact_metrics') || [];

  const addMetric = () => {
    const currentMetrics = form.getValues('impact_metrics') || [];
    form.setValue('impact_metrics', [...currentMetrics, { 
      metric_name: '', 
      target_value: '', 
      unit: '' 
    }]);
  };

  const removeMetric = (index) => {
    const currentMetrics = form.getValues('impact_metrics') || [];
    form.setValue('impact_metrics', currentMetrics.filter((_, i) => i !== index));
  };

  return (
    <motion.div 
      className="space-y-6"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.3 }}
    >
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-semibold text-deepGreen-800">Impact Metrics</h3>
        <Button 
          type="button" 
          variant="outline" 
          size="sm"
          onClick={addMetric}
          className="flex items-center gap-2"
        >
          <Plus className="h-4 w-4" />
          Add Metric
        </Button>
      </div>

      <div className="space-y-6">
        {impact_metrics.map((_, index) => (
          <ImpactMetric 
            key={index} 
            index={index} 
            onRemove={removeMetric}
          />
        ))}
      </div>
    </motion.div>
  );
};

export default ImpactMetricsList;