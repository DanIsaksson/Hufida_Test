import React from 'react';
import { FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Plus, X } from "lucide-react";
import { motion } from "framer-motion";
import { useFormContext } from './context/FormProvider';

const FeaturesSection = () => {
  const { form } = useFormContext();
  const features = form.watch('features') || [];

  const addFeature = () => {
    const currentFeatures = form.getValues('features') || [];
    form.setValue('features', [...currentFeatures, { title: '', description: '' }]);
  };

  const removeFeature = (index) => {
    const currentFeatures = form.getValues('features') || [];
    form.setValue('features', currentFeatures.filter((_, i) => i !== index));
  };

  return (
    <motion.div 
      className="space-y-6"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.4 }}
    >
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-semibold text-deepGreen-800">Key Features</h3>
        <Button 
          type="button" 
          variant="outline" 
          size="sm"
          onClick={addFeature}
          className="flex items-center gap-2"
        >
          <Plus className="h-4 w-4" />
          Add Feature
        </Button>
      </div>

      <div className="space-y-4">
        {features.map((_, index) => (
          <div key={index} className="flex gap-4 items-start">
            <div className="flex-1 space-y-4">
              <FormField
                control={form.control}
                name={`features.${index}.title`}
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-deepGreen-700 font-medium">Feature Title</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        placeholder="e.g., Safe Spaces"
                        className="bg-white/50 backdrop-blur-sm border-deepGreen-200 focus:border-deepGreen-400 transition-colors"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name={`features.${index}.description`}
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-deepGreen-700 font-medium">Description</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        placeholder="Feature description"
                        className="bg-white/50 backdrop-blur-sm border-deepGreen-200 focus:border-deepGreen-400 transition-colors"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              onClick={() => removeFeature(index)}
              className="mt-8"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        ))}
      </div>
    </motion.div>
  );
};

export default FeaturesSection;