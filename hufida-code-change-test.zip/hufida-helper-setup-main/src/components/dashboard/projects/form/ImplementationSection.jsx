import React from 'react';
import { FormField, FormItem, FormLabel, FormControl, FormMessage, FormDescription } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { HelpCircle } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { motion } from "framer-motion";
import { useFormContext } from './context/FormProvider';

const ImplementationSection = () => {
  const { form } = useFormContext();
  
  return (
    <motion.div 
      className="space-y-6"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.3 }}
    >
      <div className="flex items-center gap-2">
        <h3 className="text-xl font-semibold text-deepGreen-800">Implementation Details</h3>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <HelpCircle className="h-4 w-4 text-deepGreen-600 cursor-help" />
            </TooltipTrigger>
            <TooltipContent>
              <p>Outline your implementation strategy and timeline</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>

      <FormField
        control={form.control}
        name="implementation_details"
        rules={{
          required: "Implementation details are required",
          minLength: {
            value: 50,
            message: "Please provide more detailed implementation information"
          }
        }}
        render={({ field }) => (
          <FormItem>
            <FormLabel className="text-deepGreen-700 font-medium">
              Implementation Plan <span className="text-red-500">*</span>
            </FormLabel>
            <FormControl>
              <Textarea 
                {...field} 
                placeholder="Describe the implementation strategy, timeline, and key milestones"
                className="min-h-[150px] bg-white/50 backdrop-blur-sm border-deepGreen-200 focus:border-deepGreen-400 transition-colors"
              />
            </FormControl>
            <FormDescription>
              Include key milestones, timeline, and resources needed for successful implementation
            </FormDescription>
            <FormMessage />
          </FormItem>
        )}
      />
    </motion.div>
  );
};

export default ImplementationSection;