import React, { useState } from 'react';
import { FormField, FormItem, FormLabel, FormControl, FormMessage, FormDescription } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { HelpCircle } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useFormContext } from '../context/FormProvider';

const TagInput = ({ fieldName, label, placeholder, maxLength = 30, maxTags = 10 }) => {
  const { form } = useFormContext();
  const [inputValue, setInputValue] = useState('');
  
  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      const currentTags = form.getValues(fieldName) || [];
      const newTag = inputValue.trim();
      
      if (newTag && currentTags.length < maxTags) {
        console.log(`Adding new tag: ${newTag} to ${fieldName}`);
        form.setValue(fieldName, [...currentTags, newTag]);
        setInputValue('');
      }
    }
  };

  return (
    <FormField
      control={form.control}
      name={fieldName}
      render={() => (
        <FormItem>
          <div className="flex items-center gap-2">
            <FormLabel className="text-deepGreen-700 font-medium">{label}</FormLabel>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <HelpCircle className="h-4 w-4 text-deepGreen-600 cursor-help" />
                </TooltipTrigger>
                <TooltipContent>
                  <p>Press Enter to add tags. Maximum {maxTags} tags allowed.</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          <FormControl>
            <Input
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={placeholder}
              maxLength={maxLength}
              className="bg-white/50 backdrop-blur-sm border-deepGreen-200 focus:border-deepGreen-400 transition-colors"
            />
          </FormControl>
          <FormDescription>
            Press Enter to add a tag. Maximum {maxTags} tags allowed.
          </FormDescription>
          <FormMessage />
        </FormItem>
      )}
    />
  );
};

export default TagInput;