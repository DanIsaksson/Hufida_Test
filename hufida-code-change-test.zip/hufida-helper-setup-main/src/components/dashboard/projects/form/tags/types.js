export const TAG_FIELDS = {
  TARGET_AUDIENCE: {
    name: 'target_audience',
    label: 'Target Audience',
    placeholder: 'Press Enter to add audience group',
    maxLength: 50,
    maxTags: 10
  },
  TAGS: {
    name: 'tags',
    label: 'Project Tags',
    placeholder: 'Press Enter to add project tag',
    maxLength: 30,
    maxTags: 15
  }
};