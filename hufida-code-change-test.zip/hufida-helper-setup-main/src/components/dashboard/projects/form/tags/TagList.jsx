import React from 'react';
import { Badge } from "@/components/ui/badge";
import { X } from 'lucide-react';
import { motion, AnimatePresence } from "framer-motion";

const badgeVariants = {
  initial: { opacity: 0, scale: 0.8 },
  animate: { opacity: 1, scale: 1 },
  exit: { opacity: 0, scale: 0.8, transition: { duration: 0.2 } }
};

const TagList = ({ tags = [], onRemove, variant = "secondary" }) => {
  console.log('Rendering TagList with tags:', tags);
  
  return (
    <div className="flex flex-wrap gap-2 mt-2">
      <AnimatePresence>
        {tags?.map((tag, index) => (
          <motion.div
            key={`${tag}-${index}`}
            variants={badgeVariants}
            initial="initial"
            animate="animate"
            exit="exit"
            layout
          >
            <Badge 
              variant={variant} 
              className="flex items-center gap-1 bg-deepGreen-50/80 backdrop-blur-sm text-deepGreen-700 hover:bg-deepGreen-100/80 transition-colors"
            >
              {tag}
              <X
                className="h-3 w-3 cursor-pointer hover:text-deepGreen-600"
                onClick={() => {
                  console.log('Removing tag:', tag, 'at index:', index);
                  onRemove(index);
                }}
              />
            </Badge>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
};

export default TagList;