import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ProjectSkeleton } from '../ui/skeleton-loader';
import { neuCardStyles } from '../../utils/styleUtils';
import { motion } from "framer-motion";
import { 
  BookOpen, 
  BarChart3, 
  Settings, 
  FolderPlus,
  MessageSquare,
  Users,
} from 'lucide-react';
import WelcomeHeader from './header/WelcomeHeader';
import StatsGrid from './stats/StatsGrid';
import QuickActions from './actions/QuickActions';
import TabContent from './tabs/TabContent';
import { usePartnerProfile } from '@/hooks/usePartnerProfile';
import { useActiveProject } from '@/hooks/useActiveProject';
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

const PartnerDashboard = () => {
  const { data: profile, isLoading: profileLoading, error: profileError } = usePartnerProfile();
  const { data: activeProject, isLoading: projectLoading, error: projectError } = useActiveProject(profile?.id);

  console.log('PartnerDashboard rendering:', { profile, activeProject, profileLoading, projectLoading });

  if (profileLoading || projectLoading) {
    return <ProjectSkeleton />;
  }

  if (profileError) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          Failed to load profile data. Please try again later.
        </AlertDescription>
      </Alert>
    );
  }

  const tabs = [
    { value: 'social', label: 'Social Feed', icon: Users, description: 'View community updates and interactions' },
    { value: 'content', label: 'Content Management', icon: BookOpen, description: 'Manage your content and documents' },
    { value: 'engagements', label: 'Engagements', icon: BarChart3, description: 'Track and manage project engagements' },
    { value: 'projects', label: 'Projects', icon: FolderPlus, description: 'Create and manage your projects' },
    { value: 'updates', label: 'Updates', icon: MessageSquare, description: 'View and post project updates' },
    { value: 'settings', label: 'Settings', icon: Settings, description: 'Configure dashboard settings' }
  ];

  const containerVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5,
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        type: "spring",
        stiffness: 100
      }
    }
  };

  return (
    <motion.div 
      className="space-y-8"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      <motion.div variants={itemVariants}>
        <WelcomeHeader profile={profile} />
      </motion.div>
      
      <motion.div variants={itemVariants}>
        <QuickActions />
      </motion.div>
      
      <motion.div variants={itemVariants}>
        <StatsGrid profile={profile} />
      </motion.div>

      <motion.div variants={itemVariants}>
        <Card className={`${neuCardStyles()} overflow-hidden bg-deepGreen-700/20 backdrop-blur-sm`}>
          <CardContent className="p-6">
            <Tabs defaultValue="social" className="w-full">
              <TabsList className="mb-4 flex flex-wrap gap-2 bg-deepGreen-700/20 p-2 rounded-lg">
                <TooltipProvider>
                  {tabs.map(({ value, label, icon: Icon, description }) => (
                    <Tooltip key={value}>
                      <TooltipTrigger asChild>
                        <motion.div
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          <TabsTrigger 
                            value={value} 
                            className="flex items-center gap-2 data-[state=active]:bg-deepGreen-600 data-[state=active]:text-white transition-all duration-300 hover:bg-deepGreen-500/50"
                          >
                            <Icon className="h-4 w-4" />
                            {label}
                          </TabsTrigger>
                        </motion.div>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>{description}</p>
                      </TooltipContent>
                    </Tooltip>
                  ))}
                </TooltipProvider>
              </TabsList>
              
              {tabs.map(({ value }) => (
                <TabsContent key={value} value={value}>
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <TabContent 
                      activeTab={value}
                      profile={profile}
                      activeProject={activeProject}
                    />
                  </motion.div>
                </TabsContent>
              ))}
            </Tabs>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
};

export default PartnerDashboard;