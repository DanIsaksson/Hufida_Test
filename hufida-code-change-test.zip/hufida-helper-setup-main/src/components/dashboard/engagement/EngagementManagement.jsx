import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from 'sonner';
import { Plus, Calendar } from 'lucide-react';
import { neuCardStyles, neuButtonStyles } from '../../../utils/styleUtils';

const EngagementManagement = ({ profile, isVolunteer = false }) => {
  const [newEngagement, setNewEngagement] = useState({
    title: '',
    description: '',
    engagement_type: 'volunteer',
    start_date: '',
    end_date: '',
  });
  const queryClient = useQueryClient();

  const { data: engagements, isLoading } = useQuery({
    queryKey: ['engagements', profile?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('engagements')
        .select('*')
        .eq(isVolunteer ? 'status' : 'creator_id', isVolunteer ? 'active' : profile?.id)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data;
    },
    enabled: !!profile?.id,
  });

  const createEngagement = useMutation({
    mutationFn: async (newEngagement) => {
      const { data, error } = await supabase
        .from('engagements')
        .insert([{ ...newEngagement, creator_id: profile.id }])
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['engagements']);
      toast.success('Engagement created successfully');
      setNewEngagement({
        title: '',
        description: '',
        engagement_type: 'volunteer',
        start_date: '',
        end_date: '',
      });
    },
    onError: (error) => {
      toast.error('Failed to create engagement: ' + error.message);
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    createEngagement.mutate(newEngagement);
  };

  if (isLoading) return <div>Loading...</div>;

  return (
    <div className="space-y-6">
      {!isVolunteer && (
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            placeholder="Title"
            value={newEngagement.title}
            onChange={(e) => setNewEngagement({ ...newEngagement, title: e.target.value })}
            required
          />
          <Textarea
            placeholder="Description"
            value={newEngagement.description}
            onChange={(e) => setNewEngagement({ ...newEngagement, description: e.target.value })}
            required
            className="min-h-[100px]"
          />
          <div className="grid grid-cols-2 gap-4">
            <Input
              type="datetime-local"
              value={newEngagement.start_date}
              onChange={(e) => setNewEngagement({ ...newEngagement, start_date: e.target.value })}
              required
            />
            <Input
              type="datetime-local"
              value={newEngagement.end_date}
              onChange={(e) => setNewEngagement({ ...newEngagement, end_date: e.target.value })}
              required
            />
          </div>
          <Button type="submit" className={neuButtonStyles()}>
            <Plus className="mr-2 h-4 w-4" /> Create Engagement
          </Button>
        </form>
      )}

      <div className="grid gap-4">
        {engagements?.map((engagement) => (
          <Card key={engagement.id} className={neuCardStyles()}>
            <CardContent className="p-4">
              <h3 className="text-lg font-semibold mb-2">{engagement.title}</h3>
              <p className="text-gray-600">{engagement.description}</p>
              <div className="mt-2 flex items-center gap-2 text-sm text-gray-500">
                <Calendar className="h-4 w-4" />
                <span>
                  {new Date(engagement.start_date).toLocaleDateString()} - 
                  {new Date(engagement.end_date).toLocaleDateString()}
                </span>
              </div>
              {isVolunteer && (
                <Button className={`${neuButtonStyles()} mt-4`}>
                  Apply for Engagement
                </Button>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default EngagementManagement;