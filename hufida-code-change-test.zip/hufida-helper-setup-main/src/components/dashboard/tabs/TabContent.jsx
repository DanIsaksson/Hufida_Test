import React from 'react';
import ContentManagement from '../content/ContentManagement';
import EngagementManagement from '../engagement/EngagementManagement';
import ProfileForm from '../../profile/ProfileForm';
import ProjectForm from '../projects/ProjectForm';
import ProjectUpdates from '../projects/updates/ProjectUpdates';
import SocialFeed from '../social/SocialFeed';
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";

const TabContent = ({ activeTab, profile, activeProject }) => {
  console.log('TabContent rendering with:', { activeTab, profile, activeProject });

  if (!profile) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          Profile data is not available. Please try refreshing the page.
        </AlertDescription>
      </Alert>
    );
  }

  const renderContent = () => {
    console.log('Rendering content for tab:', activeTab);
    
    switch (activeTab) {
      case "social":
        return <SocialFeed profile={profile} />;
      case "content":
        return <ContentManagement profile={profile} />;
      case "engagements":
        return <EngagementManagement profile={profile} />;
      case "projects":
        return <ProjectForm initialData={activeProject} />;
      case "updates":
        return activeProject ? (
          <ProjectUpdates projectId={activeProject.id} />
        ) : (
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              No active project found. Please create or activate a project first.
            </AlertDescription>
          </Alert>
        );
      case "settings":
        return (
          <div className="max-w-4xl mx-auto">
            <ProfileForm initialData={profile} isLoading={false} />
          </div>
        );
      default:
        console.log('Unknown tab:', activeTab);
        return null;
    }
  };

  return renderContent();
};

export default TabContent;