import React from 'react';
import { useAuth } from '../AuthProvider';
import { useNavigate, Outlet } from 'react-router-dom';
import { Card } from "@/components/ui/card";
import { supabase } from '../../lib/supabase';
import { useToast } from "@/components/ui/use-toast";
import { motion } from "framer-motion";
import { ScrollArea } from "@/components/ui/scroll-area";
import { neuCardStyles } from '../../utils/styleUtils';
import DashboardHeader from './header/DashboardHeader';

const DashboardLayout = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  console.log('DashboardLayout rendering with user:', user);

  if (!user) {
    console.log('No user found in DashboardLayout, redirecting to auth');
    navigate('/auth');
    return null;
  }

  const handleSignOut = async () => {
    try {
      await supabase.auth.signOut();
      toast({
        title: "Signed out",
        description: "You have been successfully signed out.",
      });
      navigate('/');
    } catch (error) {
      console.error('Error signing out:', error);
      toast({
        title: "Error",
        description: "Failed to sign out. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-deepGreen-800 to-deepGreen-600 p-4 md:p-8">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="max-w-7xl mx-auto"
      >
        <Card className={`${neuCardStyles({ elevation: "medium" })} backdrop-blur-sm bg-deepGreen-700/30`}>
          <div className="flex flex-col h-full">
            <DashboardHeader handleSignOut={handleSignOut} />
            
            <ScrollArea className="flex-1 p-6">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ type: "spring", stiffness: 100 }}
              >
                <Outlet />
              </motion.div>
            </ScrollArea>
          </div>
        </Card>
      </motion.div>
    </div>
  );
};

export default DashboardLayout;