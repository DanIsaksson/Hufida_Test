import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';

const calculateImpactScore = (content, reactions) => {
  const impactTerms = [
    'impact', 'sustainable', 'community', 'innovation', 'collaboration',
    'environment', 'social', 'change', 'improvement', 'progress',
    'initiative', 'development', 'solution', 'partnership', 'engagement'
  ];
  
  // Base score from content analysis
  const contentScore = impactTerms.reduce((acc, term) => {
    const regex = new RegExp(term, 'gi');
    const matches = (content.match(regex) || []).length;
    return acc + (matches * 5);
  }, 0);

  // Enhanced engagement score from reactions
  const likesWeight = 2;
  const commentsWeight = 3;
  const commentRelevanceWeight = 0.5;
  const commentImpactWeight = 0.5;

  const likes = reactions?.filter(r => r.reaction_type === 'like').length || 0;
  const comments = reactions?.filter(r => r.reaction_type === 'comment') || [];
  
  // Calculate average relevance and impact scores from comments
  const commentScores = comments.reduce((acc, comment) => {
    const metadata = comment.metadata || {};
    return {
      relevance: acc.relevance + (metadata.relevance_score || 50),
      impact: acc.impact + (metadata.impact_score || 50)
    };
  }, { relevance: 0, impact: 0 });

  const avgRelevance = comments.length ? commentScores.relevance / comments.length : 50;
  const avgImpact = comments.length ? commentScores.impact / comments.length : 50;

  // Combined engagement score
  const engagementScore = (likes * likesWeight) + 
    (comments.length * commentsWeight) +
    (avgRelevance * commentRelevanceWeight) +
    (avgImpact * commentImpactWeight);

  // Combine scores and normalize to 0-100 range
  const rawScore = Math.min(100, contentScore + engagementScore);
  return Math.max(0, rawScore);
};

export const useSocialFeed = () => {
  return useQuery({
    queryKey: ['social-feed'],
    queryFn: async () => {
      console.log('Fetching social feed data');
      
      // Fetch content items with author profiles and reaction counts
      const { data: contentItems, error: contentError } = await supabase
        .from('content_items')
        .select(`
          *,
          profiles:creator_id (
            full_name,
            avatar_url
          ),
          content_reactions (
            reaction_type,
            user_id,
            metadata
          )
        `)
        .eq('status', 'approved')
        .order('created_at', { ascending: false })
        .limit(10);

      if (contentError) {
        console.error('Error fetching content items:', contentError);
        throw contentError;
      }

      // Process and combine the feed items
      const processedContentItems = contentItems.map(item => ({
        ...item,
        type: 'content',
        metadata: {
          ...item.metadata,
          likes_count: item.content_reactions?.filter(r => r.reaction_type === 'like').length || 0,
          comments_count: item.content_reactions?.filter(r => r.reaction_type === 'comment').length || 0,
          comments: item.content_reactions?.filter(r => r.reaction_type === 'comment')
            .map(r => ({
              ...r.metadata,
              user_id: r.user_id,
              created_at: r.created_at
            })) || [],
          user_has_liked: item.content_reactions?.some(r => 
            r.reaction_type === 'like' && r.user_id === supabase.auth.getUser()?.id
          ) || false,
          impact_score: calculateImpactScore(item.content, item.content_reactions)
        }
      }));

      console.log('Processed feed data:', processedContentItems);
      return processedContentItems;
    },
    refetchInterval: 30000, // Refetch every 30 seconds
  });
};