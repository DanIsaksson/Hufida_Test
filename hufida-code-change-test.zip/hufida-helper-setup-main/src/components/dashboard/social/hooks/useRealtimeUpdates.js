import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useToast } from "@/hooks/use-toast";

export const useRealtimeUpdates = () => {
  const [realTimeUpdates, setRealTimeUpdates] = useState([]);
  const { toast } = useToast();

  useEffect(() => {
    console.log('Setting up real-time subscriptions');
    
    const channel = supabase.channel('social-feed-changes')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'content_items' },
        (payload) => {
          console.log('Received content_items change:', payload);
          if (payload.new.status === 'approved') {
            const newUpdate = { ...payload.new, type: 'content' };
            setRealTimeUpdates(prev => [newUpdate, ...prev]);
            toast({
              title: "New Content",
              description: `New content: ${payload.new.title}`,
            });
          }
        }
      )
      .on('postgres_changes',
        { event: '*', schema: 'public', table: 'project_updates' },
        (payload) => {
          console.log('Received project_updates change:', payload);
          const newUpdate = { ...payload.new, type: 'update' };
          setRealTimeUpdates(prev => [newUpdate, ...prev]);
          toast({
            title: "Project Update",
            description: `New update for project`,
          });
        }
      )
      .subscribe();

    return () => {
      console.log('Cleaning up real-time subscriptions');
      supabase.removeChannel(channel);
    };
  }, [toast]);

  return realTimeUpdates;
};