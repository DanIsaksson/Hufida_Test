import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Users } from 'lucide-react';
import { AnimatePresence } from "framer-motion";
import { neuCardStyles } from '../../../utils/styleUtils';
import { useSocialFeed } from './hooks/useSocialFeed';
import { useRealtimeUpdates } from './hooks/useRealtimeUpdates';
import FeedItem from './components/FeedItem';

const SocialFeed = () => {
  const { data: initialFeed = [], isLoading } = useSocialFeed();
  const realTimeUpdates = useRealtimeUpdates();

  // Combine initial feed with real-time updates and sort by date
  const combinedFeed = [...realTimeUpdates, ...(initialFeed || [])].sort(
    (a, b) => new Date(b.created_at) - new Date(a.created_at)
  );

  return (
    <ScrollArea className="h-[600px]">
      <div className="space-y-4 p-4">
        <Card className={`${neuCardStyles()} bg-deepGreen-700/30 backdrop-blur-sm`}>
          <CardHeader>
            <CardTitle className="text-lg font-semibold flex items-center gap-2 text-deepGreen-100">
              <Users className="h-5 w-5" />
              Community Updates
            </CardTitle>
          </CardHeader>
          <CardContent>
            <AnimatePresence mode="popLayout">
              {isLoading ? (
                <div className="text-center text-deepGreen-300">Loading updates...</div>
              ) : combinedFeed.length === 0 ? (
                <div className="text-center text-deepGreen-300">No updates yet</div>
              ) : (
                <div className="space-y-6">
                  {combinedFeed.map(item => (
                    <FeedItem key={item.id} item={item} />
                  ))}
                </div>
              )}
            </AnimatePresence>
          </CardContent>
        </Card>
      </div>
    </ScrollArea>
  );
};

export default SocialFeed;