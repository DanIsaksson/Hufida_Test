import React from 'react';
import { Slider } from "@/components/ui/slider";
import { motion } from "framer-motion";

const MetricSlider = ({ label, value, onChange, leftLabel, rightLabel }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 10 }}
      className="space-y-2"
    >
      <label className="block text-sm font-medium text-white/90">
        {label}
      </label>
      <Slider
        value={value}
        onValueChange={onChange}
        max={100}
        step={1}
        className="w-full h-2 bg-deepGreen-600/50 rounded-full"
      />
      <div className="flex items-center justify-between text-xs text-white/70">
        <span>{leftLabel}</span>
        <span>{rightLabel}</span>
      </div>
    </motion.div>
  );
};

export default MetricSlider;