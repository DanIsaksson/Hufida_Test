import React from 'react';
import { AnimatePresence } from "framer-motion";
import MetricSlider from './MetricSlider';

const ProgressiveSliders = ({ 
  relevanceValue,
  setRelevanceValue,
  impactValue,
  setImpactValue,
  showImpactSlider
}) => {
  return (
    <div className="space-y-6">
      <MetricSlider
        label="Content Relevance:"
        value={relevanceValue}
        onChange={setRelevanceValue}
        leftLabel="Low Relevance"
        rightLabel="High Relevance"
      />
      
      <AnimatePresence>
        {showImpactSlider && (
          <MetricSlider
            label="Potential Impact:"
            value={impactValue}
            onChange={setImpactValue}
            leftLabel="Low Impact"
            rightLabel="High Impact"
          />
        )}
      </AnimatePresence>
    </div>
  );
};

export default ProgressiveSliders;