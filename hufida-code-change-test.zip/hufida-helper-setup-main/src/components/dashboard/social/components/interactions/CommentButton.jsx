import React from 'react';
import { Button } from "@/components/ui/button";
import { MessageSquare } from 'lucide-react';
import { motion } from "framer-motion";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";
import CommentForm from './CommentForm';

const CommentButton = ({ commentsCount, onClick, itemId }) => {
  const [isOpen, setIsOpen] = React.useState(false);

  const handleOpenChange = (open) => {
    setIsOpen(open);
  };

  return (
    <>
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <motion.div 
              whileHover={{ scale: 1.05 }} 
              whileTap={{ scale: 0.95 }}
              className="relative"
            >
              <Button 
                variant="ghost" 
                size="sm" 
                className="flex items-center gap-2 text-deepGreen-300 hover:text-deepGreen-100 hover:bg-deepGreen-800/30 transition-all duration-300"
                onClick={() => setIsOpen(true)}
              >
                <MessageSquare className="h-4 w-4" />
                <span>Comment</span>
                {commentsCount > 0 && (
                  <Badge 
                    variant="secondary" 
                    className="ml-1 bg-deepGreen-600/50 hover:bg-deepGreen-600"
                  >
                    {commentsCount}
                  </Badge>
                )}
              </Button>
            </motion.div>
          </TooltipTrigger>
          <TooltipContent 
            side="bottom" 
            className="bg-deepGreen-700 text-deepGreen-100 border-deepGreen-600"
          >
            <p>Share your thoughts with impact sliders</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>

      <Dialog open={isOpen} onOpenChange={handleOpenChange}>
        <DialogContent className="bg-deepGreen-900 text-white border border-deepGreen-700 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-xl font-semibold text-white flex items-center gap-2">
              <MessageSquare className="h-5 w-5" />
              Add Your Comment
            </DialogTitle>
          </DialogHeader>
          <CommentForm itemId={itemId} onClose={() => setIsOpen(false)} />
        </DialogContent>
      </Dialog>
    </>
  );
};

export default CommentButton;