import React, { useState } from 'react';
import { TrendingUp } from 'lucide-react';
import { Progress } from "@/components/ui/progress";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { supabase } from '@/lib/supabase';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

const ImpactScore = ({ score = 0, itemId }) => {
  console.log('ImpactScore rendering with itemId:', itemId); // Debug log
  const [showRelevanceSlider, setShowRelevanceSlider] = useState(false);
  const [relevanceValue, setRelevanceValue] = useState([50]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const getImpactColor = (value) => {
    if (value >= 75) return 'text-emerald-500';
    if (value >= 50) return 'text-yellow-500';
    return 'text-deepGreen-400';
  };

  const handleRelevanceSubmit = async () => {
    if (!itemId) {
      console.error('No itemId provided to ImpactScore component');
      toast({
        title: "Error",
        description: "Cannot submit feedback at this time",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast({
          title: "Authentication required",
          description: "Please sign in to provide feedback",
          variant: "destructive",
        });
        return;
      }

      // Check for existing relevance feedback
      const { data: existingFeedback, error: checkError } = await supabase
        .from('content_reactions')
        .select('id')
        .eq('content_id', itemId)
        .eq('user_id', user.id)
        .eq('reaction_type', 'relevance')
        .maybeSingle();

      if (checkError) throw checkError;

      if (existingFeedback) {
        // Update existing feedback
        const { error: updateError } = await supabase
          .from('content_reactions')
          .update({
            metadata: {
              relevance_score: relevanceValue[0]
            }
          })
          .eq('id', existingFeedback.id);

        if (updateError) throw updateError;

        toast({
          title: "Feedback updated",
          description: "Your relevance score has been updated",
        });
      } else {
        // Insert new feedback
        const { error: insertError } = await supabase
          .from('content_reactions')
          .insert({
            content_id: itemId,
            user_id: user.id,
            reaction_type: 'relevance',
            metadata: {
              relevance_score: relevanceValue[0]
            }
          });

        if (insertError) throw insertError;

        toast({
          title: "Feedback submitted",
          description: "Thank you for your feedback",
        });
      }

      setShowRelevanceSlider(false);
    } catch (error) {
      console.error('Error submitting relevance feedback:', error);
      toast({
        title: "Error",
        description: "Failed to submit feedback. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const color = getImpactColor(score);

  return (
    <TooltipProvider>
      <div className="space-y-2">
        <div 
          className="flex items-center gap-2 px-2 cursor-pointer"
          onClick={() => setShowRelevanceSlider(!showRelevanceSlider)}
        >
          <TrendingUp className={`h-4 w-4 ${color}`} />
          <Progress 
            value={score} 
            className="h-1.5" 
            indicatorClassName={color}
          />
          <Tooltip>
            <TooltipTrigger asChild>
              <span className={`text-xs ${color}`}>
                {Math.round(score)}%
              </span>
            </TooltipTrigger>
            <TooltipContent className="bg-deepGreen-700 text-deepGreen-100 border-deepGreen-600">
              <div className="space-y-1">
                <p className="font-semibold">Impact Score: {Math.round(score)}%</p>
                <p className="text-xs opacity-90">Click to rate content relevance</p>
              </div>
            </TooltipContent>
          </Tooltip>
        </div>

        {showRelevanceSlider && (
          <div className="space-y-4 pt-4 border-t border-deepGreen-600/20">
            <div className="space-y-2">
              <label className="text-sm font-medium text-deepGreen-200">
                Rate Content Relevance:
              </label>
              <div className="flex items-center gap-4">
                <Slider
                  value={relevanceValue}
                  onValueChange={setRelevanceValue}
                  max={100}
                  step={1}
                  className="flex-1"
                />
                <span className="text-sm text-deepGreen-300 min-w-[3rem] text-right">
                  {relevanceValue[0]}%
                </span>
              </div>
              <div className="flex justify-between text-xs text-deepGreen-400">
                <span>Low Relevance</span>
                <span>High Relevance</span>
              </div>
            </div>
            <Button
              onClick={handleRelevanceSubmit}
              disabled={isSubmitting}
              className="w-full bg-deepGreen-600 hover:bg-deepGreen-500"
            >
              {isSubmitting ? "Submitting..." : "Submit Feedback"}
            </Button>
          </div>
        )}
      </div>
    </TooltipProvider>
  );
};

export default ImpactScore;