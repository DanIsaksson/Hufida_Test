import React from 'react';
import { Button } from "@/components/ui/button";
import { Heart } from 'lucide-react';
import { motion, AnimatePresence } from "framer-motion";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";

const LikeButton = ({ isLiked, likes, isLoading, onClick }) => {
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <motion.div 
            whileHover={{ scale: 1.05 }} 
            whileTap={{ scale: 0.95 }}
            className="relative"
          >
            <Button 
              variant="ghost" 
              size="sm" 
              className={`
                flex items-center gap-2 
                ${isLiked ? 'text-rose-500 bg-rose-500/10' : 'text-deepGreen-300'} 
                hover:text-deepGreen-100 hover:bg-deepGreen-800/30 
                transition-all duration-300 relative group
              `}
              onClick={onClick}
              disabled={isLoading}
            >
              <AnimatePresence mode="wait">
                <motion.div
                  key={isLiked ? 'liked' : 'unliked'}
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0.8, opacity: 0 }}
                  transition={{ type: "spring", stiffness: 500, damping: 30 }}
                  className="relative"
                >
                  <Heart className={`h-4 w-4 ${isLiked ? 'fill-current' : ''}`} />
                  {isLiked && (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: [1.5, 0] }}
                      transition={{ duration: 0.3 }}
                      className="absolute inset-0 text-rose-500"
                    >
                      <Heart className="h-4 w-4 fill-current" />
                    </motion.div>
                  )}
                </motion.div>
              </AnimatePresence>
              
              <Badge 
                variant={isLiked ? "secondary" : "outline"} 
                className={`
                  transition-all duration-300
                  ${isLiked ? 'bg-rose-500/20 text-rose-400' : 'bg-deepGreen-800/30 text-deepGreen-300'}
                `}
              >
                {likes}
              </Badge>

              {isLoading && (
                <motion.div
                  className="absolute inset-0 bg-deepGreen-800/30 rounded flex items-center justify-center"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                >
                  <div className="w-4 h-4 border-2 border-deepGreen-300 border-t-transparent rounded-full animate-spin" />
                </motion.div>
              )}
            </Button>
          </motion.div>
        </TooltipTrigger>
        <TooltipContent 
          side="bottom" 
          className="bg-deepGreen-700 text-deepGreen-100 border-deepGreen-600"
        >
          <p>{isLiked ? 'Unlike this post' : 'Like this post'}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};

export default LikeButton;