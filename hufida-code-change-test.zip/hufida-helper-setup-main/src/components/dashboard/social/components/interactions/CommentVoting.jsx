import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { ThumbsUp, ThumbsDown } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { supabase } from '@/lib/supabase';
import { useQueryClient } from '@tanstack/react-query';

const CommentVoting = ({ commentId, initialVotes = { up: 0, down: 0 }, userVote = null }) => {
  const [isVoting, setIsVoting] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const handleVote = async (voteType) => {
    setIsVoting(true);
    try {
      const user = await supabase.auth.getUser();
      if (!user.data?.user) {
        toast({
          title: "Authentication required",
          description: "Please sign in to vote",
          variant: "destructive",
        });
        return;
      }

      // If user has already voted the same way, remove their vote
      if (userVote === voteType) {
        const { error } = await supabase
          .from('content_reactions')
          .delete()
          .eq('content_id', commentId)
          .eq('user_id', user.data.user.id)
          .eq('reaction_type', `vote_${voteType}`);

        if (error) throw error;
      } else {
        // Remove any existing vote first
        if (userVote) {
          await supabase
            .from('content_reactions')
            .delete()
            .eq('content_id', commentId)
            .eq('user_id', user.data.user.id)
            .eq('reaction_type', `vote_${userVote}`);
        }

        // Add new vote
        const { error } = await supabase
          .from('content_reactions')
          .insert({
            content_id: commentId,
            user_id: user.data.user.id,
            reaction_type: `vote_${voteType}`,
            metadata: { vote_type: voteType }
          });

        if (error) throw error;
      }

      queryClient.invalidateQueries(['social-feed']);
      
      toast({
        title: "Vote recorded",
        description: userVote === voteType ? "Vote removed" : "Your vote has been recorded",
      });
    } catch (error) {
      console.error('Error voting:', error);
      toast({
        title: "Error",
        description: "Failed to record vote",
        variant: "destructive",
      });
    } finally {
      setIsVoting(false);
    }
  };

  return (
    <div className="flex items-center gap-2">
      <Button
        variant="ghost"
        size="sm"
        disabled={isVoting}
        onClick={() => handleVote('up')}
        className={`text-deepGreen-300 hover:text-deepGreen-100 ${
          userVote === 'up' ? 'bg-deepGreen-700/50' : ''
        }`}
      >
        <ThumbsUp className="h-4 w-4 mr-1" />
        <span>{initialVotes.up}</span>
      </Button>
      <Button
        variant="ghost"
        size="sm"
        disabled={isVoting}
        onClick={() => handleVote('down')}
        className={`text-deepGreen-300 hover:text-deepGreen-100 ${
          userVote === 'down' ? 'bg-deepGreen-700/50' : ''
        }`}
      >
        <ThumbsDown className="h-4 w-4 mr-1" />
        <span>{initialVotes.down}</span>
      </Button>
    </div>
  );
};

export default CommentVoting;