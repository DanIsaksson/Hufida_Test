import React from 'react';
import { Textarea } from "@/components/ui/textarea";
import { neuTextareaStyles } from '../../../../../../utils/styleUtils';

const BaseCommentForm = ({ comment, setComment }) => {
  return (
    <div>
      <label htmlFor="comment" className="block text-sm font-medium mb-2 text-white/90">
        Your Comment:
      </label>
      <Textarea
        id="comment"
        value={comment}
        onChange={(e) => setComment(e.target.value)}
        placeholder="Share your thoughts..."
        className={`${neuTextareaStyles()} bg-deepGreen-800/50 text-white placeholder-white/50 min-h-[120px] border-deepGreen-600`}
      />
    </div>
  );
};

export default BaseCommentForm;