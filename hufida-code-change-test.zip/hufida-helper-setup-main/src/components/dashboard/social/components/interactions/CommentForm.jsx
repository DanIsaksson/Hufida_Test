import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Plus, Minus, Loader2 } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { supabase } from '@/lib/supabase';
import { useQueryClient } from '@tanstack/react-query';
import BaseCommentForm from './comment/BaseCommentForm';
import ProgressiveSliders from './comment/ProgressiveSliders';

const CommentForm = ({ itemId, onClose }) => {
  const [comment, setComment] = useState('');
  const [relevanceValue, setRelevanceValue] = useState([50]);
  const [impactValue, setImpactValue] = useState([50]);
  const [showImpactSlider, setShowImpactSlider] = useState(false);
  const [customSliders, setCustomSliders] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Show impact slider when relevance has been adjusted
  useEffect(() => {
    if (relevanceValue[0] !== 50) {
      setShowImpactSlider(true);
    }
  }, [relevanceValue]);

  const handleAddCustomSlider = () => {
    if (!showImpactSlider) {
      toast({
        title: "Please rate relevance first",
        description: "Share your thoughts on content relevance before adding custom metrics",
        variant: "default",
      });
      return;
    }
    
    setCustomSliders([...customSliders, { 
      label: '', 
      value: [50] 
    }]);
  };

  const handleRemoveCustomSlider = (index) => {
    setCustomSliders(customSliders.filter((_, i) => i !== index));
  };

  const handleCustomSliderLabelChange = (index, label) => {
    const updatedSliders = [...customSliders];
    updatedSliders[index].label = label;
    setCustomSliders(updatedSliders);
  };

  const handleCustomSliderValueChange = (index, value) => {
    const updatedSliders = [...customSliders];
    updatedSliders[index].value = value;
    setCustomSliders(updatedSliders);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!comment.trim()) {
      toast({
        title: "Comment required",
        description: "Please enter your comment",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    try {
      const user = await supabase.auth.getUser();
      if (!user.data?.user) {
        toast({
          title: "Authentication required",
          description: "Please sign in to comment",
          variant: "destructive",
        });
        return;
      }

      // Check if user has already commented
      const { data: existingComment } = await supabase
        .from('content_reactions')
        .select('id')
        .eq('content_id', itemId)
        .eq('user_id', user.data.user.id)
        .eq('reaction_type', 'comment')
        .single();

      // Prepare metadata
      const metadata = {
        comment: comment.trim(),
        relevance_score: relevanceValue[0],
        impact_score: showImpactSlider ? impactValue[0] : null,
        custom_metrics: customSliders.reduce((acc, slider) => ({
          ...acc,
          [slider.label]: slider.value[0]
        }), {})
      };

      if (existingComment) {
        // Update existing comment
        const { error: updateError } = await supabase
          .from('content_reactions')
          .update({ metadata })
          .eq('id', existingComment.id);

        if (updateError) throw updateError;

        toast({
          title: "Comment updated",
          description: "Your comment has been updated successfully",
        });
      } else {
        // Insert new comment
        const { error: insertError } = await supabase
          .from('content_reactions')
          .insert({
            content_id: itemId,
            user_id: user.data.user.id,
            reaction_type: 'comment',
            metadata
          });

        if (insertError) throw insertError;

        toast({
          title: "Comment added",
          description: "Your comment has been posted successfully",
        });
      }

      queryClient.invalidateQueries(['social-feed']);
      onClose();
    } catch (error) {
      console.error('Error posting comment:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to post comment",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <BaseCommentForm 
        comment={comment}
        setComment={setComment}
      />
      
      <div className="space-y-6">
        <ProgressiveSliders
          relevanceValue={relevanceValue}
          setRelevanceValue={setRelevanceValue}
          impactValue={impactValue}
          setImpactValue={setImpactValue}
          showImpactSlider={showImpactSlider}
        />

        {showImpactSlider && customSliders.map((slider, index) => (
          <div key={index} className="space-y-2 border-t border-deepGreen-600/20 pt-4">
            <div className="flex items-center justify-between">
              <input
                type="text"
                placeholder="Metric name..."
                value={slider.label}
                onChange={(e) => handleCustomSliderLabelChange(index, e.target.value)}
                className="bg-transparent border-b border-deepGreen-600/20 text-white placeholder-deepGreen-400 focus:outline-none"
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => handleRemoveCustomSlider(index)}
                className="text-deepGreen-300 hover:text-deepGreen-100"
              >
                <Minus className="h-4 w-4" />
              </Button>
            </div>
            <MetricSlider
              label={slider.label || "Custom Metric"}
              value={slider.value}
              onChange={(value) => handleCustomSliderValueChange(index, value)}
              leftLabel="Low"
              rightLabel="High"
            />
          </div>
        ))}

        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={handleAddCustomSlider}
          className="w-full mt-4 text-deepGreen-300 hover:text-deepGreen-100 border-deepGreen-600"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add Custom Metric
        </Button>
      </div>

      <div className="flex justify-end gap-4">
        <Button
          type="button"
          variant="ghost"
          onClick={onClose}
          className="text-deepGreen-300 hover:text-deepGreen-100"
        >
          Cancel
        </Button>
        <Button
          type="submit"
          disabled={isSubmitting}
          className="bg-deepGreen-600 hover:bg-deepGreen-500"
        >
          {isSubmitting ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Posting...
            </>
          ) : (
            "Post Comment"
          )}
        </Button>
      </div>
    </form>
  );
};

export default CommentForm;