import React, { useState } from 'react';
import { useToast } from "@/hooks/use-toast";
import { supabase } from '@/lib/supabase';
import { useQueryClient } from '@tanstack/react-query';
import LikeButton from './interactions/LikeButton';
import CommentButton from './interactions/CommentButton';
import ShareButton from './interactions/ShareButton';
import ImpactScore from './interactions/ImpactScore';

const FeedInteractions = ({ 
  itemId, 
  itemType, 
  initialLikes = 0, 
  initialComments = 0, 
  hasLiked = false, 
  impactScore = 0 
}) => {
  const [likes, setLikes] = useState(initialLikes);
  const [isLiked, setIsLiked] = useState(hasLiked);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const handleLike = async () => {
    console.log('Handling like for itemId:', itemId);
    setIsLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast({
          title: "Authentication required",
          description: "Please sign in to like content",
          variant: "destructive",
        });
        return;
      }

      // First check if user has already liked this content
      const { data: existingLike, error: checkError } = await supabase
        .from('content_reactions')
        .select('id')
        .eq('content_id', itemId)
        .eq('user_id', user.id)
        .eq('reaction_type', 'like')
        .maybeSingle();

      console.log('Existing like check:', { existingLike, checkError });

      if (checkError) {
        throw checkError;
      }

      if (existingLike) {
        // Unlike - delete the reaction
        const { error: deleteError } = await supabase
          .from('content_reactions')
          .delete()
          .eq('id', existingLike.id);

        if (deleteError) throw deleteError;

        setLikes(prev => prev - 1);
        setIsLiked(false);
        
        toast({
          title: "Like removed",
          description: "You've removed your like from this post",
        });
      } else {
        // Like - insert new reaction
        const { error: insertError } = await supabase
          .from('content_reactions')
          .insert({
            content_id: itemId,
            user_id: user.id,
            reaction_type: 'like'
          });

        if (insertError) throw insertError;

        setLikes(prev => prev + 1);
        setIsLiked(true);
        
        toast({
          title: "Post liked",
          description: "You've liked this post",
        });
      }

      queryClient.invalidateQueries(['social-feed']);

    } catch (error) {
      console.error('Error updating like:', error);
      toast({
        title: "Error",
        description: "Failed to update like status. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-6 mt-4 border-t border-deepGreen-600/20 pt-4">
        <LikeButton 
          isLiked={isLiked}
          likes={likes}
          isLoading={isLoading}
          onClick={handleLike}
        />
        <CommentButton 
          commentsCount={initialComments}
          itemId={itemId}
        />
        <ShareButton />
      </div>
      <ImpactScore score={impactScore} />
    </div>
  );
};

export default FeedInteractions;