import React from 'react';
import { motion } from "framer-motion";
import { FileText, Bell } from 'lucide-react';
import { Card } from "@/components/ui/card";
import FeedInteractions from './FeedInteractions';
import FeedItemHeader from './feed/FeedItemHeader';
import FeedItemContent from './feed/FeedItemContent';

const FeedItem = ({ item }) => {
  const author = item.profiles || {};
  const title = item.type === 'content' ? item.title : `Update: ${item.projects?.title || 'Project'}`;
  const content = item.type === 'content' ? item.content : item.description;
  const icon = item.type === 'content' ? FileText : Bell;
  
  const likesCount = item.metadata?.likes_count || 0;
  const commentsCount = item.metadata?.comments_count || 0;
  const hasLiked = item.metadata?.user_has_liked || false;
  const impactScore = item.metadata?.impact_score || 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="mb-6"
    >
      <Card className="bg-deepGreen-700/10 backdrop-blur-sm p-6 border border-deepGreen-600/20 shadow-xl hover:shadow-2xl transition-all duration-300">
        <div className="flex items-start gap-4">
          <div className="flex-1 space-y-4">
            <FeedItemHeader 
              author={author}
              title={title}
              item={item}
              icon={icon}
              impactScore={impactScore}
            />
            
            <FeedItemContent 
              content={content}
              title={title}
              imageUrl={item.metadata?.image_url}
            />

            <FeedInteractions 
              itemId={item.id}
              itemType={item.type}
              initialLikes={likesCount}
              initialComments={commentsCount}
              hasLiked={hasLiked}
              impactScore={impactScore}
            />
          </div>
        </div>
      </Card>
    </motion.div>
  );
};

export default FeedItem;