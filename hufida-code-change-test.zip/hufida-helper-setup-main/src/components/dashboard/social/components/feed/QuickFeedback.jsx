import React, { useState } from 'react';
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { ChevronDown } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { supabase } from '@/lib/supabase';

const QuickFeedback = ({ itemId }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [quickRelevance, setQuickRelevance] = useState([50]);
  const { toast } = useToast();

  const handleQuickComment = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast({
          title: "Authentication required",
          description: "Please sign in to comment",
          variant: "destructive",
        });
        return;
      }

      // First check if user already has a quick feedback comment
      const { data: existingComment, error: checkError } = await supabase
        .from('content_reactions')
        .select('id')
        .eq('content_id', itemId)
        .eq('user_id', user.id)
        .eq('reaction_type', 'comment')
        .maybeSingle();

      if (checkError) throw checkError;

      if (existingComment) {
        // Update existing comment
        const { error: updateError } = await supabase
          .from('content_reactions')
          .update({
            metadata: {
              relevance_score: quickRelevance[0],
              comment: "Quick relevance feedback"
            }
          })
          .eq('id', existingComment.id);

        if (updateError) throw updateError;

        toast({
          title: "Feedback updated",
          description: "Your relevance score has been updated",
        });
      } else {
        // Insert new comment
        const { error: insertError } = await supabase
          .from('content_reactions')
          .insert({
            content_id: itemId,
            user_id: user.id,
            reaction_type: 'comment',
            metadata: {
              relevance_score: quickRelevance[0],
              comment: "Quick relevance feedback"
            }
          });

        if (insertError) throw insertError;

        toast({
          title: "Feedback submitted",
          description: "Your relevance score has been recorded",
        });
      }
      
      setQuickRelevance([50]); // Reset slider
    } catch (error) {
      console.error('Error submitting quick comment:', error);
      toast({
        title: "Error",
        description: "Failed to submit feedback. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="mt-4">
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center justify-between text-deepGreen-300 hover:text-deepGreen-100"
      >
        <span>Quick Feedback</span>
        <ChevronDown className={`h-4 w-4 transition-transform duration-200 ${isExpanded ? 'rotate-180' : ''}`} />
      </Button>

      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="pt-4 space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-deepGreen-200">
                  Content Relevance:
                </label>
                <div className="flex items-center gap-4">
                  <Slider
                    value={quickRelevance}
                    onValueChange={setQuickRelevance}
                    max={100}
                    step={1}
                    className="flex-1"
                  />
                  <span className="text-sm text-deepGreen-300 min-w-[3rem] text-right">
                    {quickRelevance[0]}%
                  </span>
                </div>
                <div className="flex justify-between text-xs text-deepGreen-400">
                  <span>Low Relevance</span>
                  <span>High Relevance</span>
                </div>
              </div>
              <Button
                onClick={handleQuickComment}
                className="w-full bg-deepGreen-600 hover:bg-deepGreen-500"
              >
                Submit Feedback
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default QuickFeedback;