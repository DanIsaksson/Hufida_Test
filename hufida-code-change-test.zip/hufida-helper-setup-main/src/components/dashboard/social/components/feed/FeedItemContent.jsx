import React from 'react';
import { motion } from "framer-motion";
import { ExternalLink } from 'lucide-react';

const FeedItemContent = ({ content, title, imageUrl }) => {
  return (
    <div className="prose prose-invert max-w-none">
      <p className="text-deepGreen-200 leading-relaxed whitespace-pre-wrap">{content}</p>
      
      {imageUrl && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="mt-4 relative group"
        >
          <img
            src={imageUrl}
            alt={title}
            className="rounded-lg w-full object-cover max-h-96 border border-deepGreen-600/20"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-lg flex items-end justify-end p-4">
            <a
              href={imageUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-white flex items-center gap-1 text-sm hover:text-primary transition-colors"
            >
              <ExternalLink className="h-4 w-4" />
              View full size
            </a>
          </div>
        </motion.div>
      )}
    </div>
  );
};

export default FeedItemContent;