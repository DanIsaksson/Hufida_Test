import React from 'react';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { FileText, Bell, Calendar, TrendingUp } from 'lucide-react';
import { format } from 'date-fns';
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

const FeedItemHeader = ({ author, title, item, icon: IconComponent, impactScore }) => {
  return (
    <div className="flex justify-between items-start mb-2">
      <div>
        <h4 className="font-semibold text-lg text-deepGreen-100 mb-1">{author?.full_name}</h4>
        <div className="flex items-center gap-2 text-sm text-deepGreen-300">
          <IconComponent className="h-4 w-4" />
          <p className="font-medium">{title}</p>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger>
              <Badge 
                variant={impactScore > 50 ? "default" : "secondary"}
                className="flex items-center gap-1"
              >
                <TrendingUp className="h-3 w-3" />
                <span>{Math.round(impactScore)}</span>
              </Badge>
            </TooltipTrigger>
            <TooltipContent>
              <p>Impact Score: Measures content relevance and engagement</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger>
              <div className="flex items-center text-xs text-deepGreen-400 bg-deepGreen-800/30 px-3 py-1 rounded-full">
                <Calendar className="h-3 w-3 mr-1" />
                <span>{format(new Date(item.created_at), 'PPp')}</span>
              </div>
            </TooltipTrigger>
            <TooltipContent>
              <p>Posted on {format(new Date(item.created_at), 'PPpp')}</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>
    </div>
  );
};

export default FeedItemHeader;