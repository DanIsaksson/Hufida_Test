import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import ContentManagement from './content/ContentManagement';
import EngagementManagement from './engagement/EngagementManagement';
import DashboardLayout from './DashboardLayout';

const VolunteerDashboard = () => {
  const { data: profile } = useQuery({
    queryKey: ['profile'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .single();
      
      if (error) throw error;
      return data;
    },
  });

  return (
    <DashboardLayout>
      <h1 className="text-3xl font-bold mb-6 text-deepGreen-800">Volunteer Dashboard</h1>
      <Tabs defaultValue="engagements" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="engagements">Available Engagements</TabsTrigger>
          <TabsTrigger value="contributions">My Contributions</TabsTrigger>
        </TabsList>
        <TabsContent value="engagements">
          <EngagementManagement profile={profile} isVolunteer={true} />
        </TabsContent>
        <TabsContent value="contributions">
          <ContentManagement profile={profile} isVolunteer={true} />
        </TabsContent>
      </Tabs>
    </DashboardLayout>
  );
};

export default VolunteerDashboard;