import React, { useState } from 'react';
import { Upload, File, Loader2 } from 'lucide-react';
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { useAuth } from '@/components/AuthProvider';

const FileUpload = ({ onUploadComplete, onError }) => {
  const [uploading, setUploading] = useState(false);
  const { user } = useAuth();

  console.log('FileUpload rendering with user:', user?.id);

  const handleFileChange = async (event) => {
    try {
      const file = event.target.files[0];
      if (!file) return;

      // Instead of uploading immediately, pass the file to the parent component
      console.log('File selected:', file);
      onUploadComplete(file);
      
      // Clear the input
      event.target.value = '';
      
    } catch (error) {
      console.error('Error handling file:', error);
      if (onError) onError(error);
      else toast.error(error.message || 'Failed to handle file');
    }
  };

  return (
    <div className="space-y-4">
      <div className="border-2 border-dashed border-deepGreen-200 rounded-lg p-6 hover:border-deepGreen-400 transition-colors">
        <Input
          type="file"
          onChange={handleFileChange}
          disabled={uploading}
          className="file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 
                   file:text-sm file:font-semibold file:bg-deepGreen-50 file:text-deepGreen-700 
                   hover:file:bg-deepGreen-100 cursor-pointer"
        />
        <p className="mt-2 text-sm text-deepGreen-600 text-center">
          Drag and drop your files here, or click to select files
        </p>
      </div>
      {uploading && (
        <div className="flex items-center justify-center gap-2 text-sm text-deepGreen-600 bg-deepGreen-50 p-2 rounded-md">
          <Loader2 className="h-4 w-4 animate-spin" />
          Uploading your file...
        </div>
      )}
    </div>
  );
};

export default FileUpload;