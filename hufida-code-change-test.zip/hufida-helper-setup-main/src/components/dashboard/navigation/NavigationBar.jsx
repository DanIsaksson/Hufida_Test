import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { motion } from "framer-motion";
import NavigationItem from './NavigationItem';
import { NAVIGATION_ITEMS } from './NavigationItems';

const NavigationBar = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const handleNavigation = (path) => {
    console.log('Navigating to:', path);
    navigate(path);
  };

  return (
    <nav className="flex flex-wrap gap-2">
      {NAVIGATION_ITEMS.map((item) => (
        <NavigationItem 
          key={item.value} 
          item={item}
          isActive={location.pathname.includes(item.value)}
          onClick={() => handleNavigation(item.path)}
        />
      ))}
    </nav>
  );
};

export default NavigationBar;