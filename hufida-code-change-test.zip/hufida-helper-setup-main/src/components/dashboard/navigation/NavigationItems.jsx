import { 
  Globe, 
  FileText, 
  HandshakeIcon, 
  FolderPlus, 
  MessageSquare, 
  Settings 
} from 'lucide-react';

export const NAVIGATION_ITEMS = [
  {
    icon: Globe,
    label: 'Social Feed',
    value: 'social',
    description: 'View community updates and interactions',
    primary: true,
    path: '/dashboard/partner/social'
  },
  {
    icon: FileText,
    label: 'Content',
    value: 'content',
    description: 'Manage your content and documents',
    highlight: true,
    path: '/dashboard/partner/content'
  },
  {
    icon: HandshakeIcon,
    label: 'Engagements',
    value: 'engagements',
    description: 'Track and manage project engagements',
    highlight: true,
    path: '/dashboard/partner/engagements'
  },
  {
    icon: FolderPlus,
    label: 'Projects',
    value: 'projects',
    description: 'Create and manage your projects',
    path: '/dashboard/partner/projects'
  },
  {
    icon: MessageSquare,
    label: 'Updates',
    value: 'updates',
    description: 'View and post project updates',
    path: '/dashboard/partner/updates'
  },
  {
    icon: Settings,
    label: 'Settings',
    value: 'settings',
    description: 'Configure dashboard preferences',
    path: '/dashboard/partner/settings'
  }
];