import React from 'react';
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

const NavigationItem = ({ item, isActive, onClick }) => {
  const { icon: Icon, label, description, primary, highlight } = item;

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="relative"
          >
            <Button
              variant={primary ? "default" : "ghost"}
              className={`
                group relative flex items-center space-x-2 w-full
                ${primary 
                  ? 'bg-deepGreen-500 hover:bg-deepGreen-400 text-white shadow-lg' 
                  : isActive
                    ? 'bg-deepGreen-600/50 text-white'
                    : highlight 
                      ? 'text-deepGreen-100 hover:bg-deepGreen-600/50 hover:text-white border border-deepGreen-400/50' 
                      : 'text-deepGreen-100 hover:bg-deepGreen-600/50 hover:text-white'
                }
                transition-all duration-300
              `}
              onClick={onClick}
            >
              <Icon className={`h-4 w-4 ${primary ? 'animate-pulse' : ''}`} />
              <span>{label}</span>
              
              {highlight && (
                <span className="absolute -top-1 -right-1 flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-deepGreen-300 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-deepGreen-400"></span>
                </span>
              )}
            </Button>
          </motion.div>
        </TooltipTrigger>
        <TooltipContent>
          <p>{description}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};

export default NavigationItem;