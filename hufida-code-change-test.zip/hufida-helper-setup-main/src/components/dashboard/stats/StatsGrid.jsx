import React from 'react';
import StatCard from './StatCard';
import { Users, Target, Calendar, TrendingUp } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';

const StatsGrid = ({ profile }) => {
  const { data: engagementStats } = useQuery({
    queryKey: ['engagement-stats', profile?.id],
    queryFn: async () => {
      console.log('Fetching engagement stats for profile:', profile?.id);
      const { data: engagements, error } = await supabase
        .from('engagements')
        .select('*')
        .eq('creator_id', profile?.id);
      
      if (error) throw error;
      return engagements?.length || 0;
    },
    enabled: !!profile?.id,
  });

  const stats = [
    {
      title: "Total Engagements",
      value: engagementStats || "0",
      description: "Active community engagements",
      icon: Users,
      trend: "+2.5%"
    },
    {
      title: "Project Impact",
      value: "89%",
      description: "Overall project success rate",
      icon: Target,
      trend: "+4.1%"
    },
    {
      title: "Upcoming Events",
      value: "3",
      description: "Events in next 30 days",
      icon: Calendar,
      trend: "0%"
    },
    {
      title: "Growth Rate",
      value: "23%",
      description: "Monthly engagement growth",
      icon: TrendingUp,
      trend: "+1.2%"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat, index) => (
        <StatCard key={index} {...stat} />
      ))}
    </div>
  );
};

export default StatsGrid;