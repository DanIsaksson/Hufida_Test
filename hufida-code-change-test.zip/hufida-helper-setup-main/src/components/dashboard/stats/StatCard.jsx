import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";
import { neuCardStyles } from '../../../utils/styleUtils';

const StatCard = ({ title, value, description, icon: Icon, trend }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className={`${neuCardStyles()} hover:shadow-lg transition-all duration-300`}>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="text-deepGreen-300">
              {Icon && <Icon className="h-8 w-8" />}
            </div>
            {trend && (
              <span className={`text-sm font-medium ${trend.startsWith('+') ? 'text-green-500' : 'text-gray-500'}`}>
                {trend}
              </span>
            )}
          </div>
          <div className="space-y-1">
            <h3 className="text-2xl font-bold text-deepGreen-100">{value}</h3>
            <p className="text-sm font-medium text-deepGreen-300">{title}</p>
            <p className="text-xs text-deepGreen-400">{description}</p>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default StatCard;