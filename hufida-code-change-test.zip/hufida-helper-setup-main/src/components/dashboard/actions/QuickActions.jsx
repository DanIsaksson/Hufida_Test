import React from 'react';
import { useNavigate } from 'react-router-dom';
import QuickActionCard from './QuickActionCard';
import { FileText, HandshakeIcon, FolderPlus } from 'lucide-react';
import { toast } from "sonner";

const QUICK_ACTIONS = [
  {
    title: "New Project",
    description: "Start creating a new project",
    icon: FolderPlus,
    color: "bg-deepGreen-600",
    path: '/dashboard/partner/projects/new',
    isPrimary: true
  },
  {
    title: "Content Upload",
    description: "Upload and manage content",
    icon: FileText,
    color: "bg-deepGreen-500",
    path: '/dashboard/partner/content/new',
    isNew: true
  },
  {
    title: "Manage Engagements",
    description: "View and track engagements",
    icon: HandshakeIcon,
    color: "bg-deepGreen-400",
    path: '/dashboard/partner/engagements'
  }
];

const QuickActions = () => {
  const navigate = useNavigate();

  const handleActionClick = (action) => {
    console.log('QuickAction clicked:', action);
    if (action.path) {
      navigate(action.path);
      toast.success(`Navigating to ${action.title}`);
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {QUICK_ACTIONS.map((action, index) => (
        <QuickActionCard 
          key={index}
          {...action}
          onClick={() => handleActionClick(action)}
        />
      ))}
    </div>
  );
};

export default QuickActions;