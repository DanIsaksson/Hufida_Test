import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";
import { ArrowRight } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { neuCardStyles } from '../../../utils/styleUtils';

const QuickActionCard = ({ title, description, icon: Icon, color, onClick, isNew, isPrimary }) => {
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            onClick={onClick}
            className="relative group cursor-pointer"
          >
            <Card className={`${neuCardStyles()} hover:shadow-lg transition-all duration-300 transform hover:scale-102 ${isPrimary ? 'ring-2 ring-deepGreen-400' : ''}`}>
              <CardContent className="flex items-center space-x-4 p-6 relative">
                <div className={`${color} p-3 rounded-lg transition-colors duration-300 group-hover:bg-opacity-80`}>
                  <Icon className="h-5 w-5" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-lg group-hover:text-deepGreen-100 transition-colors duration-300">{title}</h3>
                  <p className="text-sm text-deepGreen-300 group-hover:text-deepGreen-200 transition-colors duration-300">{description}</p>
                </div>
                <motion.div 
                  className="absolute right-4 opacity-0 group-hover:opacity-100 transition-all duration-300"
                  initial={{ x: -10 }}
                  animate={{ x: 0 }}
                >
                  <ArrowRight className="h-5 w-5 text-deepGreen-300" />
                </motion.div>
              </CardContent>
            </Card>
            {(isNew || isPrimary) && (
              <div className="absolute -top-2 -right-2 z-10">
                {isNew ? (
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-deepGreen-500 text-white">
                    New
                  </span>
                ) : (
                  <span className="flex h-3 w-3">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-deepGreen-300 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-deepGreen-400"></span>
                  </span>
                )}
              </div>
            )}
          </motion.div>
        </TooltipTrigger>
        <TooltipContent>
          <p>Click to {title.toLowerCase()}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};

export default QuickActionCard;