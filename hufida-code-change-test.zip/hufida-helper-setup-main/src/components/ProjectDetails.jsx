import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { motion } from "framer-motion";
import { FileText, Users, BookOpen, MessageCircle } from 'lucide-react';
import ProjectOverview from './project-details/overview/ProjectOverview';
import ProjectVisionImpact from './project-details/ProjectVisionImpact';
import ProjectFeatures from './project-details/features/ProjectFeatures';
import ProjectTeam from './project-details/team/ProjectTeam';
import KnowledgeResources from './project-details/knowledge/KnowledgeResources';
import ProjectDiscussions from './project-details/discussions/ProjectDiscussions';

const ProjectDetails = ({ project }) => {
  const [activeTab, setActiveTab] = useState("overview");

  console.log('Rendering ProjectDetails with project:', project);

  return (
    <TooltipProvider>
      <ScrollArea className="h-screen">
        <div className="container mx-auto mt-8 px-4 sm:px-6 lg:px-8 pb-16">
          <motion.h1 
            className="text-4xl font-bold mb-6 text-center text-deepGreen-800"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            {project.title}
          </motion.h1>
          
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full mb-8">
            <TabsList className="grid w-full grid-cols-4 neu-card p-1 bg-deepGreen-100">
              <TabsTrigger 
                value="overview" 
                className="flex items-center gap-2 neu-button text-deepGreen-700 data-[state=active]:bg-deepGreen-200"
              >
                <FileText className="h-4 w-4" />
                Overview
              </TabsTrigger>
              <TabsTrigger 
                value="team" 
                className="flex items-center gap-2 neu-button text-deepGreen-700 data-[state=active]:bg-deepGreen-200"
              >
                <Users className="h-4 w-4" />
                Team
              </TabsTrigger>
              <TabsTrigger 
                value="knowledge" 
                className="flex items-center gap-2 neu-button text-deepGreen-700 data-[state=active]:bg-deepGreen-200"
              >
                <BookOpen className="h-4 w-4" />
                Knowledge
              </TabsTrigger>
              <TabsTrigger 
                value="discussions" 
                className="flex items-center gap-2 neu-button text-deepGreen-700 data-[state=active]:bg-deepGreen-200"
              >
                <MessageCircle className="h-4 w-4" />
                Discussions
              </TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <ProjectOverview project={project} />
                <ProjectVisionImpact project={project} />
              </div>
              <ProjectFeatures features={project.features} />
            </TabsContent>

            <TabsContent value="team">
              <ProjectTeam teamMembers={project.team_members} />
            </TabsContent>

            <TabsContent value="knowledge">
              <KnowledgeResources projectId={project.id} />
            </TabsContent>

            <TabsContent value="discussions">
              <ProjectDiscussions projectId={project.id} />
            </TabsContent>
          </Tabs>

          <motion.div
            className="mt-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
          >
            <Tooltip>
              <TooltipTrigger asChild>
                <Button className="w-full neu-button bg-deepGreen-600 hover:bg-deepGreen-700 text-white">
                  Get Involved with {project.title}
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Learn how you can contribute to this project</p>
              </TooltipContent>
            </Tooltip>
          </motion.div>
        </div>
      </ScrollArea>
    </TooltipProvider>
  );
};

export default ProjectDetails;