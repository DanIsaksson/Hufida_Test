import React from 'react';
import { motion } from "framer-motion";
import { Globe, Database, Users, Shield, Layers, Settings } from 'lucide-react';
import FeatureSection from './FeatureSection';
import { responsiveGridStyles } from '../../utils/styleUtils';

const features = [
  {
    icon: Globe,
    title: "Global Impact",
    description: "Making a difference across Africa through innovative development initiatives",
    items: [
      "Sustainable development projects in multiple African countries",
      "Cross-cultural collaboration and knowledge sharing",
      "Local community empowerment and capacity building",
      "Environmental conservation and climate action"
    ]
  },
  {
    icon: Database,
    title: "Digital Innovation",
    description: "Leveraging technology for sustainable development",
    items: [
      "Advanced data management and analytics",
      "Digital literacy programs and training",
      "Smart city initiatives and infrastructure",
      "Technology-driven agricultural solutions"
    ]
  },
  {
    icon: Users,
    title: "Community Engagement",
    description: "Building strong partnerships with local communities",
    items: [
      "Participatory project planning and implementation",
      "Community-led initiatives and ownership",
      "Skills development and training programs",
      "Social impact assessment and monitoring"
    ]
  },
  {
    icon: Shield,
    title: "Sustainable Solutions",
    description: "Creating lasting positive change through innovative approaches",
    items: [
      "Renewable energy implementation",
      "Waste management and recycling programs",
      "Water conservation and sanitation",
      "Sustainable agriculture practices"
    ]
  },
  {
    icon: Layers,
    title: "Knowledge Exchange",
    description: "Facilitating learning and sharing of best practices",
    items: [
      "Research and documentation of success stories",
      "Training workshops and seminars",
      "Online learning platforms and resources",
      "Partnership with academic institutions"
    ]
  },
  {
    icon: Settings,
    title: "Project Management",
    description: "Ensuring efficient and effective project implementation",
    items: [
      "Comprehensive project planning and monitoring",
      "Risk assessment and mitigation strategies",
      "Stakeholder engagement and communication",
      "Impact evaluation and reporting"
    ]
  }
];

const FeaturesGrid = () => {
  return (
    <motion.section 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="mt-24"
    >
      <h2 className="text-4xl font-bold mb-12 text-center text-white">Our Features</h2>
      <div className={`${responsiveGridStyles({ cols: 2 })} gap-8`}>
        {features.map((feature, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
          >
            <FeatureSection {...feature} />
          </motion.div>
        ))}
      </div>
    </motion.section>
  );
};

export default FeaturesGrid;