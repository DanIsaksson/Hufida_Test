import React from 'react';
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Lightbulb, Users, Target, Rocket } from 'lucide-react';
import { neuCardStyles } from '../../utils/styleUtils';
import ExpandableSection from './ExpandableSection';

const Methodology = () => {
  const methodologies = [
    {
      title: "Community-Centered Approach",
      icon: Users,
      steps: [
        "Extensive community consultation and needs assessment",
        "Participatory decision-making processes",
        "Local capacity building and knowledge transfer",
        "Sustainable resource management training"
      ]
    },
    {
      title: "Innovation Framework",
      icon: Lightbulb,
      steps: [
        "Technology integration for sustainable solutions",
        "Research-based intervention design",
        "Adaptive management strategies",
        "Continuous improvement through feedback loops"
      ]
    },
    {
      title: "Impact Measurement",
      icon: Target,
      steps: [
        "Comprehensive baseline studies",
        "Regular monitoring and evaluation",
        "Data-driven decision making",
        "Transparent reporting mechanisms"
      ]
    },
    {
      title: "Scaling Strategy",
      icon: Rocket,
      steps: [
        "Modular program design for replication",
        "Cross-sector partnership development",
        "Knowledge sharing platforms",
        "Resource optimization frameworks"
      ]
    }
  ];

  return (
    <motion.section
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      className="mt-24 mb-16 px-4"
    >
      <h2 className="text-4xl font-bold mb-8 text-center text-white">Our Methodology</h2>
      <div className="space-y-6 max-w-6xl mx-auto">
        {methodologies.map((method, idx) => (
          <ExpandableSection 
            key={idx} 
            title={method.title}
            defaultExpanded={idx === 0}
          >
            <Card className={`${neuCardStyles({ elevation: "low" })} bg-deepGreen-800/50`}>
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <method.icon className="h-8 w-8 text-deepGreen-300 mr-4" />
                  <h3 className="text-xl font-semibold text-white">{method.title}</h3>
                </div>
                <ul className="space-y-3">
                  {method.steps.map((step, stepIdx) => (
                    <motion.li
                      key={stepIdx}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: stepIdx * 0.1 }}
                      className="flex items-center text-deepGreen-100"
                    >
                      <span className="h-2 w-2 bg-deepGreen-300 rounded-full mr-3" />
                      {step}
                    </motion.li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </ExpandableSection>
        ))}
      </div>
    </motion.section>
  );
};

export default Methodology;