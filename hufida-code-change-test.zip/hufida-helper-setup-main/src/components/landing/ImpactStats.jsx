import React from 'react';
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { neuCardStyles } from '../../utils/styleUtils';

const ImpactStats = () => {
  const stats = [
    { value: '500K+', label: 'Lives Impacted' },
    { value: '50+', label: 'Active Projects' },
    { value: '20+', label: 'Countries Reached' },
    { value: '100+', label: 'Partner Organizations' }
  ];

  return (
    <motion.section 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      className="mt-28 mb-24"
    >
      <Card className={`${neuCardStyles({ elevation: "medium" })} bg-gradient-to-br from-deepGreen-700/90 to-deepGreen-600/90 backdrop-blur-sm border-deepGreen-500/20`}>
        <CardContent className="p-12">
          <h2 className="text-4xl font-bold mb-12 text-center text-white">Our Impact</h2>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="text-center"
              >
                <p className="text-5xl font-bold mb-3 bg-gradient-to-r from-deepGreen-300 to-deepGreen-100 text-transparent bg-clip-text">
                  {stat.value}
                </p>
                <p className="text-xl text-deepGreen-50/90">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>
    </motion.section>
  );
};

export default ImpactStats;