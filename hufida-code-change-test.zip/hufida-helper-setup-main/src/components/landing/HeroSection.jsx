import React from 'react';
import { motion } from "framer-motion";
import { Link } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { ArrowRight } from 'lucide-react';

const HeroSection = () => {
  return (
    <section className="relative mb-16 text-center p-16 sm:p-24 rounded-2xl overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-[#1A1F2C] via-[#2C1F3D] to-[#3D1F2C] opacity-90" />
      
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, ease: "easeOut" }}
        className="relative z-10 flex flex-col items-center justify-center min-h-[70vh]"
      >
        <h1 className="text-6xl sm:text-7xl md:text-8xl font-bold mb-10 leading-tight tracking-tight">
          Empowering Africa's
          <span className="bg-gradient-to-r from-[#9b87f5] to-[#D6BCFA] text-transparent bg-clip-text"> Future</span>
        </h1>
        <p className="text-xl sm:text-2xl md:text-3xl mb-14 max-w-4xl mx-auto text-[#C8C8C9] leading-relaxed">
          HUFIDA is at the forefront of innovative development and humanitarian efforts across Africa. Join us in creating lasting, sustainable change for millions.
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-8">
          <Button 
            asChild 
            size="lg" 
            className="bg-[#9b87f5] hover:bg-[#7E69AB] text-white min-w-[220px] group transform hover:scale-105 transition-all duration-300"
          >
            <Link to="/about" className="flex items-center gap-3 text-lg">
              Our Mission
              <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </Link>
          </Button>
          <Button 
            asChild 
            variant="outline" 
            size="lg" 
            className="text-[#D6BCFA] border-[#9b87f5] hover:bg-[#9b87f5]/20 min-w-[220px] group transform hover:scale-105 transition-all duration-300"
          >
            <Link to="/donate" className="flex items-center gap-3 text-lg">
              Support Our Cause
              <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </Link>
          </Button>
        </div>
      </motion.div>
      
      <motion.div
        className="absolute inset-0 z-0 opacity-20"
        initial={{ opacity: 0, scale: 1.1 }}
        animate={{ opacity: 0.15, scale: 1 }}
        transition={{ duration: 1.5 }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-[#1A1F2C]/80 to-[#2C1F3D]/80" />
        <img
          src="/hero-image.jpg"
          alt="HUFIDA in action"
          className="w-full h-full object-cover"
        />
      </motion.div>
    </section>
  );
};

export default HeroSection;