import React, { useState } from 'react';
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { ChevronDown } from 'lucide-react';
import { neuCardStyles } from '../../utils/styleUtils';

const ExpandableSection = ({ title, children, defaultExpanded = false }) => {
  const [isExpanded, setIsExpanded] = useState(defaultExpanded);

  return (
    <Card className={`${neuCardStyles({ elevation: "medium" })} bg-gradient-to-br from-deepGreen-700/90 to-deepGreen-600/90 backdrop-blur-sm border-deepGreen-500/20`}>
      <CardContent className="p-6">
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="w-full flex items-center justify-between text-xl font-semibold text-white group"
        >
          <span className="text-left">{title}</span>
          <motion.div
            initial={false}
            animate={{ rotate: isExpanded ? 180 : 0 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="flex items-center justify-center w-8 h-8 rounded-full bg-deepGreen-600/50 group-hover:bg-deepGreen-500/50 transition-colors"
          >
            <ChevronDown className="h-5 w-5 transition-transform" />
          </motion.div>
        </button>
        <AnimatePresence initial={false}>
          {isExpanded && (
            <motion.div
              key="content"
              initial="collapsed"
              animate="expanded"
              exit="collapsed"
              variants={{
                expanded: {
                  opacity: 1,
                  height: "auto",
                  marginTop: 16,
                  transition: {
                    height: {
                      duration: 0.3,
                      ease: "easeOut"
                    },
                    opacity: {
                      duration: 0.2,
                      ease: "easeOut"
                    }
                  }
                },
                collapsed: {
                  opacity: 0,
                  height: 0,
                  marginTop: 0,
                  transition: {
                    height: {
                      duration: 0.3,
                      ease: "easeIn"
                    },
                    opacity: {
                      duration: 0.2,
                      ease: "easeIn"
                    }
                  }
                }
              }}
              className="overflow-hidden will-change-[height]"
              style={{ pointerEvents: isExpanded ? "auto" : "none" }}
            >
              <div className="text-deepGreen-50 space-y-4">
                {children}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </CardContent>
    </Card>
  );
};

export default ExpandableSection;