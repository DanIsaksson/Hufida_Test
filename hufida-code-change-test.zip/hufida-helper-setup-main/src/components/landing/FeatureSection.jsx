import React from 'react';
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Check } from 'lucide-react';
import { neuCardStyles } from '../../utils/styleUtils';

const FeatureSection = ({ icon: Icon, title, description, items }) => (
  <Card className={`${neuCardStyles({ elevation: "medium" })} bg-white/5 backdrop-blur-sm border-deepGreen-100/20`}>
    <CardHeader>
      <CardTitle className="flex items-center gap-2 text-2xl">
        <Icon className="h-8 w-8 text-deepGreen-400" />
        <span>{title}</span>
      </CardTitle>
    </CardHeader>
    <CardContent>
      <p className="mb-4 text-lg text-deepGreen-100">{description}</p>
      <ul className="space-y-2">
        {items.map((item, index) => (
          <motion.li
            key={index}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="flex items-center gap-2"
          >
            <Check className="h-5 w-5 text-green-500" />
            <span>{item}</span>
          </motion.li>
        ))}
      </ul>
    </CardContent>
  </Card>
);

export default FeatureSection;