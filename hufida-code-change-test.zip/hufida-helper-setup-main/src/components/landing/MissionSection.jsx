import React from 'react';
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Globe, Heart, Star } from 'lucide-react';
import { neuCardStyles } from '../../utils/styleUtils';

const MissionSection = () => {
  const missions = [
    {
      icon: <Globe className="h-10 w-10 text-deepGreen-300" />,
      title: "Global Impact",
      description: "Creating sustainable change across Africa through innovative development initiatives"
    },
    {
      icon: <Heart className="h-10 w-10 text-deepGreen-300" />,
      title: "Community First",
      description: "Empowering local communities through participatory development and capacity building"
    },
    {
      icon: <Star className="h-10 w-10 text-deepGreen-300" />,
      title: "Innovation",
      description: "Leveraging technology and creative solutions to address development challenges"
    }
  ];

  return (
    <section className="mt-28 mb-24">
      <motion.h2 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
        className="text-5xl font-bold mb-16 text-center text-white"
      >
        Our Mission
      </motion.h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
        {missions.map((mission, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: index * 0.2 }}
          >
            <Card className={`${neuCardStyles({ elevation: "medium" })} h-full bg-gradient-to-br from-deepGreen-700/90 to-deepGreen-600/90 backdrop-blur-sm border-deepGreen-500/20 transform hover:scale-105 transition-all duration-300`}>
              <CardContent className="p-8 flex flex-col items-center text-center">
                <div className="mb-6 p-4 rounded-full bg-deepGreen-800/50 backdrop-blur-sm">
                  {mission.icon}
                </div>
                <h3 className="text-2xl font-semibold mb-4 text-white">{mission.title}</h3>
                <p className="text-lg text-deepGreen-50/90">{mission.description}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </section>
  );
};

export default MissionSection;