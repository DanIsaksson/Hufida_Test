import React from 'react';
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { neuCardStyles } from '../../utils/styleUtils';
import ExpandableSection from './ExpandableSection';

const DetailedStats = () => {
  const impactDetails = [
    {
      category: "Environmental Impact",
      stats: [
        { metric: "Renewable Energy Projects", value: "25+", description: "Solar and wind installations" },
        { metric: "Waste Reduction", value: "30%", description: "Average reduction in targeted areas" },
        { metric: "Water Conservation", value: "500K+", description: "Liters saved monthly" }
      ]
    },
    {
      category: "Community Development",
      stats: [
        { metric: "Skills Training", value: "10,000+", description: "People trained in digital literacy" },
        { metric: "Job Creation", value: "1,000+", description: "New employment opportunities" },
        { metric: "Community Projects", value: "50+", description: "Local initiatives supported" }
      ]
    },
    {
      category: "Innovation & Technology",
      stats: [
        { metric: "Digital Solutions", value: "15+", description: "Custom platforms developed" },
        { metric: "Tech Adoption", value: "85%", description: "Community technology adoption rate" },
        { metric: "Innovation Labs", value: "5", description: "Research and development centers" }
      ]
    }
  ];

  return (
    <motion.section
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      className="mt-24 mb-16 px-4"
    >
      <h2 className="text-4xl font-bold mb-8 text-center text-white">Detailed Impact Analysis</h2>
      <div className="space-y-6 max-w-6xl mx-auto">
        {impactDetails.map((category, idx) => (
          <ExpandableSection 
            key={idx} 
            title={category.category}
            defaultExpanded={idx === 0}
          >
            <Card className={`${neuCardStyles({ elevation: "low" })} bg-deepGreen-800/50`}>
              <CardContent className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {category.stats.map((stat, statIdx) => (
                    <motion.div
                      key={statIdx}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: statIdx * 0.1 }}
                      className="text-center p-4 rounded-lg bg-deepGreen-700/30 backdrop-blur-sm"
                    >
                      <p className="text-3xl font-bold mb-2 bg-gradient-to-r from-deepGreen-300 to-deepGreen-100 text-transparent bg-clip-text">
                        {stat.value}
                      </p>
                      <p className="text-lg font-semibold mb-1 text-white">{stat.metric}</p>
                      <p className="text-sm text-deepGreen-200">{stat.description}</p>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </ExpandableSection>
        ))}
      </div>
    </motion.section>
  );
};

export default DetailedStats;