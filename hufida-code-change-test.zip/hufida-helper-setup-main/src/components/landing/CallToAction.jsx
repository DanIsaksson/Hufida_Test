import React from 'react';
import { motion } from "framer-motion";
import { Link } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight } from 'lucide-react';
import { neuCardStyles, neuButtonStyles } from '../../utils/styleUtils';

const CallToAction = () => {
  return (
    <motion.section 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      className="mt-28 mb-24"
    >
      <Card className={`${neuCardStyles({ elevation: "high" })} bg-gradient-to-br from-deepGreen-700/90 to-deepGreen-600/90 backdrop-blur-sm border-deepGreen-500/20 transform hover:scale-[1.02] transition-all duration-300`}>
        <CardContent className="p-16 text-center">
          <h2 className="text-4xl sm:text-5xl font-bold mb-6 text-white">Ready to Make a Difference?</h2>
          <p className="text-xl sm:text-2xl mb-12 text-deepGreen-50/90 max-w-3xl mx-auto">
            Join us in our mission to create sustainable change across Africa
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-6">
            <Button 
              asChild
              size="lg"
              className={`${neuButtonStyles({ variant: "primary", size: "lg" })} group transform hover:scale-105 transition-all duration-300`}
            >
              <Link to="/projects" className="flex items-center gap-3 text-lg">
                Explore Projects
                <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Link>
            </Button>
            <Button 
              asChild
              variant="outline"
              size="lg"
              className={`${neuButtonStyles({ variant: "outline", size: "lg" })} group transform hover:scale-105 transition-all duration-300 border-2`}
            >
              <Link to="/about" className="flex items-center gap-3 text-lg">
                Learn More
                <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.section>
  );
};

export default CallToAction;