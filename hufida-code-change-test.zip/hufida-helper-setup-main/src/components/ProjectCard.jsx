import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { getStatusColor, truncateText, neuCardStyles, neuButtonStyles } from '../utils/styleUtils';
import { CalendarRange, Users, Target } from 'lucide-react';

const ProjectCard = ({ project, onSuggestDirection }) => {
  console.log('Rendering ProjectCard with project:', project);

  const projectStatus = project?.project_status || 'draft';

  return (
    <motion.div
      whileHover={{ scale: 1.03 }}
      whileTap={{ scale: 0.98 }}
      transition={{ type: "spring", stiffness: 300 }}
    >
      <Card 
        className={`
          ${neuCardStyles({ elevation: "medium" })} 
          bg-gradient-to-br from-deepGreen-50 to-deepGreen-100 
          overflow-hidden cursor-pointer 
          hover:shadow-lg transition-all duration-300
          h-full
        `}
      >
        <CardHeader className="pb-2 bg-deepGreen-200 bg-opacity-30">
          <div className="flex justify-between items-start mb-2">
            <CardTitle className="text-xl font-bold text-deepGreen-800 group-hover:text-deepGreen-600 transition-colors">
              {project?.title || 'Untitled Project'}
            </CardTitle>
            <Badge 
              className={`${getStatusColor(projectStatus)} text-sm animate-in fade-in-50`} 
              aria-label={`Project status: ${projectStatus}`}
            >
              {projectStatus}
            </Badge>
          </div>
          <p className="text-sm font-medium text-deepGreen-600">{project?.category || 'Uncategorized'}</p>
        </CardHeader>
        <CardContent className="flex-grow flex flex-col justify-between p-4 space-y-4">
          <div>
            <p className="mb-4 text-deepGreen-700">{truncateText(project?.description || 'No description available', 150)}</p>
            
            <div className="grid grid-cols-1 gap-2 text-sm text-deepGreen-600">
              {project?.start_date && (
                <div className="flex items-center gap-2">
                  <CalendarRange className="h-4 w-4" />
                  <span>Started: {new Date(project.start_date).toLocaleDateString()}</span>
                </div>
              )}
              {project?.target_audience && project.target_audience.length > 0 && (
                <div className="flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  <span>Target: {project.target_audience.join(', ')}</span>
                </div>
              )}
              {project?.impact && (
                <div className="flex items-center gap-2">
                  <Target className="h-4 w-4" />
                  <span>{truncateText(project.impact, 70)}</span>
                </div>
              )}
            </div>
          </div>

          <div className="flex justify-between mt-auto gap-2">
            <Button 
              asChild 
              className={`${neuButtonStyles({ variant: "secondary", size: "sm" })} hover:scale-105 transition-transform`}
            >
              <Link 
                to={`/projects/${project?.id}`}
                aria-label={`Learn more about ${project?.title || 'this project'}`}
                className="flex items-center gap-2"
              >
                Learn More
              </Link>
            </Button>
            <Button 
              onClick={() => onSuggestDirection(project)} 
              className={`${neuButtonStyles({ variant: "primary", size: "sm" })} hover:scale-105 transition-transform`}
              aria-label={`Suggest direction for ${project?.title || 'this project'}`}
            >
              Suggest Direction
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default ProjectCard;