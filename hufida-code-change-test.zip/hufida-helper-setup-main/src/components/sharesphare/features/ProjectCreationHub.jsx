import React from 'react';
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FolderPlus, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const ProjectCreationHub = () => {
  console.log('ProjectCreationHub rendering');
  const navigate = useNavigate();

  return (
    <motion.div
      variants={{
        hidden: { opacity: 0, y: 20 },
        visible: { opacity: 1, y: 0 }
      }}
      initial="hidden"
      animate="visible"
      transition={{ delay: 0.3 }}
    >
      <Card className="bg-deepGreen-600/50 hover:bg-deepGreen-600/60 transition-colors">
        <CardHeader>
          <CardTitle className="text-deepGreen-100 flex items-center">
            <FolderPlus className="mr-2 h-5 w-5" />
            Project Creation Hub
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-deepGreen-200 mb-6">
            Initiate new projects and collaborate with the community. Share your ideas and get feedback from potential partners.
          </p>
          <div className="space-y-4">
            <Button 
              variant="default" 
              size="lg"
              onClick={() => navigate('/project-creation')}
              className="w-full bg-deepGreen-600 hover:bg-deepGreen-500 text-white transition-colors group"
            >
              <span className="flex items-center gap-2">
                <FolderPlus className="h-5 w-5" />
                Start New Project
                <motion.span
                  className="inline-block"
                  animate={{ x: [0, 4, 0] }}
                  transition={{ repeat: Infinity, duration: 1.5 }}
                >
                  <ArrowRight className="h-5 w-5" />
                </motion.span>
              </span>
            </Button>
            <Button 
              variant="outline" 
              className="w-full text-deepGreen-100 border-deepGreen-400 hover:bg-deepGreen-500/20"
            >
              View Project Guidelines
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default ProjectCreationHub;