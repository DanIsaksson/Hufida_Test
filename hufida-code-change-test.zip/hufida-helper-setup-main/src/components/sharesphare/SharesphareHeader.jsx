import React from 'react';
import { motion } from "framer-motion";
import { Share2 } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { useNavigate } from 'react-router-dom';

const SharesphareHeader = () => {
  const navigate = useNavigate();

  return (
    <motion.div 
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-6 border-b border-border/40 bg-deepGreen-700/20 backdrop-blur-sm"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Share2 className="h-8 w-8 text-deepGreen-300" />
          <div>
            <h1 className="text-2xl font-bold text-deepGreen-100">Sharesphare Platform</h1>
            <p className="mt-1 text-deepGreen-200">Connect, Share, and Collaborate with the Community</p>
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <Button 
            variant="outline" 
            className="text-deepGreen-100 hover:bg-deepGreen-600/50"
            onClick={() => navigate('/projects')}
          >
            Explore Projects
          </Button>
        </div>
      </div>
    </motion.div>
  );
};

export default SharesphareHeader;