import React from 'react';
import { TabsContent } from "@/components/ui/tabs";
import CommunityFeedTab from './tabs/CommunityFeedTab';
import KnowledgeExchangeTab from './tabs/KnowledgeExchangeTab';
import ProjectsTab from './tabs/ProjectsTab';
import ImpactTrackingTab from './tabs/ImpactTrackingTab';
import MessagesTab from './tabs/MessagesTab';

const SharesphareContent = () => {
  console.log('SharesphareContent rendering');

  return (
    <div className="mt-6 space-y-6">
      <TabsContent value="social" className="space-y-4">
        <CommunityFeedTab />
      </TabsContent>

      <TabsContent value="knowledge" className="space-y-4">
        <KnowledgeExchangeTab />
      </TabsContent>

      <TabsContent value="projects" className="space-y-4">
        <ProjectsTab />
      </TabsContent>

      <TabsContent value="impact" className="space-y-4">
        <ImpactTrackingTab />
      </TabsContent>

      <TabsContent value="messages" className="space-y-4">
        <MessagesTab />
      </TabsContent>
    </div>
  );
};

export default SharesphareContent;