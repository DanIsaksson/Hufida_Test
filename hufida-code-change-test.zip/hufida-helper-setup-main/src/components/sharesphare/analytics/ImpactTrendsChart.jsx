import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { neuCardStyles } from '@/utils/styleUtils';

const ImpactTrendsChart = () => {
  const { data: trends, isLoading } = useQuery({
    queryKey: ['impact-trends'],
    queryFn: async () => {
      console.log('Fetching impact trends');
      const { data: impacts, error } = await supabase
        .from('project_impacts')
        .select(`
          *,
          project:projects(title, created_at)
        `)
        .order('created_at', { ascending: true });

      if (error) throw error;
      console.log('Fetched impact trends:', impacts);

      // Group by month and category
      const monthlyData = impacts.reduce((acc, impact) => {
        const date = new Date(impact.created_at);
        const monthYear = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
        const category = impact.category || 'Other';

        if (!acc[monthYear]) {
          acc[monthYear] = { month: monthYear };
        }

        if (!acc[monthYear][category]) {
          acc[monthYear][category] = 0;
        }

        acc[monthYear][category] += Number(impact.current_value) || 0;
        return acc;
      }, {});

      return Object.values(monthlyData);
    }
  });

  if (isLoading) {
    return <div>Loading impact trends...</div>;
  }

  return (
    <Card className={`${neuCardStyles()} bg-deepGreen-700/20 mt-6`}>
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-deepGreen-100">Impact Trends Over Time</CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="h-[400px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={trends}>
              <CartesianGrid strokeDasharray="3 3" stroke="#2F4F4F" />
              <XAxis 
                dataKey="month" 
                stroke="#E0E7E9"
                tick={{ fill: '#E0E7E9' }}
              />
              <YAxis 
                stroke="#E0E7E9"
                tick={{ fill: '#E0E7E9' }}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1a2e35',
                  border: '1px solid #2F4F4F',
                  borderRadius: '8px'
                }}
              />
              <Legend />
              <Bar dataKey="Environmental" fill="#059669" />
              <Bar dataKey="Social" fill="#0284c7" />
              <Bar dataKey="Economic" fill="#7c3aed" />
              <Bar dataKey="Other" fill="#9ca3af" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};

export default ImpactTrendsChart;