import React from 'react';
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { BarChart3, Users, Target, Globe } from 'lucide-react';
import { neuCardStyles } from '@/utils/styleUtils';

const ImpactMetricsGrid = () => {
  const { data: metrics, isLoading } = useQuery({
    queryKey: ['impact-metrics'],
    queryFn: async () => {
      console.log('Fetching impact metrics');
      const { data: projectImpacts, error } = await supabase
        .from('project_impacts')
        .select(`
          *,
          project:projects(title)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      console.log('Fetched impact metrics:', projectImpacts);
      return projectImpacts;
    }
  });

  const aggregateMetrics = (metrics) => {
    if (!metrics) return {};
    return metrics.reduce((acc, metric) => {
      const category = metric.category || 'Other';
      if (!acc[category]) {
        acc[category] = {
          total: 0,
          count: 0,
          average: 0,
          unit: metric.unit
        };
      }
      acc[category].total += Number(metric.current_value) || 0;
      acc[category].count += 1;
      acc[category].average = acc[category].total / acc[category].count;
      return acc;
    }, {});
  };

  const aggregatedData = aggregateMetrics(metrics);

  if (isLoading) {
    return <div>Loading impact metrics...</div>;
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {Object.entries(aggregatedData).map(([category, data], index) => (
        <motion.div
          key={category}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: index * 0.1 }}
        >
          <Card className={`${neuCardStyles()} bg-deepGreen-700/20 hover:bg-deepGreen-700/30 transition-colors`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-2 bg-deepGreen-600/20 rounded-lg">
                  {category === 'Environmental' && <Globe className="h-6 w-6 text-deepGreen-300" />}
                  {category === 'Social' && <Users className="h-6 w-6 text-deepGreen-300" />}
                  {category === 'Economic' && <BarChart3 className="h-6 w-6 text-deepGreen-300" />}
                  {category === 'Other' && <Target className="h-6 w-6 text-deepGreen-300" />}
                </div>
              </div>
              <h3 className="text-xl font-semibold text-deepGreen-100 mb-2">{category}</h3>
              <div className="space-y-2">
                <div>
                  <p className="text-sm text-deepGreen-300">Total Impact</p>
                  <p className="text-2xl font-bold text-deepGreen-100">
                    {data.total.toLocaleString()} {data.unit}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-deepGreen-300">Average per Project</p>
                  <p className="text-lg font-semibold text-deepGreen-200">
                    {data.average.toLocaleString()} {data.unit}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
};

export default ImpactMetricsGrid;