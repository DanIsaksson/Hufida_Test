import React, { useState } from 'react';
import { motion } from "framer-motion";
import { FileText, Image, Video, Music, File, ExternalLink, AudioWaveform } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { supabase } from '@/lib/supabase';

const FeedItemContent = ({ content, metadata }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const file = metadata?.file;

  console.log('FeedItemContent rendering with file:', file);

  const getFilePreview = () => {
    if (!file) return null;

    const fileUrl = supabase.storage
      .from('project_files')
      .getPublicUrl(file.file_path)
      .data.publicUrl;

    if (file.file_type?.startsWith('image/')) {
      return (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="mt-4 relative group rounded-lg overflow-hidden bg-deepGreen-800/20"
        >
          <img
            src={fileUrl}
            alt="Shared image"
            className="w-full h-auto max-h-[500px] object-contain"
          />
          <motion.div 
            initial={{ opacity: 0 }}
            whileHover={{ opacity: 1 }}
            className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent flex items-end justify-end p-4"
          >
            <a
              href={fileUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-white flex items-center gap-1 text-sm hover:text-deepGreen-300 transition-colors"
            >
              <ExternalLink className="h-4 w-4" />
              View full size
            </a>
          </motion.div>
        </motion.div>
      );
    }

    if (file.file_type?.startsWith('video/')) {
      return (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="mt-4 relative rounded-lg overflow-hidden bg-deepGreen-800/20"
        >
          <video
            controls
            className="w-full max-h-[500px]"
            src={fileUrl}
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
            controlsList="nodownload"
          >
            Your browser does not support the video tag.
          </video>
        </motion.div>
      );
    }

    if (file.file_type?.startsWith('audio/')) {
      return (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="mt-4 p-4 bg-deepGreen-800/20 rounded-lg space-y-4"
        >
          <div className="flex items-center gap-2 text-deepGreen-200">
            <AudioWaveform className="h-5 w-5" />
            <span className="font-medium">{file.file_name}</span>
          </div>
          <audio
            controls
            className="w-full"
            src={fileUrl}
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
            controlsList="nodownload"
          >
            Your browser does not support the audio element.
          </audio>
        </motion.div>
      );
    }

    // For other file types, show a download button
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="mt-4 p-4 bg-deepGreen-800/20 rounded-lg"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-deepGreen-200">
            <FileText className="h-5 w-5" />
            <span className="font-medium">{file.file_name}</span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => window.open(fileUrl, '_blank')}
            className="text-deepGreen-200 hover:text-deepGreen-100"
          >
            <ExternalLink className="h-4 w-4 mr-2" />
            Download
          </Button>
        </div>
      </motion.div>
    );
  };

  return (
    <div className="space-y-4">
      <p className="text-deepGreen-200 leading-relaxed whitespace-pre-wrap">{content}</p>
      {getFilePreview()}
    </div>
  );
};

export default FeedItemContent;