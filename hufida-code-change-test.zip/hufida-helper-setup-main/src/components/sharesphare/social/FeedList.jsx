import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import FeedItem from '@/components/dashboard/social/components/FeedItem';
import { Loader2 } from 'lucide-react';

const FeedList = ({ feed, isLoading, user }) => {
  console.log('FeedList rendering with feed:', feed);

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-deepGreen-300" />
      </div>
    );
  }

  if (!feed?.length) {
    return (
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-center py-12 text-deepGreen-300 bg-deepGreen-800/30 rounded-lg border border-deepGreen-600/20"
      >
        No posts yet. Be the first to share something!
      </motion.div>
    );
  }

  return (
    <div className="mt-6 space-y-6">
      <AnimatePresence mode="popLayout">
        {feed.map(item => {
          // Process file metadata if present
          const fileMetadata = item.project_files?.[0] ? {
            file: {
              file_name: item.project_files[0].file_name,
              file_path: item.project_files[0].file_path,
              file_type: item.project_files[0].file_type,
              file_size: item.project_files[0].file_size
            }
          } : {};

          // Combine with existing metadata
          const combinedMetadata = {
            ...item.metadata,
            ...fileMetadata,
            likes_count: item.content_reactions?.filter(r => r.reaction_type === 'like').length || 0,
            comments_count: item.content_reactions?.filter(r => r.reaction_type === 'comment').length || 0,
            user_has_liked: item.content_reactions?.some(r => 
              r.reaction_type === 'like' && r.user_id === user?.id
            ) || false,
            impact_score: item.metadata?.impact_score || 0
          };

          return (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <FeedItem 
                item={{
                  ...item,
                  type: 'content',
                  profiles: item.profiles,
                  metadata: combinedMetadata
                }}
              />
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
};

export default FeedList;