import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';

export const useFeed = () => {
  return useQuery({
    queryKey: ['community-feed'],
    queryFn: async () => {
      console.log('Fetching community feed');
      const { data, error } = await supabase
        .from('content_items')
        .select(`
          *,
          profiles:creator_id (*),
          project_files (*),
          metadata,
          content_reactions (*)
        `)
        .eq('content_type', 'social_post')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching feed:', error);
        throw error;
      }

      console.log('Fetched feed data:', data);
      return data;
    }
  });
};