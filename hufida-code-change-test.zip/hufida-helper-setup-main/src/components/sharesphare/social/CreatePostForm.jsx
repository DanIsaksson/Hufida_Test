import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Upload, Loader2, X } from 'lucide-react';
import { toast } from "sonner";
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/components/AuthProvider';

const CreatePostForm = ({ onPostCreated }) => {
  const [content, setContent] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const { user } = useAuth();

  console.log('CreatePostForm rendering with user:', user?.id);

  const handleFileSelect = (event) => {
    const file = event.target.files[0];
    if (file) {
      if (file.size > 50 * 1024 * 1024) { // 50MB limit
        toast.error('File size must be less than 50MB');
        return;
      }
      setSelectedFile(file);
    }
  };

  const removeFile = () => {
    setSelectedFile(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!content.trim() && !selectedFile) {
      toast.error('Please add some content or attach a file');
      return;
    }

    setIsSubmitting(true);
    try {
      let fileData = null;
      if (selectedFile) {
        const fileExt = selectedFile.name.split('.').pop();
        const filePath = `${crypto.randomUUID()}.${fileExt}`;

        const { error: uploadError } = await supabase.storage
          .from('project_files')
          .upload(filePath, selectedFile);

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('project_files')
          .getPublicUrl(filePath);

        fileData = {
          file_name: selectedFile.name,
          file_path: filePath,
          file_type: selectedFile.type,
          file_size: selectedFile.size,
          public_url: publicUrl
        };
      }

      // Generate a title from the content or use a default format
      const title = content.trim() 
        ? content.split('\n')[0].slice(0, 100) // Use first line of content, max 100 chars
        : 'Social Post';

      const { data: post, error } = await supabase
        .from('content_items')
        .insert({
          title: title,
          content: content,
          content_type: 'social_post',
          creator_id: user.id,
          status: 'approved',
          metadata: fileData ? { file: fileData } : {}
        })
        .select()
        .single();

      if (error) throw error;

      if (fileData) {
        const { error: fileError } = await supabase
          .from('project_files')
          .insert({
            content_id: post.id,
            file_name: fileData.file_name,
            file_path: fileData.file_path,
            file_type: fileData.file_type,
            file_size: fileData.file_size,
            uploaded_by: user.id
          });

        if (fileError) throw fileError;
      }

      setContent('');
      setSelectedFile(null);
      if (onPostCreated) onPostCreated(post);
      toast.success('Post created successfully');
    } catch (error) {
      console.error('Error creating post:', error);
      toast.error('Failed to create post: ' + error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className="p-4 bg-white/95 backdrop-blur-sm">
      <form onSubmit={handleSubmit} className="space-y-4">
        <Textarea
          placeholder="Share your thoughts..."
          value={content}
          onChange={(e) => setContent(e.target.value)}
          className="min-h-[100px] resize-none"
        />
        
        <div className="flex items-center gap-4">
          <div className="flex-1">
            {selectedFile ? (
              <div className="flex items-center gap-2 text-sm text-deepGreen-600 bg-deepGreen-50 p-2 rounded">
                <span className="truncate">{selectedFile.name}</span>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={removeFile}
                  className="h-6 w-6"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <div className="relative">
                <Input
                  type="file"
                  onChange={handleFileSelect}
                  className="hidden"
                  id="file-upload"
                />
                <Button
                  type="button"
                  variant="outline"
                  asChild
                  className="text-deepGreen-600 hover:text-deepGreen-700"
                >
                  <label htmlFor="file-upload" className="cursor-pointer flex items-center gap-2">
                    <Upload className="h-4 w-4" />
                    Attach File
                  </label>
                </Button>
              </div>
            )}
          </div>
          
          <Button 
            type="submit" 
            disabled={isSubmitting || (!content.trim() && !selectedFile)}
            className="bg-deepGreen-600 hover:bg-deepGreen-700 text-white"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Posting...
              </>
            ) : (
              'Post'
            )}
          </Button>
        </div>
      </form>
    </Card>
  );
};

export default CreatePostForm;