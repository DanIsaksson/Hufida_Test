import React from 'react';
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useNavigate } from 'react-router-dom';
import { FolderPlus, Users, ArrowRight, Calendar, Target, MapPin } from 'lucide-react';
import { Skeleton } from "@/components/ui/skeleton";
import ProjectCreationHub from '../features/ProjectCreationHub';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';

const ProjectCard = ({ project, isLoading }) => {
  const navigate = useNavigate();

  if (isLoading) {
    return (
      <Card className="bg-deepGreen-700/50">
        <CardHeader>
          <Skeleton className="h-6 w-3/4 bg-deepGreen-600/30" />
        </CardHeader>
        <CardContent className="space-y-4">
          <Skeleton className="h-4 w-full bg-deepGreen-600/30" />
          <Skeleton className="h-4 w-3/4 bg-deepGreen-600/30" />
          <div className="space-y-2">
            <Skeleton className="h-4 w-1/2 bg-deepGreen-600/30" />
            <Skeleton className="h-4 w-2/3 bg-deepGreen-600/30" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-deepGreen-700/50 hover:bg-deepGreen-700/70 transition-colors">
      <CardHeader>
        <CardTitle className="text-lg text-deepGreen-100">{project.title}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-deepGreen-200 line-clamp-3">{project.description}</p>
        <div className="space-y-2 text-deepGreen-300">
          {project.start_date && (
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              <span>{new Date(project.start_date).toLocaleDateString()}</span>
            </div>
          )}
          {project.target_audience && (
            <div className="flex items-center gap-2">
              <Target className="h-4 w-4" />
              <span>{project.target_audience.join(', ')}</span>
            </div>
          )}
          {project.location && (
            <div className="flex items-center gap-2">
              <MapPin className="h-4 w-4" />
              <span>{project.location}</span>
            </div>
          )}
        </div>
        <Button 
          variant="ghost" 
          className="mt-4 text-deepGreen-100 hover:text-white hover:bg-deepGreen-500 w-full justify-center"
          onClick={() => navigate(`/active-project/${project.id}`)}
        >
          View Details
        </Button>
      </CardContent>
    </Card>
  );
};

const ProjectsTab = () => {
  const navigate = useNavigate();
  const { data: projects, isLoading } = useQuery({
    queryKey: ['active-projects'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('projects')
        .select('*')
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data;
    }
  });

  console.log('ProjectsTab rendering with projects:', projects);

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card className="bg-deepGreen-600/50">
          <CardHeader>
            <CardTitle className="text-deepGreen-100 flex items-center">
              <FolderPlus className="mr-2 h-5 w-5" />
              Project Hub
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="text-deepGreen-200">
                <h3 className="text-xl font-semibold mb-4">Create a New Project</h3>
                <p className="mb-6">Share your project idea with the community and collaborate with others to bring it to life.</p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h4 className="font-medium">Project Creation Process</h4>
                    <ul className="list-disc pl-5 space-y-2">
                      <li>Share your project idea</li>
                      <li>Get community feedback</li>
                      <li>Refine your approach</li>
                      <li>Build your team</li>
                      <li>Launch and track impact</li>
                    </ul>
                  </div>
                  
                  <div className="space-y-4">
                    <h4 className="font-medium">What You'll Need</h4>
                    <ul className="list-disc pl-5 space-y-2">
                      <li>Clear project title and description</li>
                      <li>Project goals and objectives</li>
                      <li>Target audience and impact metrics</li>
                      <li>Resource requirements and timeline</li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="flex justify-center">
                <Button 
                  onClick={() => navigate('/project-creation')}
                  className="bg-deepGreen-500 hover:bg-deepGreen-400 text-white px-6 py-2 rounded-lg flex items-center gap-2 group"
                >
                  <span>Proceed to Project Creation</span>
                  <motion.span
                    className="inline-block"
                    animate={{ x: [0, 4, 0] }}
                    transition={{ repeat: Infinity, duration: 1.5 }}
                  >
                    <ArrowRight className="h-5 w-5" />
                  </motion.span>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <Card className="bg-deepGreen-600/50">
          <CardHeader>
            <CardTitle className="text-deepGreen-100 flex items-center">
              <Users className="mr-2 h-5 w-5" />
              Active Projects
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {[1, 2, 3].map((i) => (
                  <ProjectCard key={i} isLoading={true} />
                ))}
              </div>
            ) : projects?.length === 0 ? (
              <div className="text-center text-deepGreen-200 py-8">
                No active projects found
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {projects?.map((project) => (
                  <ProjectCard 
                    key={project.id} 
                    project={project} 
                    isLoading={false}
                  />
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default ProjectsTab;