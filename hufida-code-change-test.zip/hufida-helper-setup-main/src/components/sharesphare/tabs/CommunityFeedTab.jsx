import React, { useState } from 'react';
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users } from 'lucide-react';
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";
import { useAuth } from '@/components/AuthProvider';
import CreatePostForm from '../social/CreatePostForm';
import FeedList from '../social/FeedList';
import { useFeed } from '../social/useFeed';

const CommunityFeedTab = () => {
  const { user } = useAuth();
  const [isCreatingPost, setIsCreatingPost] = useState(false);
  const { data: feed, isLoading, error } = useFeed();

  console.log('CommunityFeedTab rendering with user:', user);

  if (error) {
    return (
      <Alert variant="destructive" className="bg-red-900/20 border-red-600/30">
        <AlertCircle className="h-4 w-4 text-red-400" />
        <AlertDescription className="text-red-200">
          Failed to load community feed. Please try again later.
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="space-y-6 p-4"
    >
      <Card className="bg-gradient-to-br from-deepGreen-800/50 to-deepGreen-600/30 backdrop-blur-sm border-deepGreen-600/20">
        <CardHeader className="border-b border-deepGreen-600/20">
          <CardTitle className="text-deepGreen-100 flex items-center gap-2">
            <Users className="h-5 w-5 text-deepGreen-300" />
            Community Feed
          </CardTitle>
        </CardHeader>
        <CardContent>
          {user ? (
            <div className="space-y-6">
              <CreatePostForm 
                user={user}
                isCreatingPost={isCreatingPost}
                setIsCreatingPost={setIsCreatingPost}
              />
            </div>
          ) : (
            <div className="text-center py-6 text-deepGreen-300 bg-deepGreen-800/30 rounded-lg border border-deepGreen-600/20">
              Please sign in to create posts and interact with the community.
            </div>
          )}

          <FeedList 
            feed={feed}
            isLoading={isLoading}
            user={user}
          />
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default CommunityFeedTab;