import React from 'react';
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart3 } from 'lucide-react';
import ImpactMetricsGrid from '../analytics/ImpactMetricsGrid';
import ImpactTrendsChart from '../analytics/ImpactTrendsChart';

const ImpactTrackingTab = () => {
  const contentVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <motion.div
      variants={contentVariants}
      initial="hidden"
      animate="visible"
      transition={{ delay: 0.2 }}
      className="space-y-6"
    >
      <Card className="bg-deepGreen-600/50">
        <CardHeader>
          <CardTitle className="text-deepGreen-100 flex items-center">
            <BarChart3 className="mr-2 h-5 w-5" />
            Impact Analytics
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-deepGreen-200 mb-6">
            Track and analyze the collective impact of all projects across different categories.
          </p>
          
          <div className="space-y-8">
            <section>
              <h3 className="text-lg font-semibold text-deepGreen-100 mb-4">Impact Overview</h3>
              <ImpactMetricsGrid />
            </section>

            <section>
              <h3 className="text-lg font-semibold text-deepGreen-100 mb-4">Impact Trends</h3>
              <ImpactTrendsChart />
            </section>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default ImpactTrackingTab;