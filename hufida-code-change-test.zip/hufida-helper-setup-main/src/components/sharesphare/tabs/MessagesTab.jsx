import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { MessageSquare, Send, Loader2 } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/components/AuthProvider';
import { format } from 'date-fns';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const MessagesTab = () => {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const scrollRef = useRef(null);
  const { toast } = useToast();
  const { user } = useAuth();

  useEffect(() => {
    const fetchMessages = async () => {
      setIsLoading(true);
      try {
        const { data, error } = await supabase
          .from('project_messages')
          .select(`
            *,
            sender:sender_id (
              full_name,
              avatar_url
            )
          `)
          .is('project_id', null)
          .order('created_at', { ascending: true })
          .limit(100);

        if (error) throw error;
        setMessages(data || []);
      } catch (error) {
        console.error('Error fetching messages:', error);
        toast({
          title: "Error loading messages",
          description: "Please try again later",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
        scrollToBottom();
      }
    };

    fetchMessages();

    const channel = supabase
      .channel('global-messages')
      .on('postgres_changes', 
        { 
          event: 'INSERT', 
          schema: 'public', 
          table: 'project_messages',
          filter: 'project_id=is.null'
        },
        async (payload) => {
          console.log('New message received:', payload);
          const { data: messageWithSender, error } = await supabase
            .from('project_messages')
            .select(`
              *,
              sender:sender_id (
                full_name,
                avatar_url
              )
            `)
            .eq('id', payload.new.id)
            .single();

          if (!error && messageWithSender) {
            setMessages(prev => [...prev, messageWithSender]);
            scrollToBottom();
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [toast]);

  const scrollToBottom = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  };

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim() || !user || isSending) return;

    setIsSending(true);
    try {
      const { error } = await supabase
        .from('project_messages')
        .insert({
          content: newMessage.trim(),
          sender_id: user.id,
          message_type: 'text',
          project_id: null
        });

      if (error) throw error;
      setNewMessage('');
    } catch (error) {
      console.error('Error sending message:', error);
      toast({
        title: "Error sending message",
        description: "Please try again",
        variant: "destructive",
      });
    } finally {
      setIsSending(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="h-[calc(100vh-200px)]"
    >
      <Card className="h-full bg-gradient-to-br from-deepGreen-800/50 to-deepGreen-600/30 backdrop-blur-sm border-deepGreen-600/20">
        <CardHeader className="border-b border-deepGreen-600/20">
          <CardTitle className="text-deepGreen-100 flex items-center gap-2">
            <MessageSquare className="h-5 w-5 text-deepGreen-300" />
            Global Chat
          </CardTitle>
        </CardHeader>
        <CardContent className="h-[calc(100%-5rem)] flex flex-col p-0">
          <ScrollArea 
            ref={scrollRef}
            className="flex-1 p-4"
          >
            {isLoading ? (
              <div className="flex items-center justify-center h-full">
                <Loader2 className="h-8 w-8 animate-spin text-deepGreen-300" />
              </div>
            ) : (
              <AnimatePresence mode="popLayout">
                <div className="space-y-4">
                  {messages.map((message) => (
                    <motion.div
                      key={message.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      className={`flex items-start gap-3 ${
                        message.sender_id === user?.id ? 'flex-row-reverse' : ''
                      }`}
                    >
                      <Avatar className="h-8 w-8 border-2 border-deepGreen-600/20">
                        <AvatarImage src={message.sender?.avatar_url} />
                        <AvatarFallback className="bg-deepGreen-700 text-deepGreen-100">
                          {message.sender?.full_name?.charAt(0) || '?'}
                        </AvatarFallback>
                      </Avatar>
                      <div
                        className={`flex flex-col ${
                          message.sender_id === user?.id ? 'items-end' : 'items-start'
                        }`}
                      >
                        <div
                          className={`rounded-lg px-4 py-2 max-w-[80%] ${
                            message.sender_id === user?.id
                              ? 'bg-deepGreen-600 text-white'
                              : 'bg-deepGreen-800/50 text-deepGreen-100'
                          } backdrop-blur-sm border border-deepGreen-600/20`}
                        >
                          {message.content}
                        </div>
                        <span className="text-xs text-deepGreen-400 mt-1">
                          {message.sender?.full_name} • {format(new Date(message.created_at), 'HH:mm')}
                        </span>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </AnimatePresence>
            )}
          </ScrollArea>
          
          <form 
            onSubmit={handleSendMessage} 
            className="p-4 border-t border-deepGreen-600/20 bg-deepGreen-800/30"
          >
            <div className="flex gap-2">
              <Input
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                placeholder={user ? "Type your message..." : "Please sign in to chat"}
                disabled={isLoading || !user || isSending}
                className="flex-1 bg-deepGreen-700/50 border-deepGreen-600/20 text-deepGreen-100 placeholder:text-deepGreen-400"
              />
              <Button 
                type="submit" 
                disabled={isLoading || !user || !newMessage.trim() || isSending}
                className="bg-deepGreen-600 hover:bg-deepGreen-500 text-white"
              >
                {isSending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Send className="h-4 w-4" />
                )}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default MessagesTab;