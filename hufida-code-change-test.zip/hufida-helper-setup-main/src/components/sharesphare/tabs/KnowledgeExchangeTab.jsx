import React, { useState } from 'react';
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { BookOpen, Plus } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { toast } from "sonner";
import ResourceDialog from '../../project-details/knowledge/ResourceDialog';
import ResourceCard from '../../project-details/knowledge/ResourceCard';

const KnowledgeExchangeTab = () => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const queryClient = useQueryClient();

  console.log('Rendering KnowledgeExchangeTab');

  const { data: resources, isLoading } = useQuery({
    queryKey: ['global-knowledge-resources'],
    queryFn: async () => {
      console.log('Fetching global knowledge resources');
      const { data, error } = await supabase
        .from('knowledge_resources')
        .select(`
          *,
          created_by_profile:profiles!created_by(
            full_name,
            avatar_url
          )
        `)
        .is('project_id', null) // Only fetch global resources
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching knowledge resources:', error);
        throw error;
      }
      console.log('Fetched knowledge resources:', data);
      return data;
    },
  });

  const createResource = useMutation({
    mutationFn: async (resourceData) => {
      console.log('Creating knowledge resource:', resourceData);
      const { data: userProfile } = await supabase.auth.getUser();
      
      if (!userProfile.user) {
        throw new Error('User must be logged in to create resources');
      }

      const { data, error } = await supabase
        .from('knowledge_resources')
        .insert([{
          ...resourceData,
          created_by: userProfile.user.id,
          project_id: null // This makes it a global resource
        }])
        .select()
        .single();

      if (error) {
        console.error('Error creating resource:', error);
        throw error;
      }
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['global-knowledge-resources']);
      setIsDialogOpen(false);
      toast.success('Resource added successfully');
    },
    onError: (error) => {
      console.error('Error creating resource:', error);
      toast.error('Failed to add resource');
    },
  });

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <Card className="bg-deepGreen-600/50">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-deepGreen-100 flex items-center">
              <BookOpen className="mr-2 h-5 w-5" />
              Knowledge Exchange Portal
            </CardTitle>
            <Button 
              onClick={() => setIsDialogOpen(true)}
              className="bg-deepGreen-600 hover:bg-deepGreen-700"
            >
              <Plus className="h-4 w-4 mr-2" />
              Share Knowledge
            </Button>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[600px] pr-4">
              {isLoading ? (
                <div className="text-center py-8 text-deepGreen-200">
                  Loading resources...
                </div>
              ) : resources?.length === 0 ? (
                <div className="text-center py-8 text-deepGreen-200">
                  No resources shared yet. Be the first to contribute!
                </div>
              ) : (
                <div className="space-y-4">
                  {resources?.map((resource) => (
                    <ResourceCard 
                      key={resource.id} 
                      resource={resource}
                    />
                  ))}
                </div>
              )}
            </ScrollArea>
          </CardContent>
        </Card>
      </motion.div>

      <ResourceDialog
        isOpen={isDialogOpen}
        setIsOpen={setIsDialogOpen}
        onSubmit={createResource.mutate}
        isSubmitting={createResource.isPending}
      />
    </div>
  );
};

export default KnowledgeExchangeTab;