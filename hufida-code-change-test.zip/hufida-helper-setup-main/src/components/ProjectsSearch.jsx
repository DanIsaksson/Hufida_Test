import React from 'react';
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { motion } from "framer-motion";
import { Search } from 'lucide-react';
import { neuInputStyles, neuCardStyles } from '../../utils/styleUtils';

const ProjectsSearch = ({ searchTerm, setSearchTerm, categoryFilter, setCategoryFilter }) => {
  return (
    <motion.div 
      className="flex flex-col sm:flex-row gap-4 mb-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.4 }}
    >
      <div className="relative flex-grow">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-deepGreen-500" />
        <Input
          type="text"
          placeholder="Search projects..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className={`
            ${neuInputStyles({ state: "default" })} 
            pl-10 flex-grow text-deepGreen-800
            focus:ring-2 focus:ring-deepGreen-500 focus:ring-opacity-50
            hover:bg-deepGreen-50 transition-colors
          `}
        />
      </div>
      <Select 
        value={categoryFilter} 
        onValueChange={setCategoryFilter}
      >
        <SelectTrigger 
          className={`
            ${neuCardStyles({ elevation: "low" })} 
            w-full sm:w-[180px] bg-deepGreen-100 text-deepGreen-800
            hover:bg-deepGreen-200 transition-colors
            focus:ring-2 focus:ring-deepGreen-500 focus:ring-opacity-50
          `}
        >
          <SelectValue placeholder="Filter by category" />
        </SelectTrigger>
        <SelectContent className="bg-white border border-deepGreen-200">
          <SelectItem value="All">All Categories</SelectItem>
          <SelectItem value="Technology">Technology</SelectItem>
          <SelectItem value="Environment">Environment</SelectItem>
          <SelectItem value="Research">Research</SelectItem>
          <SelectItem value="Education">Education</SelectItem>
          <SelectItem value="Health">Health</SelectItem>
          <SelectItem value="Energy">Energy</SelectItem>
        </SelectContent>
      </Select>
    </motion.div>
  );
};

export default ProjectsSearch;