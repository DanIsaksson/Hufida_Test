import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { motion } from "framer-motion";

const ProjectSection = ({ section }) => (
  <motion.div
    initial={{ opacity: 0, x: 20 }}
    animate={{ opacity: 1, x: 0 }}
    transition={{ duration: 0.5 }}
  >
    <Card className="neu-card bg-deepGreen-50 border-deepGreen-200">
      <CardHeader>
        <CardTitle className="text-deepGreen-700">{section.title}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-deepGreen-600">{section.content}</p>
      </CardContent>
    </Card>
  </motion.div>
);

export default ProjectSection;