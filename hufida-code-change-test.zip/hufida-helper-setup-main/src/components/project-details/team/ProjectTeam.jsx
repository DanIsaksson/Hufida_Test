import React from 'react';
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Users, Mail, Phone } from 'lucide-react';
import { neuCardStyles } from '../../../utils/styleUtils';

const ProjectTeam = ({ teamMembers }) => {
  console.log('Rendering ProjectTeam with:', teamMembers);

  if (!teamMembers?.length) {
    return (
      <Card className={`${neuCardStyles({ elevation: "medium" })} bg-white`}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-deepGreen-700">
            <Users className="h-5 w-5" />
            Project Team
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-deepGreen-600 text-sm">No team members have been assigned to this project yet.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={`${neuCardStyles({ elevation: "medium" })} bg-white`}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-deepGreen-700">
          <Users className="h-5 w-5" />
          Project Team
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[300px] pr-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {teamMembers.map((member, index) => (
              <motion.div
                key={member.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-deepGreen-50 rounded-lg p-4 hover:bg-deepGreen-100 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={member.profile.avatar_url} alt={member.profile.full_name} />
                    <AvatarFallback>{member.profile.full_name?.charAt(0) || '?'}</AvatarFallback>
                  </Avatar>
                  <div>
                    <h4 className="font-medium text-deepGreen-700">{member.profile.full_name}</h4>
                    <p className="text-sm text-deepGreen-600">{member.role}</p>
                  </div>
                </div>
                
                {member.responsibilities && member.responsibilities.length > 0 && (
                  <div className="mt-3">
                    <p className="text-xs font-medium text-deepGreen-500">Responsibilities:</p>
                    <ul className="mt-1 text-sm text-deepGreen-600 list-disc list-inside">
                      {member.responsibilities.map((resp, idx) => (
                        <li key={idx}>{resp}</li>
                      ))}
                    </ul>
                  </div>
                )}
                
                <div className="mt-3 flex flex-wrap gap-3 text-xs text-deepGreen-500">
                  {member.profile.contact_email && (
                    <a 
                      href={`mailto:${member.profile.contact_email}`}
                      className="flex items-center gap-1 hover:text-deepGreen-700"
                    >
                      <Mail className="h-3 w-3" />
                      {member.profile.contact_email}
                    </a>
                  )}
                  {member.profile.contact_phone && (
                    <a 
                      href={`tel:${member.profile.contact_phone}`}
                      className="flex items-center gap-1 hover:text-deepGreen-700"
                    >
                      <Phone className="h-3 w-3" />
                      {member.profile.contact_phone}
                    </a>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
};

export default ProjectTeam;