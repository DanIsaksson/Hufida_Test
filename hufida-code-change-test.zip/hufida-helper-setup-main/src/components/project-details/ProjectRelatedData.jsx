import React from 'react';
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar, Users, MessageSquare, Globe, Activity } from 'lucide-react';
import { format } from 'date-fns';
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { neuCardStyles } from '../../utils/styleUtils';

const ProjectRelatedData = ({ project, partnerEvents, communityEngagements, projectUpdates }) => {
  console.log('Rendering ProjectRelatedData with:', { partnerEvents, communityEngagements, projectUpdates });

  const formatDate = (dateString) => {
    if (!dateString) return 'Date TBD';
    return format(new Date(dateString), 'MMM dd, yyyy');
  };

  return (
    <TooltipProvider>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
        className="space-y-6"
      >
        <h2 className="text-2xl font-semibold text-deepGreen-800 mb-4">Related Activities</h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Partner Events Section */}
          <Card className={`${neuCardStyles({ elevation: "medium" })} bg-white hover:shadow-lg transition-all duration-300`}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-deepGreen-700">
                <Calendar className="h-5 w-5 text-deepGreen-600" />
                Partner Events
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[200px] pr-4">
                {partnerEvents && partnerEvents.length > 0 ? (
                  <div className="space-y-4">
                    {partnerEvents.map((event) => (
                      <Tooltip key={event.id}>
                        <TooltipTrigger asChild>
                          <motion.div
                            whileHover={{ scale: 1.02 }}
                            initial={{ opacity: 0, x: -10 }}
                            animate={{ opacity: 1, x: 0 }}
                            className="p-3 bg-deepGreen-50 rounded-lg cursor-pointer hover:bg-deepGreen-100 transition-colors"
                          >
                            <h3 className="font-medium text-deepGreen-700">{event.title}</h3>
                            <p className="text-sm text-deepGreen-600">{event.description}</p>
                            <div className="flex items-center gap-2 mt-2 text-xs text-deepGreen-500">
                              <Calendar className="h-3 w-3" />
                              <span>{formatDate(event.event_date)}</span>
                              {event.location && (
                                <>
                                  <Globe className="h-3 w-3 ml-2" />
                                  <span>{event.location}</span>
                                </>
                              )}
                            </div>
                          </motion.div>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Click to see event details</p>
                        </TooltipContent>
                      </Tooltip>
                    ))}
                  </div>
                ) : (
                  <p className="text-deepGreen-500 text-sm">No upcoming events</p>
                )}
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Community Engagements Section */}
          <Card className={`${neuCardStyles({ elevation: "medium" })} bg-white hover:shadow-lg transition-all duration-300`}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-deepGreen-700">
                <Users className="h-5 w-5 text-deepGreen-600" />
                Community Engagements
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[200px] pr-4">
                {communityEngagements && communityEngagements.length > 0 ? (
                  <div className="space-y-4">
                    {communityEngagements.map((engagement) => (
                      <Tooltip key={engagement.id}>
                        <TooltipTrigger asChild>
                          <motion.div
                            whileHover={{ scale: 1.02 }}
                            initial={{ opacity: 0, x: -10 }}
                            animate={{ opacity: 1, x: 0 }}
                            className="p-3 bg-deepGreen-50 rounded-lg cursor-pointer hover:bg-deepGreen-100 transition-colors"
                          >
                            <h3 className="font-medium text-deepGreen-700">{engagement.title}</h3>
                            <p className="text-sm text-deepGreen-600">{engagement.description}</p>
                            <div className="flex items-center gap-2 mt-2 text-xs text-deepGreen-500">
                              <Users className="h-3 w-3" />
                              <span>{engagement.participants_count || 0} participants</span>
                              {engagement.location && (
                                <>
                                  <Globe className="h-3 w-3 ml-2" />
                                  <span>{engagement.location}</span>
                                </>
                              )}
                            </div>
                          </motion.div>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Click to see engagement details</p>
                        </TooltipContent>
                      </Tooltip>
                    ))}
                  </div>
                ) : (
                  <p className="text-deepGreen-500 text-sm">No community engagements yet</p>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </div>

        {/* Project Updates Section */}
        <Card className={`${neuCardStyles({ elevation: "medium" })} bg-white hover:shadow-lg transition-all duration-300`}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-deepGreen-700">
              <Activity className="h-5 w-5 text-deepGreen-600" />
              Recent Updates
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[200px] pr-4">
              {projectUpdates && projectUpdates.length > 0 ? (
                <div className="space-y-4">
                  {projectUpdates.map((update) => (
                    <Tooltip key={update.id}>
                      <TooltipTrigger asChild>
                        <motion.div
                          whileHover={{ scale: 1.02 }}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="p-3 bg-deepGreen-50 rounded-lg cursor-pointer hover:bg-deepGreen-100 transition-colors"
                        >
                          <div className="flex items-start justify-between">
                            <div>
                              <span className="inline-block px-2 py-1 text-xs font-medium rounded-full bg-deepGreen-100 text-deepGreen-700 mb-2">
                                {update.update_type}
                              </span>
                              <p className="text-sm text-deepGreen-600">{update.description}</p>
                            </div>
                            <span className="text-xs text-deepGreen-500">
                              {formatDate(update.created_at)}
                            </span>
                          </div>
                        </motion.div>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Click to see update details</p>
                      </TooltipContent>
                    </Tooltip>
                  ))}
                </div>
              ) : (
                <p className="text-deepGreen-500 text-sm">No recent updates</p>
              )}
            </ScrollArea>
          </CardContent>
        </Card>
      </motion.div>
    </TooltipProvider>
  );
};

export default ProjectRelatedData;