import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { motion } from "framer-motion";
import { neuCardStyles } from '../../../utils/styleUtils';
import FeatureIcon from './FeatureIcon';
import FeatureDetails from './FeatureDetails';

const FeatureCard = ({ feature, index }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      whileHover={{ scale: 1.02 }}
      className="h-full"
    >
      <Card className={`${neuCardStyles({ elevation: "medium" })} bg-white hover:shadow-xl transition-all duration-300 cursor-pointer h-full group`}>
        <CardHeader className="flex flex-row items-center gap-4 pb-2">
          <FeatureIcon iconName={feature.icon_name} />
          <CardTitle className="text-xl text-deepGreen-700">{feature.title}</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-deepGreen-600 mb-4">{feature.description}</p>
          <FeatureDetails details={feature.details} />
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default FeatureCard;