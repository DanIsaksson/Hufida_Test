import React from 'react';
import { Code, Users, Rocket, Globe, Leaf, Recycle, BookOpen, Smartphone } from 'lucide-react';

const iconMap = {
  code: Code,
  users: Users,
  rocket: Rocket,
  globe: Globe,
  leaf: Leaf,
  recycle: Recycle,
  book: BookOpen,
  smartphone: Smartphone
};

const FeatureIcon = ({ iconName }) => {
  const IconComponent = iconName ? iconMap[iconName.toLowerCase()] : Rocket;
  
  return (
    <div className="rounded-lg bg-deepGreen-100 p-2 group-hover:bg-deepGreen-200 transition-colors">
      {IconComponent && <IconComponent className="h-6 w-6 text-deepGreen-600" />}
    </div>
  );
};

export default FeatureIcon;