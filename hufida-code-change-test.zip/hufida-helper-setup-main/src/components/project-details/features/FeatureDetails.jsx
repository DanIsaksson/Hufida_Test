import React from 'react';
import { motion } from "framer-motion";

const FeatureDetails = ({ details }) => {
  if (!details || details.length === 0) return null;
  
  return (
    <motion.ul 
      className="space-y-2"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.2 }}
    >
      {details.map((detail, idx) => (
        <motion.li 
          key={idx} 
          className="flex items-center gap-2 text-sm text-deepGreen-500"
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 + idx * 0.1 }}
        >
          <div className="h-1.5 w-1.5 rounded-full bg-deepGreen-400 flex-shrink-0" />
          <span>{detail}</span>
        </motion.li>
      ))}
    </motion.ul>
  );
};

export default FeatureDetails;