import React from 'react';
import { motion } from "framer-motion";
import { TooltipProvider, Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import FeatureCard from './FeatureCard';

const ProjectFeatures = ({ features }) => {
  console.log('Rendering ProjectFeatures with features:', features);

  if (!features || features.length === 0) {
    return null;
  }

  return (
    <TooltipProvider>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="space-y-6"
      >
        <motion.h2 
          className="text-3xl font-bold text-center text-deepGreen-800"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          Key Features
        </motion.h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <Tooltip key={feature.id}>
              <TooltipTrigger asChild>
                <div>
                  <FeatureCard feature={feature} index={index} />
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <p>Click to learn more about {feature.title}</p>
              </TooltipContent>
            </Tooltip>
          ))}
        </div>
      </motion.div>
    </TooltipProvider>
  );
};

export default ProjectFeatures;