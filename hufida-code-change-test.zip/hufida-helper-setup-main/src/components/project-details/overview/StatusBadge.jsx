import React from 'react';
import { Badge } from "@/components/ui/badge";

const StatusBadge = ({ status, type = 'project' }) => {
  const getStatusColor = () => {
    if (type === 'funding') {
      switch (status?.toLowerCase()) {
        case 'funded':
          return 'bg-green-100 text-green-700';
        case 'pending':
          return 'bg-yellow-100 text-yellow-700';
        case 'seeking':
          return 'bg-blue-100 text-blue-700';
        default:
          return 'bg-gray-100 text-gray-700';
      }
    }

    switch (status?.toLowerCase()) {
      case 'active':
        return 'bg-green-100 text-green-700';
      case 'completed':
        return 'bg-blue-100 text-blue-700';
      case 'pending':
        return 'bg-yellow-100 text-yellow-700';
      case 'draft':
        return 'bg-gray-100 text-gray-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <Badge 
      variant="secondary"
      className={`${getStatusColor()} capitalize`}
    >
      {type === 'funding' ? `Funding: ${status}` : status}
    </Badge>
  );
};

export default StatusBadge;