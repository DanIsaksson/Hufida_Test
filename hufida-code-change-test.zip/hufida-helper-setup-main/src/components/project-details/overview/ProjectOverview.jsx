import React from 'react';
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar, Target, MapPin, Users, Globe, Briefcase, Tags, Rocket, Clock, Coins } from 'lucide-react';
import { neuCardStyles } from '../../../utils/styleUtils';
import StatusBadge from './StatusBadge';
import MetadataItem from './MetadataItem';

const ProjectOverview = ({ project }) => {
  console.log('Rendering ProjectOverview with project:', project);
  
  const formatDate = (dateString) => {
    if (!dateString) return 'Not specified';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="space-y-6"
    >
      <Card className={`${neuCardStyles({ elevation: "medium" })} bg-white/95 backdrop-blur-sm hover:shadow-xl transition-all duration-300`}>
        <CardHeader className="border-b border-gray-100 pb-6">
          <CardTitle className="text-2xl text-deepGreen-700 flex items-center gap-3">
            <Globe className="h-7 w-7 text-deepGreen-600" />
            Project Overview
          </CardTitle>
          <p className="text-deepGreen-600 mt-2 text-lg">{project.description}</p>
          <div className="mt-4 flex flex-wrap gap-2">
            <StatusBadge status={project.project_status} />
            {project.funding_status && (
              <StatusBadge status={project.funding_status} type="funding" />
            )}
          </div>
        </CardHeader>
        <CardContent className="pt-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <MetadataItem
              icon={Calendar}
              label="Timeline"
              value={`${formatDate(project.start_date)} - ${formatDate(project.end_date)}`}
            />
            <MetadataItem
              icon={Coins}
              label="Budget"
              value={project.budget ? `$${project.budget.toLocaleString()}` : 'Not specified'}
            />
            <MetadataItem
              icon={Briefcase}
              label="Category"
              value={project.category || 'Not specified'}
            />
            <MetadataItem
              icon={MapPin}
              label="Location"
              value={project.location || 'Not specified'}
            />
            <MetadataItem
              icon={Target}
              label="Target Audience"
              value={project.target_audience?.join(', ') || 'Not specified'}
            />
            <MetadataItem
              icon={Users}
              label="Team Size"
              value={project.team_members?.length ? `${project.team_members.length} Members` : 'No team members yet'}
            />
          </div>

          {project.tags && project.tags.length > 0 && (
            <div className="pt-4 border-t border-gray-100">
              <div className="flex items-center gap-2 flex-wrap">
                <Tags className="h-4 w-4 text-deepGreen-500" />
                {project.tags.map((tag, index) => (
                  <span
                    key={index}
                    className="px-3 py-1 bg-deepGreen-50 text-deepGreen-600 rounded-full text-sm font-medium"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          )}

          {project.approach && (
            <div className="pt-4 border-t border-gray-100">
              <h3 className="text-lg font-semibold text-deepGreen-700 mb-2 flex items-center gap-2">
                <Rocket className="h-5 w-5 text-deepGreen-500" />
                Approach
              </h3>
              <p className="text-deepGreen-600">{project.approach}</p>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default ProjectOverview;