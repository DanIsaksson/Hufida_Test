import React from 'react';

const MetadataItem = ({ icon: Icon, label, value }) => {
  return (
    <div className="flex items-center gap-3 text-deepGreen-600 hover:text-deepGreen-700 transition-colors group">
      <div className="rounded-lg bg-deepGreen-50 p-2 group-hover:bg-deepGreen-100 transition-colors">
        <Icon className="h-5 w-5 text-deepGreen-500" />
      </div>
      <div>
        <p className="text-sm text-deepGreen-500">{label}</p>
        <p className="font-medium">{value}</p>
      </div>
    </div>
  );
};

export default MetadataItem;