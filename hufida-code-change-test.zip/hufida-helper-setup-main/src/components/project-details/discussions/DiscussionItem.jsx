import React from 'react';
import { motion } from "framer-motion";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { format } from 'date-fns';
import { MessageSquare } from 'lucide-react';

const DiscussionItem = ({ discussion }) => {
  const initials = discussion.created_by_profile?.full_name
    ?.split(' ')
    .map(n => n[0])
    .join('') || '?';

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-4 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow border border-gray-100"
    >
      <div className="flex items-start gap-4">
        <Avatar>
          <AvatarImage src={discussion.created_by_profile?.avatar_url} />
          <AvatarFallback>{initials}</AvatarFallback>
        </Avatar>
        <div className="flex-1">
          <div className="flex items-center justify-between">
            <h3 className="font-medium text-deepGreen-800">{discussion.title}</h3>
            <span className="text-sm text-deepGreen-500">
              {format(new Date(discussion.created_at), 'MMM dd, yyyy')}
            </span>
          </div>
          <p className="mt-1 text-sm text-deepGreen-600">{discussion.content}</p>
          <div className="mt-2 flex items-center gap-2 text-sm text-deepGreen-500">
            <MessageSquare className="h-4 w-4" />
            <span>0 replies</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default DiscussionItem;