import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { supabase } from '@/lib/supabase';
import { useForm } from 'react-hook-form';

const NewDiscussionDialog = ({ isOpen, setIsOpen, projectId }) => {
  const { register, handleSubmit, reset, formState: { isSubmitting } } = useForm();
  const { toast } = useToast();

  const onSubmit = async (data) => {
    try {
      const { error } = await supabase
        .from('project_discussions')
        .insert([
          {
            project_id: projectId,
            title: data.title,
            content: data.content,
          }
        ]);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Discussion created successfully",
      });
      
      reset();
      setIsOpen(false);
    } catch (error) {
      console.error('Error creating discussion:', error);
      toast({
        title: "Error",
        description: "Failed to create discussion",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Start New Discussion</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="space-y-2">
            <Input
              {...register('title', { required: true })}
              placeholder="Discussion title"
              className="w-full"
            />
          </div>
          <div className="space-y-2">
            <Textarea
              {...register('content', { required: true })}
              placeholder="What would you like to discuss?"
              className="min-h-[100px]"
            />
          </div>
          <div className="flex justify-end gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsOpen(false)}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting}
              className="bg-deepGreen-600 hover:bg-deepGreen-700"
            >
              {isSubmitting ? 'Creating...' : 'Create Discussion'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default NewDiscussionDialog;