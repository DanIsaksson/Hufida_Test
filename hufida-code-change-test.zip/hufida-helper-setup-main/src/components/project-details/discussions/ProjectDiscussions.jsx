import React, { useState, useEffect } from 'react';
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { MessageSquare, Plus } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { supabase } from '@/lib/supabase';
import { format } from 'date-fns';
import DiscussionItem from './DiscussionItem';
import NewDiscussionDialog from './NewDiscussionDialog';

const ProjectDiscussions = ({ projectId }) => {
  const [discussions, setDiscussions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const fetchDiscussions = async () => {
      try {
        const { data, error } = await supabase
          .from('project_discussions')
          .select(`
            *,
            created_by_profile:profiles!created_by(
              full_name,
              avatar_url
            )
          `)
          .eq('project_id', projectId)
          .order('created_at', { ascending: false });

        if (error) throw error;
        setDiscussions(data);
      } catch (error) {
        console.error('Error fetching discussions:', error);
        toast({
          title: "Error",
          description: "Failed to load discussions",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchDiscussions();

    // Set up real-time subscription
    const channel = supabase
      .channel('project-discussions')
      .on('postgres_changes', 
        { 
          event: '*', 
          schema: 'public', 
          table: 'project_discussions',
          filter: `project_id=eq.${projectId}`
        },
        (payload) => {
          console.log('Discussion change received:', payload);
          if (payload.eventType === 'INSERT') {
            setDiscussions(prev => [payload.new, ...prev]);
          } else if (payload.eventType === 'UPDATE') {
            setDiscussions(prev => 
              prev.map(disc => disc.id === payload.new.id ? payload.new : disc)
            );
          } else if (payload.eventType === 'DELETE') {
            setDiscussions(prev => 
              prev.filter(disc => disc.id !== payload.old.id)
            );
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [projectId, toast]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-4"
    >
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-xl font-semibold flex items-center gap-2">
            <MessageSquare className="h-5 w-5 text-deepGreen-600" />
            Discussions
          </CardTitle>
          <Button 
            onClick={() => setIsDialogOpen(true)}
            className="bg-deepGreen-600 hover:bg-deepGreen-700"
          >
            <Plus className="h-4 w-4 mr-2" />
            New Discussion
          </Button>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[400px] pr-4">
            {isLoading ? (
              <div className="flex justify-center py-8">
                <span className="loading loading-spinner"></span>
              </div>
            ) : discussions.length === 0 ? (
              <div className="text-center py-8 text-deepGreen-600">
                No discussions yet. Start a new one!
              </div>
            ) : (
              <div className="space-y-4">
                {discussions.map((discussion) => (
                  <DiscussionItem 
                    key={discussion.id} 
                    discussion={discussion}
                  />
                ))}
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>

      <NewDiscussionDialog
        isOpen={isDialogOpen}
        setIsOpen={setIsDialogOpen}
        projectId={projectId}
      />
    </motion.div>
  );
};

export default ProjectDiscussions;