import React from 'react';
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Clock, CheckCircle, AlertCircle } from 'lucide-react';
import { format } from 'date-fns';
import { neuCardStyles } from '../../../utils/styleUtils';

const ProjectTimeline = ({ milestones }) => {
  console.log('Rendering ProjectTimeline with:', milestones);

  if (!milestones?.length) {
    return (
      <Card className={`${neuCardStyles({ elevation: "medium" })} bg-white`}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-deepGreen-700">
            <Clock className="h-5 w-5" />
            Project Timeline
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-deepGreen-600 text-sm">No milestones have been set for this project yet.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={`${neuCardStyles({ elevation: "medium" })} bg-white`}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-deepGreen-700">
          <Clock className="h-5 w-5" />
          Project Timeline
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[300px] pr-4">
          <div className="space-y-4">
            {milestones.map((milestone, index) => (
              <motion.div
                key={milestone.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="relative pl-6 pb-4 border-l-2 border-deepGreen-200 last:border-l-0"
              >
                <div className="absolute -left-[9px] top-0">
                  {milestone.status === 'completed' ? (
                    <CheckCircle className="h-4 w-4 text-green-500" />
                  ) : milestone.status === 'pending' ? (
                    <AlertCircle className="h-4 w-4 text-amber-500" />
                  ) : (
                    <div className="h-4 w-4 rounded-full bg-deepGreen-200" />
                  )}
                </div>
                
                <div className="bg-deepGreen-50 rounded-lg p-4 hover:bg-deepGreen-100 transition-colors">
                  <h4 className="font-medium text-deepGreen-700">{milestone.title}</h4>
                  {milestone.description && (
                    <p className="text-sm text-deepGreen-600 mt-1">{milestone.description}</p>
                  )}
                  <div className="flex items-center gap-4 mt-2 text-xs text-deepGreen-500">
                    <span>Due: {format(new Date(milestone.due_date), 'MMM dd, yyyy')}</span>
                    <span className="flex items-center gap-1">
                      Progress: {milestone.completion_percentage}%
                    </span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
};

export default ProjectTimeline;