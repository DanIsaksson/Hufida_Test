import React from 'react';
import { motion } from "framer-motion";
import { Calendar, MessageSquare, Activity } from 'lucide-react';
import { TooltipProvider } from "@/components/ui/tooltip";
import RelatedSection from './RelatedSection';
import EventItem from './EventItem';
import EngagementItem from './EngagementItem';
import UpdateItem from './UpdateItem';

const ProjectRelatedData = ({ project, partnerEvents, communityEngagements, projectUpdates }) => {
  console.log('Rendering ProjectRelatedData with:', { partnerEvents, communityEngagements, projectUpdates });

  return (
    <TooltipProvider>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
        className="space-y-6"
      >
        <h2 className="text-2xl font-semibold text-deepGreen-800 mb-4">Related Activities</h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <RelatedSection
            title="Partner Events"
            icon={Calendar}
            isEmpty={!partnerEvents?.length}
            emptyMessage="No upcoming events"
          >
            {partnerEvents?.map((event) => (
              <EventItem key={event.id} event={event} />
            ))}
          </RelatedSection>

          <RelatedSection
            title="Community Engagements"
            icon={MessageSquare}
            isEmpty={!communityEngagements?.length}
            emptyMessage="No community engagements yet"
          >
            {communityEngagements?.map((engagement) => (
              <EngagementItem key={engagement.id} engagement={engagement} />
            ))}
          </RelatedSection>
        </div>

        <RelatedSection
          title="Recent Updates"
          icon={Activity}
          isEmpty={!projectUpdates?.length}
          emptyMessage="No recent updates"
        >
          {projectUpdates?.map((update) => (
            <UpdateItem key={update.id} update={update} />
          ))}
        </RelatedSection>
      </motion.div>
    </TooltipProvider>
  );
};

export default ProjectRelatedData;