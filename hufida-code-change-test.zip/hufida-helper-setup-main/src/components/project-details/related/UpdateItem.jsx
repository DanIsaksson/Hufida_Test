import React from 'react';
import { motion } from "framer-motion";
import { format } from 'date-fns';

const UpdateItem = ({ update }) => (
  <motion.div
    whileHover={{ scale: 1.02 }}
    initial={{ opacity: 0, y: 10 }}
    animate={{ opacity: 1, y: 0 }}
    className="p-3 bg-deepGreen-50 rounded-lg cursor-pointer hover:bg-deepGreen-100 transition-colors"
  >
    <div className="flex items-start justify-between">
      <div>
        <span className="inline-block px-2 py-1 text-xs font-medium rounded-full bg-deepGreen-100 text-deepGreen-700 mb-2">
          {update.update_type}
        </span>
        <p className="text-sm text-deepGreen-600">{update.description}</p>
      </div>
      <span className="text-xs text-deepGreen-500">
        {format(new Date(update.created_at), 'MMM dd, yyyy')}
      </span>
    </div>
  </motion.div>
);

export default UpdateItem;