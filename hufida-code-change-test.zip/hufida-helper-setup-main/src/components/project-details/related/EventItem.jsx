import React from 'react';
import { motion } from "framer-motion";
import { Calendar, Globe } from 'lucide-react';
import { format } from 'date-fns';

const EventItem = ({ event }) => (
  <motion.div
    whileHover={{ scale: 1.02 }}
    initial={{ opacity: 0, x: -10 }}
    animate={{ opacity: 1, x: 0 }}
    className="p-3 bg-deepGreen-50 rounded-lg cursor-pointer hover:bg-deepGreen-100 transition-colors"
  >
    <h3 className="font-medium text-deepGreen-700">{event.title}</h3>
    <p className="text-sm text-deepGreen-600">{event.description}</p>
    <div className="flex items-center gap-2 mt-2 text-xs text-deepGreen-500">
      <Calendar className="h-3 w-3" />
      <span>{format(new Date(event.event_date), 'MMM dd, yyyy')}</span>
      {event.location && (
        <>
          <Globe className="h-3 w-3 ml-2" />
          <span>{event.location}</span>
        </>
      )}
    </div>
  </motion.div>
);

export default EventItem;