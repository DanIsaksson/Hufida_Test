import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { neuCardStyles } from '../../../utils/styleUtils';

const RelatedSection = ({ title, icon: Icon, children, isEmpty, emptyMessage }) => (
  <Card className={`${neuCardStyles({ elevation: "medium" })} bg-white hover:shadow-lg transition-all duration-300`}>
    <CardHeader>
      <CardTitle className="flex items-center gap-2 text-deepGreen-700">
        <Icon className="h-5 w-5 text-deepGreen-600" />
        {title}
      </CardTitle>
    </CardHeader>
    <CardContent>
      <ScrollArea className="h-[200px] pr-4">
        {isEmpty ? (
          <p className="text-deepGreen-500 text-sm">{emptyMessage}</p>
        ) : (
          <div className="space-y-4">
            {children}
          </div>
        )}
      </ScrollArea>
    </CardContent>
  </Card>
);

export default RelatedSection;