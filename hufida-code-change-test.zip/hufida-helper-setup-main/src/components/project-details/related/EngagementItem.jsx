import React from 'react';
import { motion } from "framer-motion";
import { Users, Globe } from 'lucide-react';

const EngagementItem = ({ engagement }) => (
  <motion.div
    whileHover={{ scale: 1.02 }}
    initial={{ opacity: 0, x: -10 }}
    animate={{ opacity: 1, x: 0 }}
    className="p-3 bg-deepGreen-50 rounded-lg cursor-pointer hover:bg-deepGreen-100 transition-colors"
  >
    <h3 className="font-medium text-deepGreen-700">{engagement.title}</h3>
    <p className="text-sm text-deepGreen-600">{engagement.description}</p>
    <div className="flex items-center gap-2 mt-2 text-xs text-deepGreen-500">
      <Users className="h-3 w-3" />
      <span>{engagement.participants_count || 0} participants</span>
      {engagement.location && (
        <>
          <Globe className="h-3 w-3 ml-2" />
          <span>{engagement.location}</span>
        </>
      )}
    </div>
  </motion.div>
);

export default EngagementItem;