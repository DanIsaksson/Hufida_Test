import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const FeatureDialog = ({ feature, isOpen, onClose }) => {
  if (!feature) {
    return null;
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="neu-card bg-deepGreen-50 border-deepGreen-200">
        <DialogHeader>
          <DialogTitle className="text-deepGreen-800">{feature.title}</DialogTitle>
        </DialogHeader>
        <div className="mt-4">
          <p className="text-deepGreen-700">{feature.description}</p>
          {feature.details && feature.details.length > 0 && (
            <ul className="list-disc pl-5 mt-2 text-deepGreen-600">
              {feature.details.map((detail, idx) => (
                <li key={idx}>{detail}</li>
              ))}
            </ul>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default FeatureDialog;