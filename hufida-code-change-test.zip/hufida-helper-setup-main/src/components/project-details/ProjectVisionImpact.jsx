import React from 'react';
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Rocket, Lightbulb, ChartBar, Target, Users, Globe } from 'lucide-react';
import { neuCardStyles } from '../../utils/styleUtils';

const ProjectVisionImpact = ({ project }) => {
  const getProgressPercentage = () => {
    if (!project.impact_metrics || project.impact_metrics.length === 0) return 0;
    const completed = project.impact_metrics.filter(metric => metric.status === 'completed').length;
    return Math.round((completed / project.impact_metrics.length) * 100);
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, delay: 0.3 }}
      className="space-y-6"
    >
      <Card className={`${neuCardStyles()} bg-white/80 backdrop-blur-sm hover:shadow-lg transition-all duration-300`}>
        <CardHeader>
          <CardTitle className="text-2xl text-deepGreen-700 flex items-center gap-2">
            <Rocket className="h-6 w-6" />
            Vision & Impact
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {project.vision && (
            <motion.div 
              className="prose text-deepGreen-600"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <Lightbulb className="h-5 w-5 text-deepGreen-500" />
                Vision
              </h3>
              <p className="mt-2">{project.vision}</p>
            </motion.div>
          )}
          
          {project.impact && (
            <motion.div 
              className="prose text-deepGreen-600"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
            >
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <ChartBar className="h-5 w-5 text-deepGreen-500" />
                Impact
              </h3>
              <p className="mt-2">{project.impact}</p>
            </motion.div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
            {project.target_audience && (
              <motion.div 
                className="flex items-center gap-3 bg-deepGreen-50 p-4 rounded-lg"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.6 }}
              >
                <Target className="h-8 w-8 text-deepGreen-500" />
                <div>
                  <p className="font-semibold text-deepGreen-700">Target Audience</p>
                  <p className="text-sm text-deepGreen-600">{project.target_audience.join(', ')}</p>
                </div>
              </motion.div>
            )}

            {project.team_members && (
              <motion.div 
                className="flex items-center gap-3 bg-deepGreen-50 p-4 rounded-lg"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.7 }}
              >
                <Users className="h-8 w-8 text-deepGreen-500" />
                <div>
                  <p className="font-semibold text-deepGreen-700">Team Size</p>
                  <p className="text-sm text-deepGreen-600">{project.team_members.length} Members</p>
                </div>
              </motion.div>
            )}

            {project.location && (
              <motion.div 
                className="flex items-center gap-3 bg-deepGreen-50 p-4 rounded-lg"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.8 }}
              >
                <Globe className="h-8 w-8 text-deepGreen-500" />
                <div>
                  <p className="font-semibold text-deepGreen-700">Location</p>
                  <p className="text-sm text-deepGreen-600">{project.location}</p>
                </div>
              </motion.div>
            )}
          </div>

          {project.impact_metrics && project.impact_metrics.length > 0 && (
            <motion.div 
              className="mt-6 p-4 bg-deepGreen-50 rounded-lg"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.9 }}
            >
              <div className="flex justify-between items-center mb-2">
                <h4 className="font-semibold text-deepGreen-700">Overall Progress</h4>
                <span className="text-sm font-medium text-deepGreen-600">
                  {getProgressPercentage()}%
                </span>
              </div>
              <div className="w-full h-2 bg-deepGreen-200 rounded-full overflow-hidden">
                <motion.div 
                  className="h-full bg-deepGreen-500"
                  initial={{ width: 0 }}
                  animate={{ width: `${getProgressPercentage()}%` }}
                  transition={{ duration: 1, delay: 1 }}
                />
              </div>
            </motion.div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default ProjectVisionImpact;