import React from 'react';
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Book, FileText, Lightbulb, Search } from 'lucide-react';
import { format } from 'date-fns';

const getResourceIcon = (type) => {
  switch (type) {
    case 'documentation':
      return <FileText className="h-4 w-4" />;
    case 'guide':
      return <Book className="h-4 w-4" />;
    case 'best_practice':
      return <Lightbulb className="h-4 w-4" />;
    case 'case_study':
      return <FileText className="h-4 w-4" />; // Changed from CaseStudy to FileText
    case 'research':
      return <Search className="h-4 w-4" />;
    default:
      return <FileText className="h-4 w-4" />;
  }
};

const ResourceCard = ({ resource }) => {
  const initials = resource.created_by_profile?.full_name
    ?.split(' ')
    .map(n => n[0])
    .join('') || '?';

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="group"
    >
      <Card className="hover:shadow-md transition-shadow">
        <CardContent className="p-4">
          <div className="flex items-start gap-4">
            <Avatar>
              <AvatarImage src={resource.created_by_profile?.avatar_url} />
              <AvatarFallback>{initials}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-medium text-deepGreen-800">{resource.title}</h3>
                  <p className="text-sm text-deepGreen-600 mt-1">
                    {resource.created_by_profile?.full_name} • {format(new Date(resource.created_at), 'MMM dd, yyyy')}
                  </p>
                </div>
                <Badge 
                  variant="secondary"
                  className="flex items-center gap-1 bg-deepGreen-50 text-deepGreen-700"
                >
                  {getResourceIcon(resource.resource_type)}
                  <span className="capitalize">{resource.resource_type.replace('_', ' ')}</span>
                </Badge>
              </div>
              
              <p className="mt-3 text-deepGreen-700">{resource.content}</p>
              
              {resource.tags && resource.tags.length > 0 && (
                <div className="mt-3 flex flex-wrap gap-2">
                  {resource.tags.map((tag, index) => (
                    <Badge
                      key={index}
                      variant="outline"
                      className="text-xs bg-deepGreen-50/50"
                    >
                      {tag}
                    </Badge>
                  ))}
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default ResourceCard;