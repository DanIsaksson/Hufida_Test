import React from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Book, Tags } from 'lucide-react';
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import { supabase } from '@/lib/supabase';
import ResourceDialog from './ResourceDialog';
import ResourceCard from './ResourceCard';

const KnowledgeResources = ({ projectId }) => {
  const [isDialogOpen, setIsDialogOpen] = React.useState(false);
  const queryClient = useQueryClient();

  console.log('Rendering KnowledgeResources for project:', projectId);

  const { data: resources, isLoading } = useQuery({
    queryKey: ['knowledge-resources', projectId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('knowledge_resources')
        .select(`
          *,
          created_by_profile:profiles!created_by(
            full_name,
            avatar_url
          )
        `)
        .eq('project_id', projectId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data;
    },
  });

  const createResource = useMutation({
    mutationFn: async (resourceData) => {
      const { data, error } = await supabase
        .from('knowledge_resources')
        .insert([{ ...resourceData, project_id: projectId }])
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['knowledge-resources', projectId]);
      setIsDialogOpen(false);
      toast.success('Resource added successfully');
    },
    onError: (error) => {
      console.error('Error creating resource:', error);
      toast.error('Failed to add resource');
    },
  });

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-xl font-semibold flex items-center gap-2">
            <Book className="h-5 w-5 text-deepGreen-600" />
            Knowledge Resources
          </CardTitle>
          <Button 
            onClick={() => setIsDialogOpen(true)}
            className="bg-deepGreen-600 hover:bg-deepGreen-700"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Resource
          </Button>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[400px] pr-4">
            {isLoading ? (
              <div className="text-center py-8">Loading resources...</div>
            ) : resources?.length === 0 ? (
              <div className="text-center py-8 text-deepGreen-600">
                No resources added yet. Share your knowledge with the team!
              </div>
            ) : (
              <div className="space-y-4">
                {resources?.map((resource) => (
                  <ResourceCard 
                    key={resource.id} 
                    resource={resource}
                  />
                ))}
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>

      <ResourceDialog
        isOpen={isDialogOpen}
        setIsOpen={setIsDialogOpen}
        onSubmit={createResource.mutate}
        isSubmitting={createResource.isPending}
      />
    </motion.div>
  );
};

export default KnowledgeResources;