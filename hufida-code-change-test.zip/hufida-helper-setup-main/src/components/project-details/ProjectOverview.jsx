import React from 'react';
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar, Target, MapPin, Users, Globe, Briefcase, Tags, Rocket, Clock, Coins, Award } from 'lucide-react';
import { neuCardStyles } from '../../utils/styleUtils';
import { format } from 'date-fns';

const ProjectOverview = ({ project }) => {
  console.log('Rendering ProjectOverview with project:', project);
  
  const formatDate = (dateString) => {
    if (!dateString) return 'Not specified';
    return format(new Date(dateString), 'MMM dd, yyyy');
  };

  const statusColors = {
    draft: 'bg-gray-100 text-gray-600',
    active: 'bg-green-100 text-green-600',
    completed: 'bg-blue-100 text-blue-600',
    pending: 'bg-yellow-100 text-yellow-600'
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="space-y-6"
    >
      <Card className={`${neuCardStyles({ elevation: "medium" })} bg-white/95 backdrop-blur-sm hover:shadow-xl transition-all duration-300`}>
        <CardHeader className="border-b border-gray-100 pb-6">
          <CardTitle className="text-2xl text-deepGreen-700 flex items-center gap-3">
            <Globe className="h-7 w-7 text-deepGreen-600" />
            Project Overview
          </CardTitle>
          <p className="text-deepGreen-600 mt-2 text-lg">{project.description}</p>
          <div className="mt-4 flex flex-wrap gap-2">
            <span className={`px-3 py-1 rounded-full text-sm font-medium ${statusColors[project.project_status || 'draft']}`}>
              {project.project_status?.charAt(0).toUpperCase() + project.project_status?.slice(1) || 'Draft'}
            </span>
            {project.funding_status && (
              <span className="px-3 py-1 rounded-full bg-purple-100 text-purple-600 text-sm font-medium">
                {project.funding_status.charAt(0).toUpperCase() + project.funding_status.slice(1)}
              </span>
            )}
          </div>
        </CardHeader>
        <CardContent className="pt-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {project.start_date && (
              <div className="flex items-center gap-3 text-deepGreen-600 hover:text-deepGreen-700 transition-colors group">
                <div className="rounded-lg bg-deepGreen-50 p-2 group-hover:bg-deepGreen-100 transition-colors">
                  <Calendar className="h-5 w-5 text-deepGreen-500" />
                </div>
                <div>
                  <p className="text-sm text-deepGreen-500">Timeline</p>
                  <p className="font-medium">
                    {formatDate(project.start_date)} - {formatDate(project.end_date)}
                  </p>
                </div>
              </div>
            )}
            {project.budget && (
              <div className="flex items-center gap-3 text-deepGreen-600 hover:text-deepGreen-700 transition-colors group">
                <div className="rounded-lg bg-deepGreen-50 p-2 group-hover:bg-deepGreen-100 transition-colors">
                  <Coins className="h-5 w-5 text-deepGreen-500" />
                </div>
                <div>
                  <p className="text-sm text-deepGreen-500">Budget</p>
                  <p className="font-medium">${project.budget.toLocaleString()}</p>
                </div>
              </div>
            )}
            {project.category && (
              <div className="flex items-center gap-3 text-deepGreen-600 hover:text-deepGreen-700 transition-colors group">
                <div className="rounded-lg bg-deepGreen-50 p-2 group-hover:bg-deepGreen-100 transition-colors">
                  <Briefcase className="h-5 w-5 text-deepGreen-500" />
                </div>
                <div>
                  <p className="text-sm text-deepGreen-500">Category</p>
                  <p className="font-medium">{project.category}</p>
                </div>
              </div>
            )}
            {project.location && (
              <div className="flex items-center gap-3 text-deepGreen-600 hover:text-deepGreen-700 transition-colors group">
                <div className="rounded-lg bg-deepGreen-50 p-2 group-hover:bg-deepGreen-100 transition-colors">
                  <MapPin className="h-5 w-5 text-deepGreen-500" />
                </div>
                <div>
                  <p className="text-sm text-deepGreen-500">Location</p>
                  <p className="font-medium">{project.location}</p>
                </div>
              </div>
            )}
            {project.target_audience && project.target_audience.length > 0 && (
              <div className="flex items-center gap-3 text-deepGreen-600 hover:text-deepGreen-700 transition-colors group">
                <div className="rounded-lg bg-deepGreen-50 p-2 group-hover:bg-deepGreen-100 transition-colors">
                  <Target className="h-5 w-5 text-deepGreen-500" />
                </div>
                <div>
                  <p className="text-sm text-deepGreen-500">Target Audience</p>
                  <p className="font-medium">{project.target_audience.join(', ')}</p>
                </div>
              </div>
            )}
            {project.team_members && project.team_members.length > 0 && (
              <div className="flex items-center gap-3 text-deepGreen-600 hover:text-deepGreen-700 transition-colors group">
                <div className="rounded-lg bg-deepGreen-50 p-2 group-hover:bg-deepGreen-100 transition-colors">
                  <Users className="h-5 w-5 text-deepGreen-500" />
                </div>
                <div>
                  <p className="text-sm text-deepGreen-500">Team Size</p>
                  <p className="font-medium">{project.team_members.length} Members</p>
                </div>
              </div>
            )}
          </div>

          {project.tags && project.tags.length > 0 && (
            <div className="pt-4 border-t border-gray-100">
              <div className="flex items-center gap-2 flex-wrap">
                <Tags className="h-4 w-4 text-deepGreen-500" />
                {project.tags.map((tag, index) => (
                  <span
                    key={index}
                    className="px-3 py-1 bg-deepGreen-50 text-deepGreen-600 rounded-full text-sm font-medium"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          )}

          {project.innovation && (
            <div className="pt-4 border-t border-gray-100">
              <h3 className="text-lg font-semibold text-deepGreen-700 mb-2 flex items-center gap-2">
                <Award className="h-5 w-5 text-deepGreen-500" />
                Innovation
              </h3>
              <p className="text-deepGreen-600">{project.innovation}</p>
            </div>
          )}

          {project.approach && (
            <div className="pt-4 border-t border-gray-100">
              <h3 className="text-lg font-semibold text-deepGreen-700 mb-2 flex items-center gap-2">
                <Rocket className="h-5 w-5 text-deepGreen-500" />
                Approach
              </h3>
              <p className="text-deepGreen-600">{project.approach}</p>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default ProjectOverview;