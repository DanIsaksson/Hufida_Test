import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { motion } from "framer-motion";

const FeatureCard = ({ feature, onSelect }) => (
  <Tooltip>
    <TooltipTrigger asChild>
      <motion.div
        whileHover={{ scale: 1.02 }}
        transition={{ type: "spring", stiffness: 300 }}
      >
        <Card 
          className="neu-card hover:shadow-md transition-shadow duration-300 cursor-pointer bg-deepGreen-50 border-deepGreen-200"
          onClick={() => onSelect(feature)}
        >
          <CardHeader>
            <CardTitle className="text-lg text-deepGreen-700">{feature.title}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-deepGreen-600">{feature.description}</p>
          </CardContent>
        </Card>
      </motion.div>
    </TooltipTrigger>
    <TooltipContent>
      <p>Click to see details about {feature.title}</p>
    </TooltipContent>
  </Tooltip>
);

export default FeatureCard;