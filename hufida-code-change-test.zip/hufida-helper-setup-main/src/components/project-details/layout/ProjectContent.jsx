import React from 'react';
import { TabsContent } from "@/components/ui/tabs";
import ProjectOverview from '../ProjectOverview';
import ProjectVisionImpact from '../ProjectVisionImpact';
import ImpactStats from '@/components/ImpactStats';
import ProjectFeatures from '../ProjectFeatures';
import ProjectRelatedData from '../ProjectRelatedData';
import ProjectDiscussions from '../discussions/ProjectDiscussions';
import ProjectChat from '../chat/ProjectChat';
import KnowledgeResources from '../knowledge/KnowledgeResources';

const ProjectContent = ({ activeTab, project, relatedData, projectId }) => {
  return (
    <>
      <TabsContent value="overview" className="space-y-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <ProjectOverview project={project} />
          <ProjectVisionImpact project={project} />
        </div>
        <ImpactStats impacts={project.impacts} />
        <ProjectFeatures features={project.features} />
        <ProjectRelatedData
          project={project}
          partnerEvents={relatedData?.partnerEvents}
          communityEngagements={relatedData?.communityEngagements}
          projectUpdates={relatedData?.projectUpdates}
        />
      </TabsContent>

      <TabsContent value="discussions">
        <ProjectDiscussions projectId={projectId} />
      </TabsContent>

      <TabsContent value="knowledge">
        <KnowledgeResources projectId={projectId} />
      </TabsContent>

      <TabsContent value="chat">
        <ProjectChat projectId={projectId} />
      </TabsContent>
    </>
  );
};

export default ProjectContent;