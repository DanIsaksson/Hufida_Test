import React from 'react';
import { TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileText, MessageSquare, Book, MessageCircle } from 'lucide-react';

const ProjectTabs = () => {
  return (
    <TabsList className="bg-deepGreen-100/50 p-1">
      <TabsTrigger value="overview" className="flex items-center gap-2">
        <FileText className="h-4 w-4" />
        Overview
      </TabsTrigger>
      <TabsTrigger value="discussions" className="flex items-center gap-2">
        <MessageSquare className="h-4 w-4" />
        Discussions
      </TabsTrigger>
      <TabsTrigger value="knowledge" className="flex items-center gap-2">
        <Book className="h-4 w-4" />
        Knowledge
      </TabsTrigger>
      <TabsTrigger value="chat" className="flex items-center gap-2">
        <MessageCircle className="h-4 w-4" />
        Chat
      </TabsTrigger>
    </TabsList>
  );
};

export default ProjectTabs;