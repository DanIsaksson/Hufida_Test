import React from 'react';
import { Button } from "@/components/ui/button";
import { ChevronLeft, MessageSquare } from 'lucide-react';
import { motion } from "framer-motion";
import { useNavigate } from 'react-router-dom';

const ProjectHeader = ({ setIsDialogOpen }) => {
  const navigate = useNavigate();

  return (
    <motion.div 
      className="flex items-center justify-between"
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Button 
        variant="ghost" 
        className="text-deepGreen-600 hover:text-deepGreen-700 hover:bg-deepGreen-50"
        onClick={() => navigate(-1)}
      >
        <ChevronLeft className="mr-2 h-5 w-5" />
        Back to Projects
      </Button>
      <Button 
        className="bg-deepGreen-600 hover:bg-deepGreen-700 text-white shadow-sm hover:shadow-md flex items-center gap-2"
        onClick={() => setIsDialogOpen(true)}
      >
        <MessageSquare className="h-5 w-5" />
        Suggest Direction
      </Button>
    </motion.div>
  );
};

export default ProjectHeader;