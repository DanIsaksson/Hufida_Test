import React from 'react';
import { motion } from "framer-motion";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { format } from 'date-fns';

const ChatMessage = ({ message }) => {
  const initials = message.sender?.full_name
    ?.split(' ')
    .map(n => n[0])
    .join('') || '?';

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex items-start gap-3"
    >
      <Avatar className="h-8 w-8">
        <AvatarImage src={message.sender?.avatar_url} />
        <AvatarFallback>{initials}</AvatarFallback>
      </Avatar>
      <div className="flex-1">
        <div className="flex items-baseline gap-2">
          <span className="font-medium text-sm text-deepGreen-800">
            {message.sender?.full_name}
          </span>
          <span className="text-xs text-deepGreen-500">
            {format(new Date(message.created_at), 'HH:mm')}
          </span>
        </div>
        <p className="mt-1 text-sm text-deepGreen-700">{message.content}</p>
      </div>
    </motion.div>
  );
};

export default ChatMessage;