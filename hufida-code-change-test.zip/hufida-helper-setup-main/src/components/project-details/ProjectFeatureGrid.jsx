import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { motion } from "framer-motion";
import FeatureDialog from './FeatureDialog';

const ProjectFeatureGrid = ({ features }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, delay: 0.2 }}
  >
    <h2 className="text-2xl font-semibold mb-4 text-deepGreen-800">Key Features</h2>
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {features.map((feature, index) => (
        <Tooltip key={index}>
          <TooltipTrigger asChild>
            <Card className="neu-card hover:shadow-md transition-shadow duration-300 cursor-pointer bg-deepGreen-50 border-deepGreen-200">
              <CardHeader>
                <CardTitle className="text-lg text-deepGreen-700">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-deepGreen-600">{feature.description}</p>
              </CardContent>
            </Card>
          </TooltipTrigger>
          <TooltipContent>
            <p>Explore details about {feature.title}</p>
          </TooltipContent>
        </Tooltip>
      ))}
    </div>
  </motion.div>
);

export default ProjectFeatureGrid;