import React from 'react';
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { neuCardStyles } from '../../utils/styleUtils';
import { Code, Users, Rocket, Globe, Leaf, Recycle, BookOpen, Smartphone } from 'lucide-react';

const iconMap = {
  code: Code,
  users: Users,
  rocket: Rocket,
  globe: Globe,
  leaf: Leaf,
  recycle: Recycle,
  book: BookOpen,
  smartphone: Smartphone
};

const ProjectFeatures = ({ features }) => {
  console.log('Rendering ProjectFeatures with features:', features);

  if (!features || features.length === 0) {
    return null;
  }

  return (
    <TooltipProvider>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="space-y-6"
      >
        <motion.h2 
          className="text-3xl font-bold text-center text-deepGreen-800"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          Key Features
        </motion.h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => {
            const IconComponent = feature.icon_name ? iconMap[feature.icon_name.toLowerCase()] : Rocket;
            
            return (
              <Tooltip key={feature.id}>
                <TooltipTrigger asChild>
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    whileHover={{ scale: 1.02 }}
                    className="h-full"
                  >
                    <Card className={`${neuCardStyles({ elevation: "medium" })} bg-white hover:shadow-xl transition-all duration-300 cursor-pointer h-full group`}>
                      <CardHeader className="flex flex-row items-center gap-4 pb-2">
                        <div className="rounded-lg bg-deepGreen-100 p-2 group-hover:bg-deepGreen-200 transition-colors">
                          {IconComponent && <IconComponent className="h-6 w-6 text-deepGreen-600" />}
                        </div>
                        <CardTitle className="text-xl text-deepGreen-700">{feature.title}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-deepGreen-600 mb-4">{feature.description}</p>
                        {feature.details && feature.details.length > 0 && (
                          <motion.ul 
                            className="space-y-2"
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ delay: 0.2 }}
                          >
                            {feature.details.map((detail, idx) => (
                              <motion.li 
                                key={idx} 
                                className="flex items-center gap-2 text-sm text-deepGreen-500"
                                initial={{ opacity: 0, x: -10 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: 0.3 + idx * 0.1 }}
                              >
                                <div className="h-1.5 w-1.5 rounded-full bg-deepGreen-400 flex-shrink-0" />
                                <span>{detail}</span>
                              </motion.li>
                            ))}
                          </motion.ul>
                        )}
                      </CardContent>
                    </Card>
                  </motion.div>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Click to learn more about {feature.title}</p>
                </TooltipContent>
              </Tooltip>
            );
          })}
        </div>
      </motion.div>
    </TooltipProvider>
  );
};

export default ProjectFeatures;