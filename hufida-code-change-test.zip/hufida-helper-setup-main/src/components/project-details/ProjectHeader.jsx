import React from 'react';
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { neuCardStyles } from '../../utils/styleUtils';
import { ExternalLink, MapPin } from 'lucide-react';

const ProjectHeader = ({ project, partner }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="text-center space-y-6 mb-8"
    >
      {partner?.logo_url && (
        <motion.img 
          src={partner.logo_url} 
          alt={`${partner.name} logo`}
          className="h-20 mx-auto rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300"
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.2 }}
        />
      )}
      
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="space-y-4"
      >
        <h1 className="text-4xl font-bold bg-gradient-to-r from-deepGreen-600 via-deepGreen-500 to-deepGreen-400 bg-clip-text text-transparent">
          {project.title}
        </h1>
        
        <p className="text-xl text-deepGreen-600 max-w-3xl mx-auto leading-relaxed">
          {project.description}
        </p>

        <div className="flex items-center justify-center gap-4 text-sm text-deepGreen-500">
          {project.location && (
            <motion.div 
              className="flex items-center gap-2"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
            >
              <MapPin className="h-4 w-4" />
              <span>{project.location}</span>
            </motion.div>
          )}
          
          {project.website && (
            <motion.a
              href={project.website}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 hover:text-deepGreen-600 transition-colors"
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
            >
              <ExternalLink className="h-4 w-4" />
              <span>Visit Website</span>
            </motion.a>
          )}
        </div>
      </motion.div>

      {project.tags && project.tags.length > 0 && (
        <motion.div 
          className="flex flex-wrap justify-center gap-2 mt-4"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          {project.tags.map((tag, index) => (
            <motion.span
              key={tag}
              className="px-3 py-1 bg-deepGreen-50 text-deepGreen-600 rounded-full text-sm font-medium hover:bg-deepGreen-100 transition-colors"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5 + index * 0.1 }}
            >
              {tag}
            </motion.span>
          ))}
        </motion.div>
      )}
    </motion.div>
  );
};

export default ProjectHeader;