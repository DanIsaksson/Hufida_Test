import React, { useState } from 'react';
import { motion } from "framer-motion";
import FeatureList from './FeatureList';
import FeatureDialog from './FeatureDialog';

const FeatureSection = ({ features }) => {
  const [selectedFeature, setSelectedFeature] = useState(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const handleSelectFeature = (feature) => {
    setSelectedFeature(feature);
    setIsDialogOpen(true);
  };

  return (
    <div className="mt-8">
      <motion.h2 
        className="text-2xl font-semibold mb-4 text-deepGreen-800"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        Key Features
      </motion.h2>
      
      <FeatureList 
        features={features} 
        onSelectFeature={handleSelectFeature}
      />

      <FeatureDialog
        feature={selectedFeature}
        isOpen={isDialogOpen}
        onClose={() => setIsDialogOpen(false)}
      />
    </div>
  );
};

export default FeatureSection;