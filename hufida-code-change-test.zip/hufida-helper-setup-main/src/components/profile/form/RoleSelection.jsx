import React from 'react';
import { motion } from "framer-motion";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

const RoleSelection = ({ register, watch }) => {
  const role = watch("role");

  return (
    <motion.div 
      className="space-y-4"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      <Label>Select Role</Label>
      <RadioGroup defaultValue={role} className="grid grid-cols-2 gap-4">
        <motion.div 
          className="flex items-center space-x-2"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <RadioGroupItem
            value="volunteer"
            id="volunteer"
            {...register("role")}
          />
          <Label htmlFor="volunteer">Volunteer</Label>
        </motion.div>
        <motion.div 
          className="flex items-center space-x-2"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <RadioGroupItem
            value="partner"
            id="partner"
            {...register("role")}
          />
          <Label htmlFor="partner">Partner</Label>
        </motion.div>
      </RadioGroup>
    </motion.div>
  );
};

export default RoleSelection;