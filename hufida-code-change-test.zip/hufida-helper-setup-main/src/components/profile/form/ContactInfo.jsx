import React from 'react';
import { motion } from "framer-motion";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const ContactInfo = ({ register, errors }) => {
  return (
    <motion.div 
      className="space-y-4"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      <div>
        <Label htmlFor="contact_email">Contact Email</Label>
        <Input
          id="contact_email"
          type="email"
          {...register("contact_email", {
            required: "Contact email is required",
            pattern: {
              value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
              message: "Invalid email address",
            },
          })}
          className="mt-1"
        />
        {errors.contact_email && (
          <motion.p 
            className="text-red-500 text-sm mt-1"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            {errors.contact_email.message}
          </motion.p>
        )}
      </div>

      <div>
        <Label htmlFor="contact_phone">Phone Number</Label>
        <Input
          id="contact_phone"
          type="tel"
          {...register("contact_phone")}
          className="mt-1"
          placeholder="+1234567890"
        />
      </div>

      <div>
        <Label htmlFor="website">Website</Label>
        <Input
          id="website"
          type="url"
          {...register("website")}
          className="mt-1"
          placeholder="https://example.com"
        />
      </div>
    </motion.div>
  );
};

export default ContactInfo;