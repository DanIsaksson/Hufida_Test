import React from 'react';
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import VolunteerFieldsSkeleton from './VolunteerFieldsSkeleton';

const VolunteerFields = ({ register, isLoading }) => {
  if (isLoading) {
    return <VolunteerFieldsSkeleton />;
  }

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="skills">Skills</Label>
        <Input
          id="skills"
          {...register("skills")}
          className="mt-1"
          placeholder="Enter your skills (comma-separated)"
        />
      </div>

      <div>
        <Label htmlFor="availability">Availability</Label>
        <Select onValueChange={(value) => register("availability").onChange({ target: { value } })}>
          <SelectTrigger>
            <SelectValue placeholder="Select availability" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="full-time">Full Time</SelectItem>
            <SelectItem value="part-time">Part Time</SelectItem>
            <SelectItem value="weekends">Weekends</SelectItem>
            <SelectItem value="flexible">Flexible</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  );
};

export default VolunteerFields;