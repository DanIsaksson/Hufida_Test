import React from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from "sonner";
import { supabase } from '@/lib/supabase';
import { FormProvider } from './form/context/FormProvider';
import FormSections from './form/components/FormSections';
import FormActions from './form/components/FormActions';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { neuCardStyles } from '@/utils/styleUtils';

const ProjectForm = ({ initialData, onSuccess }) => {
  console.log('Rendering ProjectForm with initialData:', initialData);
  const queryClient = useQueryClient();

  const saveProject = useMutation({
    mutationFn: async (data) => {
      console.log('Submitting project data:', data);
      
      const projectData = {
        ...data,
        budget: data.budget === '' ? null : Number(data.budget),
        target_audience: Array.isArray(data.target_audience) ? data.target_audience : data.target_audience ? [data.target_audience] : [],
        tags: Array.isArray(data.tags) ? data.tags : data.tags ? data.tags.split(',').map(tag => tag.trim()) : [],
        features: data.features || [],
        impact_metrics: data.impact_metrics || [],
        objectives: data.objectives || [],
        partnerships: data.partnerships || []
      };

      if (initialData?.id) {
        const { data: result, error } = await supabase
          .from('projects')  // Changed from 'partners' to 'projects'
          .update(projectData)
          .eq('id', initialData.id)
          .select()
          .single();
        
        if (error) {
          console.error('Error updating project:', error);
          throw error;
        }
        return result;
      } else {
        const { data: result, error } = await supabase
          .from('projects')  // Changed from 'partners' to 'projects'
          .insert(projectData)
          .select()
          .single();
        
        if (error) {
          console.error('Error creating project:', error);
          throw error;
        }
        return result;
      }
    },
    onSuccess: (data) => {
      toast.success(initialData ? 'Project updated successfully' : 'Project created successfully');
      queryClient.invalidateQueries(['projects']);
      if (onSuccess) onSuccess(data.id);
    },
    onError: (error) => {
      console.error('Error saving project:', error);
      toast.error(`Failed to save project: ${error.message}`);
    },
  });

  const handleSubmit = (data) => {
    console.log('Form submitted with data:', data);
    saveProject.mutate(data);
  };

  return (
    <Card className={neuCardStyles()}>
      <CardHeader>
        <CardTitle>{initialData ? 'Edit Project' : 'Create New Project'}</CardTitle>
      </CardHeader>
      <CardContent>
        <FormProvider initialData={initialData} onSubmit={handleSubmit}>
          <FormSections />
          <FormActions />
        </FormProvider>
      </CardContent>
    </Card>
  );
};

export default ProjectForm;