import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import ObjectiveForm from './ObjectiveForm';

const ObjectiveDialog = ({ isOpen, setIsOpen, editingObjective, onSubmit }) => {
  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{editingObjective ? 'Edit Objective' : 'Add New Objective'}</DialogTitle>
        </DialogHeader>
        <ObjectiveForm 
          editingObjective={editingObjective} 
          onSubmit={onSubmit}
        />
      </DialogContent>
    </Dialog>
  );
};

export default ObjectiveDialog;