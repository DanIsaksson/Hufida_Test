import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { toast } from "sonner";

export const useObjectives = (projectId) => {
  const queryClient = useQueryClient();

  const { data: objectives, isLoading } = useQuery({
    queryKey: ['project-objectives', projectId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('project_objectives')
        .select('*')
        .eq('project_id', projectId)
        .order('order_index', { ascending: true });
      
      if (error) throw error;
      return data;
    },
  });

  const addObjective = useMutation({
    mutationFn: async (objectiveData) => {
      const orderIndex = objectives ? objectives.length : 0;
      const { error } = await supabase
        .from('project_objectives')
        .insert([{ ...objectiveData, project_id: projectId, order_index: orderIndex }]);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['project-objectives', projectId]);
      toast.success('Objective added successfully');
    },
    onError: (error) => {
      toast.error('Failed to add objective: ' + error.message);
    },
  });

  const updateObjective = useMutation({
    mutationFn: async ({ id, ...objectiveData }) => {
      const { error } = await supabase
        .from('project_objectives')
        .update(objectiveData)
        .eq('id', id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['project-objectives', projectId]);
      toast.success('Objective updated successfully');
    },
    onError: (error) => {
      toast.error('Failed to update objective: ' + error.message);
    },
  });

  const deleteObjective = useMutation({
    mutationFn: async (objectiveId) => {
      const { error } = await supabase
        .from('project_objectives')
        .delete()
        .eq('id', objectiveId);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['project-objectives', projectId]);
      toast.success('Objective deleted successfully');
    },
    onError: (error) => {
      toast.error('Failed to delete objective: ' + error.message);
    },
  });

  return {
    objectives,
    isLoading,
    addObjective,
    updateObjective,
    deleteObjective
  };
};