import React from 'react';
import { Button } from "@/components/ui/button";
import { Edit, Trash } from "lucide-react";

const ObjectiveCard = ({ objective, onEdit, onDelete }) => {
  return (
    <div
      key={objective.id}
      className="p-4 border rounded-lg flex justify-between items-start"
    >
      <div>
        <h4 className="font-semibold">{objective.title}</h4>
        <p className="text-sm text-gray-600">{objective.description}</p>
        <span className={`text-xs px-2 py-1 rounded-full ${
          objective.status === 'completed' ? 'bg-green-100 text-green-800' :
          objective.status === 'on_hold' ? 'bg-yellow-100 text-yellow-800' :
          'bg-blue-100 text-blue-800'
        }`}>
          {objective.status.replace('_', ' ')}
        </span>
      </div>
      <div className="flex gap-2">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => onEdit(objective)}
        >
          <Edit className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => {
            if (window.confirm('Are you sure you want to delete this objective?')) {
              onDelete(objective.id);
            }
          }}
        >
          <Trash className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
};

export default ObjectiveCard;