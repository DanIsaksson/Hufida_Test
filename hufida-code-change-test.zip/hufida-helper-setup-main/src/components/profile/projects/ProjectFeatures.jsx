import React from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Plus, Trash, Edit } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

const ProjectFeatures = ({ projectId }) => {
  const [isDialogOpen, setIsDialogOpen] = React.useState(false);
  const [editingFeature, setEditingFeature] = React.useState(null);
  const queryClient = useQueryClient();

  const { data: features, isLoading } = useQuery({
    queryKey: ['project-features', projectId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('project_features')
        .select('*')
        .eq('project_id', projectId)
        .order('created_at', { ascending: true });
      
      if (error) throw error;
      return data;
    },
  });

  const addFeature = useMutation({
    mutationFn: async (featureData) => {
      const { error } = await supabase
        .from('project_features')
        .insert([{ ...featureData, project_id: projectId }]);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['project-features', projectId]);
      setIsDialogOpen(false);
      setEditingFeature(null);
      toast.success('Feature added successfully');
    },
    onError: (error) => {
      toast.error('Failed to add feature: ' + error.message);
    },
  });

  const updateFeature = useMutation({
    mutationFn: async (featureData) => {
      const { error } = await supabase
        .from('project_features')
        .update(featureData)
        .eq('id', editingFeature.id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['project-features', projectId]);
      setIsDialogOpen(false);
      setEditingFeature(null);
      toast.success('Feature updated successfully');
    },
    onError: (error) => {
      toast.error('Failed to update feature: ' + error.message);
    },
  });

  const deleteFeature = useMutation({
    mutationFn: async (featureId) => {
      const { error } = await supabase
        .from('project_features')
        .delete()
        .eq('id', featureId);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['project-features', projectId]);
      toast.success('Feature deleted successfully');
    },
    onError: (error) => {
      toast.error('Failed to delete feature: ' + error.message);
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const data = {
      title: formData.get('title'),
      description: formData.get('description'),
      icon_name: formData.get('icon_name'),
    };

    if (editingFeature) {
      updateFeature.mutate({ ...data, id: editingFeature.id });
    } else {
      addFeature.mutate(data);
    }
  };

  if (isLoading) {
    return <div>Loading features...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Project Features</h3>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingFeature(null)}>
              <Plus className="mr-2 h-4 w-4" /> Add Feature
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingFeature ? 'Edit Feature' : 'Add New Feature'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  name="title"
                  defaultValue={editingFeature?.title}
                  required
                />
              </div>
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  name="description"
                  defaultValue={editingFeature?.description}
                  required
                />
              </div>
              <div>
                <Label htmlFor="icon_name">Icon Name</Label>
                <Input
                  id="icon_name"
                  name="icon_name"
                  defaultValue={editingFeature?.icon_name}
                  placeholder="e.g., map-pin, users, chart"
                />
              </div>
              <Button type="submit" className="w-full">
                {editingFeature ? 'Update Feature' : 'Add Feature'}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4">
        {features?.map((feature) => (
          <div
            key={feature.id}
            className="p-4 border rounded-lg flex justify-between items-start"
          >
            <div>
              <h4 className="font-semibold">{feature.title}</h4>
              <p className="text-sm text-gray-600">{feature.description}</p>
            </div>
            <div className="flex gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => {
                  setEditingFeature(feature);
                  setIsDialogOpen(true);
                }}
              >
                <Edit className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => {
                  if (window.confirm('Are you sure you want to delete this feature?')) {
                    deleteFeature.mutate(feature.id);
                  }
                }}
              >
                <Trash className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProjectFeatures;