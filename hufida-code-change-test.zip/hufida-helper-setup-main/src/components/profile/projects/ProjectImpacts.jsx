import React from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Plus, Trash, Edit } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

const ProjectImpacts = ({ projectId }) => {
  const [isDialogOpen, setIsDialogOpen] = React.useState(false);
  const [editingImpact, setEditingImpact] = React.useState(null);
  const queryClient = useQueryClient();

  const { data: impacts, isLoading } = useQuery({
    queryKey: ['project-impacts', projectId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('project_impacts')
        .select('*')
        .eq('project_id', projectId)
        .order('created_at', { ascending: true });
      
      if (error) throw error;
      return data;
    },
  });

  const addImpact = useMutation({
    mutationFn: async (impactData) => {
      const { error } = await supabase
        .from('project_impacts')
        .insert([{ ...impactData, project_id: projectId }]);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['project-impacts', projectId]);
      setIsDialogOpen(false);
      setEditingImpact(null);
      toast.success('Impact metric added successfully');
    },
    onError: (error) => {
      toast.error('Failed to add impact metric: ' + error.message);
    },
  });

  const updateImpact = useMutation({
    mutationFn: async (impactData) => {
      const { error } = await supabase
        .from('project_impacts')
        .update(impactData)
        .eq('id', editingImpact.id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['project-impacts', projectId]);
      setIsDialogOpen(false);
      setEditingImpact(null);
      toast.success('Impact metric updated successfully');
    },
    onError: (error) => {
      toast.error('Failed to update impact metric: ' + error.message);
    },
  });

  const deleteImpact = useMutation({
    mutationFn: async (impactId) => {
      const { error } = await supabase
        .from('project_impacts')
        .delete()
        .eq('id', impactId);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['project-impacts', projectId]);
      toast.success('Impact metric deleted successfully');
    },
    onError: (error) => {
      toast.error('Failed to delete impact metric: ' + error.message);
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const data = {
      metric_name: formData.get('metric_name'),
      current_value: parseFloat(formData.get('current_value')),
      target_value: parseFloat(formData.get('target_value')),
      unit: formData.get('unit'),
      category: formData.get('category'),
    };

    if (editingImpact) {
      updateImpact.mutate({ ...data, id: editingImpact.id });
    } else {
      addImpact.mutate(data);
    }
  };

  if (isLoading) {
    return <div>Loading impact metrics...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Impact Metrics</h3>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingImpact(null)}>
              <Plus className="mr-2 h-4 w-4" /> Add Impact Metric
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingImpact ? 'Edit Impact Metric' : 'Add New Impact Metric'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="metric_name">Metric Name</Label>
                <Input
                  id="metric_name"
                  name="metric_name"
                  defaultValue={editingImpact?.metric_name}
                  required
                />
              </div>
              <div>
                <Label htmlFor="current_value">Current Value</Label>
                <Input
                  id="current_value"
                  name="current_value"
                  type="number"
                  step="0.01"
                  defaultValue={editingImpact?.current_value}
                  required
                />
              </div>
              <div>
                <Label htmlFor="target_value">Target Value</Label>
                <Input
                  id="target_value"
                  name="target_value"
                  type="number"
                  step="0.01"
                  defaultValue={editingImpact?.target_value}
                  required
                />
              </div>
              <div>
                <Label htmlFor="unit">Unit</Label>
                <Input
                  id="unit"
                  name="unit"
                  defaultValue={editingImpact?.unit}
                  required
                />
              </div>
              <div>
                <Label htmlFor="category">Category</Label>
                <Input
                  id="category"
                  name="category"
                  defaultValue={editingImpact?.category}
                  required
                />
              </div>
              <Button type="submit" className="w-full">
                {editingImpact ? 'Update Impact Metric' : 'Add Impact Metric'}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4">
        {impacts?.map((impact) => (
          <div
            key={impact.id}
            className="p-4 border rounded-lg flex justify-between items-start"
          >
            <div>
              <h4 className="font-semibold">{impact.metric_name}</h4>
              <p className="text-sm text-gray-600">
                Current: {impact.current_value} {impact.unit} / 
                Target: {impact.target_value} {impact.unit}
              </p>
              <span className="text-xs bg-gray-100 text-gray-800 px-2 py-1 rounded-full">
                {impact.category}
              </span>
            </div>
            <div className="flex gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => {
                  setEditingImpact(impact);
                  setIsDialogOpen(true);
                }}
              >
                <Edit className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => {
                  if (window.confirm('Are you sure you want to delete this impact metric?')) {
                    deleteImpact.mutate(impact.id);
                  }
                }}
              >
                <Trash className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProjectImpacts;