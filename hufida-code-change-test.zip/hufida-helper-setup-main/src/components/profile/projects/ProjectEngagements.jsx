import React from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Plus, Trash, Edit } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

const ProjectEngagements = ({ projectId }) => {
  const [isDialogOpen, setIsDialogOpen] = React.useState(false);
  const [editingEngagement, setEditingEngagement] = React.useState(null);
  const queryClient = useQueryClient();

  const { data: engagements, isLoading } = useQuery({
    queryKey: ['project-engagements', projectId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('community_engagements')
        .select('*')
        .eq('project_id', projectId)
        .order('start_date', { ascending: false });
      
      if (error) throw error;
      return data;
    },
  });

  const addEngagement = useMutation({
    mutationFn: async (engagementData) => {
      const { error } = await supabase
        .from('community_engagements')
        .insert([{ ...engagementData, project_id: projectId }]);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['project-engagements', projectId]);
      setIsDialogOpen(false);
      setEditingEngagement(null);
      toast.success('Engagement added successfully');
    },
    onError: (error) => {
      toast.error('Failed to add engagement: ' + error.message);
    },
  });

  const updateEngagement = useMutation({
    mutationFn: async (engagementData) => {
      const { error } = await supabase
        .from('community_engagements')
        .update(engagementData)
        .eq('id', editingEngagement.id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['project-engagements', projectId]);
      setIsDialogOpen(false);
      setEditingEngagement(null);
      toast.success('Engagement updated successfully');
    },
    onError: (error) => {
      toast.error('Failed to update engagement: ' + error.message);
    },
  });

  const deleteEngagement = useMutation({
    mutationFn: async (engagementId) => {
      const { error } = await supabase
        .from('community_engagements')
        .delete()
        .eq('id', engagementId);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['project-engagements', projectId]);
      toast.success('Engagement deleted successfully');
    },
    onError: (error) => {
      toast.error('Failed to delete engagement: ' + error.message);
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const data = {
      title: formData.get('title'),
      description: formData.get('description'),
      engagement_type: formData.get('engagement_type'),
      location: formData.get('location'),
      start_date: formData.get('start_date'),
      end_date: formData.get('end_date'),
      participants_count: parseInt(formData.get('participants_count'), 10) || 0,
      status: formData.get('status') || 'active',
    };

    if (editingEngagement) {
      updateEngagement.mutate({ ...data, id: editingEngagement.id });
    } else {
      addEngagement.mutate(data);
    }
  };

  if (isLoading) {
    return <div>Loading engagements...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Community Engagements</h3>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingEngagement(null)}>
              <Plus className="mr-2 h-4 w-4" /> Add Engagement
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingEngagement ? 'Edit Engagement' : 'Add New Engagement'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  name="title"
                  defaultValue={editingEngagement?.title}
                  required
                />
              </div>
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  name="description"
                  defaultValue={editingEngagement?.description}
                  required
                />
              </div>
              <div>
                <Label htmlFor="engagement_type">Type</Label>
                <select
                  id="engagement_type"
                  name="engagement_type"
                  className="w-full border rounded-md p-2"
                  defaultValue={editingEngagement?.engagement_type || 'workshop'}
                >
                  <option value="workshop">Workshop</option>
                  <option value="training">Training</option>
                  <option value="community_meeting">Community Meeting</option>
                  <option value="awareness_campaign">Awareness Campaign</option>
                </select>
              </div>
              <div>
                <Label htmlFor="location">Location</Label>
                <Input
                  id="location"
                  name="location"
                  defaultValue={editingEngagement?.location}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="start_date">Start Date</Label>
                  <Input
                    id="start_date"
                    name="start_date"
                    type="datetime-local"
                    defaultValue={editingEngagement?.start_date}
                  />
                </div>
                <div>
                  <Label htmlFor="end_date">End Date</Label>
                  <Input
                    id="end_date"
                    name="end_date"
                    type="datetime-local"
                    defaultValue={editingEngagement?.end_date}
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="participants_count">Number of Participants</Label>
                <Input
                  id="participants_count"
                  name="participants_count"
                  type="number"
                  defaultValue={editingEngagement?.participants_count || 0}
                />
              </div>
              <div>
                <Label htmlFor="status">Status</Label>
                <select
                  id="status"
                  name="status"
                  className="w-full border rounded-md p-2"
                  defaultValue={editingEngagement?.status || 'active'}
                >
                  <option value="active">Active</option>
                  <option value="completed">Completed</option>
                  <option value="cancelled">Cancelled</option>
                  <option value="postponed">Postponed</option>
                </select>
              </div>
              <Button type="submit" className="w-full">
                {editingEngagement ? 'Update Engagement' : 'Add Engagement'}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4">
        {engagements?.map((engagement) => (
          <div
            key={engagement.id}
            className="p-4 border rounded-lg flex justify-between items-start"
          >
            <div>
              <h4 className="font-semibold">{engagement.title}</h4>
              <p className="text-sm text-gray-600">{engagement.description}</p>
              <div className="mt-2 space-x-2">
                <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
                  {engagement.engagement_type.replace('_', ' ')}
                </span>
                <span className={`text-xs px-2 py-1 rounded-full ${
                  engagement.status === 'active' ? 'bg-green-100 text-green-800' :
                  engagement.status === 'completed' ? 'bg-blue-100 text-blue-800' :
                  engagement.status === 'cancelled' ? 'bg-red-100 text-red-800' :
                  'bg-yellow-100 text-yellow-800'
                }`}>
                  {engagement.status}
                </span>
              </div>
              <div className="mt-2 text-sm text-gray-500">
                <p>Location: {engagement.location}</p>
                <p>Participants: {engagement.participants_count}</p>
                {engagement.start_date && (
                  <p>
                    Date: {new Date(engagement.start_date).toLocaleDateString()}
                    {engagement.end_date && ` - ${new Date(engagement.end_date).toLocaleDateString()}`}
                  </p>
                )}
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => {
                  setEditingEngagement(engagement);
                  setIsDialogOpen(true);
                }}
              >
                <Edit className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => {
                  if (window.confirm('Are you sure you want to delete this engagement?')) {
                    deleteEngagement.mutate(engagement.id);
                  }
                }}
              >
                <Trash className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProjectEngagements;