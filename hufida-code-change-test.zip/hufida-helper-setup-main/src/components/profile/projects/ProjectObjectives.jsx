import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import ObjectiveDialog from './objectives/ObjectiveDialog';
import ObjectiveCard from './objectives/ObjectiveCard';
import { useObjectives } from './objectives/useObjectives';

const ProjectObjectives = ({ projectId }) => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingObjective, setEditingObjective] = useState(null);
  
  const {
    objectives,
    isLoading,
    addObjective,
    updateObjective,
    deleteObjective
  } = useObjectives(projectId);

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const data = {
      title: formData.get('title'),
      description: formData.get('description'),
      status: formData.get('status') || 'in_progress',
    };

    if (editingObjective) {
      updateObjective.mutate({ ...data, id: editingObjective.id });
    } else {
      addObjective.mutate(data);
    }
    setIsDialogOpen(false);
    setEditingObjective(null);
  };

  if (isLoading) {
    return <div>Loading objectives...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Project Objectives</h3>
        <Button onClick={() => {
          setEditingObjective(null);
          setIsDialogOpen(true);
        }}>
          <Plus className="mr-2 h-4 w-4" /> Add Objective
        </Button>
      </div>

      <div className="grid gap-4">
        {objectives?.map((objective) => (
          <ObjectiveCard
            key={objective.id}
            objective={objective}
            onEdit={(obj) => {
              setEditingObjective(obj);
              setIsDialogOpen(true);
            }}
            onDelete={(id) => deleteObjective.mutate(id)}
          />
        ))}
      </div>

      <ObjectiveDialog
        isOpen={isDialogOpen}
        setIsOpen={setIsDialogOpen}
        editingObjective={editingObjective}
        onSubmit={handleSubmit}
      />
    </div>
  );
};

export default ProjectObjectives;