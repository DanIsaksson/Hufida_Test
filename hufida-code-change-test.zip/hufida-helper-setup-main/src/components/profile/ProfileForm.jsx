import React from 'react';
import { useForm } from 'react-hook-form';
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { useAuth } from '../AuthProvider';
import { supabase } from '@/lib/supabase';
import FormSkeleton from './form/FormSkeleton';
import PersonalInfo from './form/PersonalInfo';
import ContactInfo from './form/ContactInfo';
import RoleSelection from './form/RoleSelection';
import VolunteerFields from './form/VolunteerFields';

const ProfileForm = ({ initialData, isLoading }) => {
  const { user } = useAuth();
  const { toast } = useToast();
  
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors, isSubmitting },
  } = useForm({
    defaultValues: initialData || {
      role: 'volunteer',
    },
  });

  const onSubmit = async (data) => {
    try {
      console.log('Submitting profile data:', data);
      const { error } = await supabase
        .from('profiles')
        .upsert({
          id: user.id,
          ...data,
          updated_at: new Date().toISOString(),
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Profile updated successfully",
      });
    } catch (error) {
      console.error('Error updating profile:', error);
      toast({
        title: "Error",
        description: "Failed to update profile",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return <FormSkeleton />;
  }

  const role = watch("role");

  return (
    <motion.form
      onSubmit={handleSubmit(onSubmit)}
      className="space-y-8"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="grid gap-8 md:grid-cols-2">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
          className="space-y-6"
        >
          <PersonalInfo register={register} errors={errors} />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="space-y-6"
        >
          <ContactInfo register={register} errors={errors} />
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="space-y-6"
      >
        <RoleSelection register={register} watch={watch} />
      </motion.div>

      {role === "volunteer" && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="space-y-6"
        >
          <VolunteerFields register={register} isLoading={isLoading} />
        </motion.div>
      )}

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="flex justify-end pt-4"
      >
        <Button 
          type="submit" 
          className="w-full md:w-auto bg-primary hover:bg-primary/90 text-primary-foreground"
          disabled={isSubmitting}
        >
          {isSubmitting ? 'Saving...' : 'Save Profile'}
        </Button>
      </motion.div>
    </motion.form>
  );
};

export default ProfileForm;