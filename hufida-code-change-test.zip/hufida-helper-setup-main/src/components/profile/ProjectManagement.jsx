import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { useAuth } from '../AuthProvider';
import ProjectManagementSkeleton from './projects/ProjectManagementSkeleton';

const ProjectManagement = () => {
  const { user } = useAuth();

  const { data: projects, isLoading } = useQuery({
    queryKey: ['user-projects', user?.id],
    queryFn: async () => {
      console.log('Fetching projects for user:', user?.id);
      const { data, error } = await supabase
        .from('partners')
        .select('*')
        .eq('created_by', user?.id);

      if (error) throw error;
      console.log('Fetched projects:', data);
      return data;
    },
    enabled: !!user,
  });

  if (isLoading) {
    return <ProjectManagementSkeleton />;
  }

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold">Your Projects</h2>
      {projects.length === 0 ? (
        <p className="text-gray-500">You have no projects yet.</p>
      ) : (
        projects.map((project) => (
          <div key={project.id} className="p-4 border rounded-lg">
            <h3 className="text-xl font-bold">{project.title}</h3>
            <p className="text-gray-700">{project.description}</p>
            <div className="flex justify-end mt-4">
              <button className="text-blue-500 hover:underline">Edit</button>
              <button className="text-red-500 hover:underline ml-4">Delete</button>
            </div>
          </div>
        ))
      )}
    </div>
  );
};

export default ProjectManagement;
