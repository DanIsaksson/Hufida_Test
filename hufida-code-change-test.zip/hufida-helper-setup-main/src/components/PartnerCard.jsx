/**
 * @component PartnerCard
 * @description A card component that displays detailed information about a partner organization
 * including their logo, name, type, description, and metadata.
 * 
 * @example
 * ```jsx
 * const partner = {
 *   name: "Green Earth Initiative",
 *   logo_url: "/path/to/logo.png",
 *   partner_type: "Environmental",
 *   website: "https://example.com",
 *   description: "Partner description",
 *   location: "Nairobi, Kenya"
 * };
 * 
 * <PartnerCard partner={partner} />
 * ```
 * 
 * @param {Object} props
 * @param {Object} props.partner - The partner object containing organization details
 * @param {string} props.partner.name - Organization name
 * @param {string} props.partner.logo_url - URL to organization's logo
 * @param {string} props.partner.partner_type - Type of partnership
 * @param {string} props.partner.website - Organization's website URL
 * @param {string} props.partner.description - Brief description of the organization
 * @param {string} props.partner.location - Organization's location
 */
import React from 'react';
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { neuCardStyles } from '../utils/styleUtils';
import PartnerCardHeader from './partners/PartnerCardHeader';
import PartnerCardContent from './partners/PartnerCardContent';

const PartnerCard = ({ partner }) => {
  const [imageLoaded, setImageLoaded] = React.useState(false);
  const [imageError, setImageError] = React.useState(false);

  // Map Supabase fields to component props
  const mappedPartner = {
    ...partner,
    logo: partner.logo_url,
    partnerType: partner.partner_type
  };

  console.log(`Rendering PartnerCard for ${partner.name}`);

  return (
    <motion.div
      variants={{
        hidden: { opacity: 0, y: 50 },
        visible: { 
          opacity: 1, 
          y: 0,
          transition: {
            type: "spring",
            damping: 15,
            stiffness: 80,
          },
        },
      }}
      whileHover={{ scale: 1.02 }}
      className="h-full"
    >
      <Card 
        className={`
          ${neuCardStyles({ elevation: "medium" })} 
          flex flex-col h-full 
          bg-deepGreen-800/90 border-deepGreen-700
          hover:bg-deepGreen-800/95 transition-all duration-500
          backdrop-blur-lg rounded-xl overflow-hidden
          shadow-[0_8px_30px_rgb(0,0,0,0.12)]
          group
        `}
      >
        <PartnerCardHeader 
          partner={mappedPartner}
          imageLoaded={imageLoaded}
          setImageLoaded={setImageLoaded}
          imageError={imageError}
          setImageError={setImageError}
        />
        <PartnerCardContent partner={mappedPartner} />
      </Card>
    </motion.div>
  );
};

export default PartnerCard;