import React from 'react';
import { TooltipProvider } from "@/components/ui/tooltip";
import FeatureSection from './project-details/FeatureSection';

const ProjectFeatures = ({ features }) => {
  if (!features || features.length === 0) {
    return null;
  }

  return (
    <TooltipProvider>
      <FeatureSection features={features} />
    </TooltipProvider>
  );
};

export default ProjectFeatures;