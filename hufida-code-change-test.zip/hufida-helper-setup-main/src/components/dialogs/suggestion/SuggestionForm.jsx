import React from 'react';
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { neuTextareaStyles } from '../../../utils/styleUtils';

const SuggestionForm = ({ suggestion, setSuggestion, changeValue, setChangeValue, impactValue, setImpactValue, feasibilityValue, setFeasibilityValue }) => {
  return (
    <div className="space-y-6">
      <div>
        <label htmlFor="suggestion" className="block text-sm font-medium mb-2 text-white/90">
          Your Suggestion:
        </label>
        <Textarea
          id="suggestion"
          value={suggestion}
          onChange={(e) => setSuggestion(e.target.value)}
          placeholder="What direction would you like to see this project take?"
          className={`${neuTextareaStyles()} bg-deepGreen-800/50 text-white placeholder-white/50 min-h-[120px] border-deepGreen-600`}
        />
      </div>
      
      <div className="space-y-6">
        <SliderInput
          label="Degree of Change:"
          value={changeValue}
          onChange={setChangeValue}
          leftLabel="Minor"
          rightLabel="Major"
        />
        <SliderInput
          label="Potential Impact:"
          value={impactValue}
          onChange={setImpactValue}
          leftLabel="Low"
          rightLabel="High"
        />
        <SliderInput
          label="Feasibility:"
          value={feasibilityValue}
          onChange={setFeasibilityValue}
          leftLabel="Challenging"
          rightLabel="Easily Achievable"
        />
      </div>
    </div>
  );
};

const SliderInput = ({ label, value, onChange, leftLabel, rightLabel }) => (
  <div className="space-y-2">
    <label className="block text-sm font-medium text-white/90">
      {label}
    </label>
    <Slider
      value={value}
      onValueChange={onChange}
      max={100}
      step={1}
      className="w-full h-2 bg-deepGreen-600/50 rounded-full"
    />
    <div className="flex items-center justify-between text-xs text-white/70">
      <span>{leftLabel}</span>
      <span>{rightLabel}</span>
    </div>
  </div>
);

export default SuggestionForm;