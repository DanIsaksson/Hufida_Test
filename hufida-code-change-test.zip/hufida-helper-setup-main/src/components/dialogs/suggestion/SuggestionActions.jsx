import React from 'react';
import { Button } from "@/components/ui/button";
import { ExternalLink } from 'lucide-react';
import { neuButtonStyles } from '../../../utils/styleUtils';

const SuggestionActions = ({ onSubmit, onDonate, isSubmitting }) => {
  return (
    <div className="flex justify-between items-center pt-6">
      <Button
        onClick={onSubmit}
        disabled={isSubmitting}
        className="bg-deepGreen-600 hover:bg-deepGreen-500 text-white px-6 py-2 rounded-md transition-colors"
      >
        {isSubmitting ? "Submitting..." : "Submit Suggestion"}
      </Button>
      <Button 
        onClick={onDonate}
        variant="outline"
        className="bg-transparent border border-deepGreen-400 text-white hover:bg-deepGreen-700 px-6 py-2 rounded-md transition-colors flex items-center gap-2"
      >
        Press Forward <ExternalLink className="h-4 w-4" />
      </Button>
    </div>
  );
};

export default SuggestionActions;