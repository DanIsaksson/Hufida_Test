import React from 'react';
import { Button } from "@/components/ui/button";
import { MessageSquare, ExternalLink } from 'lucide-react';
import { neuButtonStyles } from '../../../utils/styleUtils';

const DialogActions = ({ onSubmit, onDonate }) => {
  return (
    <div className="flex justify-between pt-4">
      <Button 
        onClick={onSubmit} 
        className={`${neuButtonStyles({ variant: "primary" })} gap-2`}
      >
        <MessageSquare className="h-4 w-4" />
        Submit Suggestion
      </Button>
      <Button 
        className={neuButtonStyles({ variant: "secondary" })}
        onClick={onDonate}
      >
        Press Forward <ExternalLink className="ml-2 h-4 w-4" />
      </Button>
    </div>
  );
};

export default DialogActions;