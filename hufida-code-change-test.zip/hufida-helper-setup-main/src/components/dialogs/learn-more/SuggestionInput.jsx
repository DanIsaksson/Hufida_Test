import React from 'react';
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { neuTextareaStyles, neuSliderStyles } from '../../../utils/styleUtils';

const SuggestionInput = ({ suggestion, setSuggestion, nuanceValue, setNuanceValue }) => {
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-white/90">Suggest a Direction</h3>
      <Textarea
        placeholder="What direction would you like to see this project take?"
        value={suggestion}
        onChange={(e) => setSuggestion(e.target.value)}
        className={`${neuTextareaStyles()} bg-deepGreen-800/50 text-white placeholder-white/50 min-h-[120px] border-deepGreen-600`}
      />
      <div>
        <label className="block text-sm font-medium text-white/90 mb-2">
          Degree of Change:
        </label>
        <Slider
          value={nuanceValue}
          onValueChange={setNuanceValue}
          max={100}
          step={1}
          className={`mb-2 ${neuSliderStyles()}`}
        />
        <div className="flex justify-between text-xs text-white/70">
          <span>Minor Adjustment</span>
          <span>Moderate Change</span>
          <span>Major Overhaul</span>
        </div>
      </div>
    </div>
  );
};

export default SuggestionInput;