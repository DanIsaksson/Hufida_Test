import React from 'react';
import { formatDate } from '../../../utils/styleUtils';

const ProjectDescription = ({ project }) => {
  return (
    <div className="space-y-6">
      <div className="bg-deepGreen-50/50 rounded-lg p-4">
        <h3 className="text-lg font-semibold mb-2 text-deepGreen-700">Project Description</h3>
        <p className="text-deepGreen-600">{project.description}</p>
      </div>
      
      <div className="bg-deepGreen-50/50 rounded-lg p-4">
        <h3 className="text-lg font-semibold mb-2 text-deepGreen-700">Current Status</h3>
        <p className="text-deepGreen-600">{project.status}</p>
        <p className="text-sm text-deepGreen-500 mt-2">
          Started: {formatDate(project.startDate)}
        </p>
      </div>
    </div>
  );
};

export default ProjectDescription;