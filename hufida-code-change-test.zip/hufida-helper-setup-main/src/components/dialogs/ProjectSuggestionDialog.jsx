import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/hooks/useAuthState';
import SuggestionForm from './suggestion/SuggestionForm';
import SuggestionActions from './suggestion/SuggestionActions';

const ProjectSuggestionDialog = ({ 
  isOpen, 
  setIsOpen, 
  project,
  projectId,
  projectTitle 
}) => {
  const [suggestion, setSuggestion] = React.useState('');
  const [changeValue, setChangeValue] = React.useState([50]);
  const [impactValue, setImpactValue] = React.useState([50]);
  const [feasibilityValue, setFeasibilityValue] = React.useState([50]);
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const { toast } = useToast();
  const { user } = useAuth();

  console.log('Rendering ProjectSuggestionDialog for project:', projectId);

  const handleSubmitSuggestion = async () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please sign in to submit suggestions",
        variant: "destructive"
      });
      return;
    }

    if (!suggestion.trim()) {
      toast({
        title: "Missing information",
        description: "Please provide a suggestion",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);
    console.log('Submitting suggestion:', {
      projectId,
      suggestion,
      changeValue: changeValue[0],
      impactValue: impactValue[0],
      feasibilityValue: feasibilityValue[0]
    });

    try {
      const { error } = await supabase
        .from('project_suggestions')
        .insert({
          project_id: projectId,
          suggested_by: user.id,
          suggestion: suggestion.trim(),
          degree_of_change: changeValue[0],
          potential_impact: impactValue[0],
          feasibility: feasibilityValue[0]
        });

      if (error) throw error;

      toast({
        title: "Suggestion submitted",
        description: "Thank you for your contribution!",
      });

      setIsOpen(false);
      setSuggestion('');
      setChangeValue([50]);
      setImpactValue([50]);
      setFeasibilityValue([50]);
    } catch (error) {
      console.error('Error submitting suggestion:', error);
      toast({
        title: "Error submitting suggestion",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePressForward = () => {
    const revolutLink = `https://revolut.me/davidxt0s/10`;
    window.open(revolutLink, '_blank', 'noopener,noreferrer');
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="max-w-md mx-auto bg-deepGreen-900 text-white border border-deepGreen-700 shadow-xl">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold text-white mb-1">
            Suggest a Direction for {projectTitle}
          </DialogTitle>
          <DialogDescription className="text-white/70">
            Share your ideas to improve or redirect this project.
          </DialogDescription>
        </DialogHeader>
        
        {project && (
          <div className="space-y-4 mb-6">
            <div className="bg-deepGreen-800/50 p-4 rounded-lg">
              <h3 className="text-sm font-medium text-white/90 mb-2">Current Project Status</h3>
              <p className="text-sm text-white/70">{project.description}</p>
            </div>
          </div>
        )}
        
        <SuggestionForm
          suggestion={suggestion}
          setSuggestion={setSuggestion}
          changeValue={changeValue}
          setChangeValue={setChangeValue}
          impactValue={impactValue}
          setImpactValue={setImpactValue}
          feasibilityValue={feasibilityValue}
          setFeasibilityValue={setFeasibilityValue}
        />
        
        <SuggestionActions
          onSubmit={handleSubmitSuggestion}
          onDonate={handlePressForward}
          isSubmitting={isSubmitting}
        />
      </DialogContent>
    </Dialog>
  );
};

export default ProjectSuggestionDialog;