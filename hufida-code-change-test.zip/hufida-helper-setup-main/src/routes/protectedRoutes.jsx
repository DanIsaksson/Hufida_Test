import { Navigate } from 'react-router-dom';
import PartnerDashboard from '@/components/dashboard/PartnerDashboard';
import VolunteerDashboard from '@/components/dashboard/VolunteerDashboard';

export const createProtectedRoutes = (hasRequiredRole) => [
  {
    path: '/dashboard/partner',
    element: <PartnerDashboard />,
    requiresAuth: true,
    role: 'partner',
  },
  {
    path: '/dashboard/volunteer',
    element: <VolunteerDashboard />,
    requiresAuth: true,
    role: 'volunteer',
  },
];