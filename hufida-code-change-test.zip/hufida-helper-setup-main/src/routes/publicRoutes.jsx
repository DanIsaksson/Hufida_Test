import React from 'react';
import ActiveProjectDetails from '../pages/ActiveProjectDetails';
import ProjectDetails from '../pages/ProjectDetails';
import Projects from '../pages/Projects';
import Sharesphare from '../pages/Sharesphare';

/**
 * Public routes configuration for the application.
 * These routes are accessible without authentication.
 */
export const publicRoutes = [
  {
    path: "/projects",
    element: <Projects />,
    title: "Projects",
    description: "Explore our project portfolio"
  },
  {
    path: "/sharesphare",
    element: <Sharesphare />,
    title: "Sharesphare",
    description: "Collaborate and share resources"
  },
  {
    path: "/project/:projectId",
    element: <ProjectDetails />,
    title: "Project Details",
    description: "View detailed project information"
  },
  {
    path: "/active-project/:projectId",
    element: <ActiveProjectDetails />,
    title: "Active Project",
    description: "View active project details and progress"
  }
];

// Helper function to find a route by path
export const findRouteByPath = (path) => {
  return publicRoutes.find(route => {
    // Remove dynamic parameters for comparison
    const routePath = route.path.replace(/\/:[^/]+/g, '');
    const normalizedPath = path.split('/').slice(0, routePath.split('/').length).join('/');
    return routePath === normalizedPath;
  });
};

// Helper function to get route metadata
export const getRouteMetadata = (path) => {
  const route = findRouteByPath(path);
  return route ? { title: route.title, description: route.description } : null;
};