import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Heart, ArrowRight } from 'lucide-react';
import { neuButtonStyles } from '../utils/styleUtils';
import ImpactStats from '../components/ImpactStats';
import ProjectSelection from '../components/ProjectSelection';
import DonationFAQ from '../components/DonationFAQ';
import DonationHero from '../components/donate/DonationHero';
import DonationGoal from '../components/donate/DonationGoal';
import DonationForm from '../components/donate/DonationForm';

const Donate = () => {
  const [donationType, setDonationType] = useState('one-time');
  const [amount, setAmount] = useState('');
  const [selectedProject, setSelectedProject] = useState(null);
  const projectSelectionRef = useRef(null);

  const scrollToProjectSelection = () => {
    if (projectSelectionRef.current) {
      projectSelectionRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleDonation = () => {
    if (!amount) {
      alert('Please select or enter an amount before donating.');
      return;
    }
    
    const amountInCents = Math.round(parseFloat(amount) * 100);
    let comment = donationType === 'monthly' ? 'Monthly donation' : 'One-time donation';
    if (selectedProject) {
      comment += ` for ${selectedProject.name}`;
    }
    comment = comment.slice(0, 64);
    
    const encodedComment = encodeURIComponent(comment);
    const revolutLink = `https://revolut.me/davidxt0s?amount=${amountInCents}&currency=USD&comment=${encodedComment}`;
    
    window.open(revolutLink, '_blank');
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-deepGreen-800 to-deepGreen-900 py-12">
      <div className="container mx-auto px-4 max-w-4xl">
        <DonationHero />
        <ImpactStats />
        <DonationGoal />

        <div ref={projectSelectionRef}>
          <ProjectSelection 
            selectedProject={selectedProject}
            setSelectedProject={setSelectedProject}
          />
        </div>

        {selectedProject && (
          <DonationForm
            donationType={donationType}
            setDonationType={setDonationType}
            amount={amount}
            setAmount={setAmount}
            handleDonation={handleDonation}
          />
        )}

        <DonationFAQ />

        {!selectedProject && (
          <motion.div
            className="mt-16 text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <p className="text-2xl font-semibold mb-6 text-white">Ready to make a difference?</p>
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Button 
                size="lg" 
                onClick={scrollToProjectSelection}
                className={`${neuButtonStyles({ variant: "primary", size: "lg" })} text-xl py-8 px-12 flex items-center`}
              >
                <Heart className="mr-2 h-6 w-6" />
                Choose a Project to Support
                <ArrowRight className="ml-2 h-6 w-6" />
              </Button>
            </motion.div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default Donate;