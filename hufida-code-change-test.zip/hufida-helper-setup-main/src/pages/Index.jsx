import React from 'react';
import { motion } from "framer-motion";
import { useNavigate } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight } from 'lucide-react';
import HeroSection from '../components/landing/HeroSection';
import MissionSection from '../components/landing/MissionSection';
import FeaturesGrid from '../components/landing/FeaturesGrid';
import DetailedStats from '../components/landing/DetailedStats';
import Methodology from '../components/landing/Methodology';
import ImpactStats from '../components/landing/ImpactStats';
import CallToAction from '../components/landing/CallToAction';

const Index = () => {
  const navigate = useNavigate();
  console.log('Rendering Index page');

  const handleCreateProject = () => {
    console.log('Navigating to project creation page');
    navigate('/project-creation');
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1A1F2C] to-[#2C1F3D]">
      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <HeroSection />
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="my-12"
        >
          <Card className="bg-[#9b87f5]/10 backdrop-blur-sm border-[#9b87f5]/20">
            <CardContent className="p-6 flex flex-col items-center space-y-6">
              <h2 className="text-2xl font-bold text-[#D6BCFA] text-center">
                Start Your Impact Journey
              </h2>
              <p className="text-[#C8C8C9] text-center max-w-2xl">
                Join our community of changemakers and initiate projects that matter. 
                Create lasting impact through collaboration and innovation.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
                <Button 
                  variant="default"
                  onClick={handleCreateProject}
                  className="w-full sm:w-auto bg-[#9b87f5] hover:bg-[#7E69AB] text-white group"
                >
                  <span className="flex items-center gap-2">
                    Create New Project
                    <motion.span
                      className="inline-block"
                      animate={{ x: [0, 4, 0] }}
                      transition={{ repeat: Infinity, duration: 1.5 }}
                    >
                      <ArrowRight className="h-4 w-4" />
                    </motion.span>
                  </span>
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => navigate('/sharesphare')}
                  className="w-full sm:w-auto text-[#D6BCFA] border-[#9b87f5] hover:bg-[#9b87f5]/20 group"
                >
                  <span className="flex items-center gap-2">
                    Explore Sharesphare
                    <motion.span
                      className="inline-block"
                      animate={{ x: [0, 4, 0] }}
                      transition={{ repeat: Infinity, duration: 1.5 }}
                    >
                      <ArrowRight className="h-4 w-4" />
                    </motion.span>
                  </span>
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <MissionSection />
        <FeaturesGrid />
        <DetailedStats />
        <Methodology />
        <ImpactStats />
        <CallToAction />
      </main>
    </div>
  );
};

export default Index;