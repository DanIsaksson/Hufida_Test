import React, { useEffect, useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/components/AuthProvider';
import { supabase } from '@/lib/supabase';
import { useToast } from "@/components/ui/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion, AnimatePresence } from "framer-motion";
import ProfileForm from '@/components/profile/ProfileForm';
import ProjectManagement from '@/components/profile/ProjectManagement';
import ProfileSkeleton from '@/components/profile/ProfileSkeleton';
import { Card } from "@/components/ui/card";

const Profile = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchProfile = useMemo(() => async () => {
    if (!user) return;
    
    try {
      console.log('Fetching profile for user:', user.id);
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();

      if (error) throw error;
      console.log('Fetched profile:', data);
      setProfile(data);
    } catch (error) {
      console.error('Error fetching profile:', error);
      toast({
        title: "Error",
        description: "Failed to load profile data",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [user, toast]);

  useEffect(() => {
    if (!user) {
      console.log('No user found, redirecting to auth');
      navigate('/auth');
      return;
    }

    fetchProfile();
  }, [user, navigate, fetchProfile]);

  if (loading) {
    return (
      <div className="container max-w-6xl mx-auto py-8 px-4">
        <ProfileSkeleton />
      </div>
    );
  }

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key="profile-page"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        className="min-h-screen bg-background"
      >
        <div className="container max-w-6xl mx-auto px-4 py-8">
          <div className="space-y-8">
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center"
            >
              <h1 className="text-3xl font-bold text-foreground mb-2">
                {profile?.full_name || 'Complete Your Profile'}
              </h1>
              <p className="text-muted-foreground">
                {profile ? 'Manage your profile and projects' : 'Tell us about yourself'}
              </p>
            </motion.div>
            
            <Card className="overflow-hidden bg-card shadow-lg border border-border/40">
              <Tabs defaultValue="profile" className="w-full">
                <div className="px-6 pt-6">
                  <TabsList className="w-full grid grid-cols-2 gap-4 bg-primary/10 p-1 rounded-lg">
                    <TabsTrigger 
                      value="profile"
                      className="w-full data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                    >
                      Profile Details
                    </TabsTrigger>
                    <TabsTrigger 
                      value="projects"
                      className="w-full data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                    >
                      Project Management
                    </TabsTrigger>
                  </TabsList>
                </div>

                <div className="p-6">
                  <AnimatePresence mode="wait">
                    <TabsContent value="profile" className="mt-0 space-y-6">
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.2 }}
                      >
                        <ProfileForm initialData={profile} isLoading={loading} />
                      </motion.div>
                    </TabsContent>

                    <TabsContent value="projects" className="mt-0 space-y-6">
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.2 }}
                      >
                        <ProjectManagement />
                      </motion.div>
                    </TabsContent>
                  </AnimatePresence>
                </div>
              </Tabs>
            </Card>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};

export default Profile;