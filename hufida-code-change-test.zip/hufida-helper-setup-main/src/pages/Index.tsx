import { Button } from "@/components/ui/button";

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-50 p-4">
      <div className="max-w-3xl text-center space-y-6">
        <h1 className="text-4xl font-bold text-gray-900 sm:text-5xl">
          Welcome to Hufida 99
        </h1>
        <p className="text-xl text-gray-600">
          Your environment has been successfully initialized. Start building your amazing project!
        </p>
        <div className="flex justify-center gap-4">
          <Button
            variant="default"
            onClick={() => window.open("https://github.com/davlindh/hufida-99", "_blank")}
          >
            View on GitHub
          </Button>
          <Button
            variant="outline"
            onClick={() => window.open("https://docs.lovable.dev", "_blank")}
          >
            Read the Docs
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Index;