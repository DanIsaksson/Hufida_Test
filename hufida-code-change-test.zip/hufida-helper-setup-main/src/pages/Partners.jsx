import React, { useState, useEffect } from 'react';
import { motion } from "framer-motion";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Tabs, TabsContent } from "@/components/ui/tabs";
import { neuContainerStyles } from '../utils/styleUtils';
import PartnerHeader from '../components/partners/PartnerHeader';
import PartnerTabs from '../components/partners/PartnerTabs';
import PartnerSearch from '../components/partners/PartnerSearch';
import PartnerGrid from '../components/partners/PartnerGrid';
import ScrollButton from '../components/partners/ScrollButton';
import { supabase } from '../lib/supabase';
import { useToast } from "@/components/ui/use-toast";

const Partners = () => {
  const [selectedType, setSelectedType] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [partners, setPartners] = useState([]);
  const [types, setTypes] = useState(["all"]);
  const { toast } = useToast();

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        // Fetch partners
        const { data: partnersData, error: partnersError } = await supabase
          .from('partners')
          .select('*')
          .eq('is_active', true);

        if (partnersError) throw partnersError;

        // Fetch partner types
        const { data: typesData, error: typesError } = await supabase
          .from('partnership_types')
          .select('name');

        if (typesError) throw typesError;

        console.log('Fetched partners:', partnersData);
        console.log('Fetched partner types:', typesData);

        setPartners(partnersData || []);
        setTypes(['all', ...(typesData || []).map(type => type.name)]);
      } catch (error) {
        console.error('Error fetching data:', error);
        toast({
          title: "Error",
          description: "Failed to load partners. Please try again later.",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [toast]);

  const filteredPartners = partners
    .filter(p => selectedType === "all" || p.partner_type === selectedType)
    .filter(p => 
      searchTerm === "" || 
      p.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.location?.toLowerCase().includes(searchTerm.toLowerCase())
    );

  const handleTypeChange = (type) => {
    setSelectedType(type);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-deepGreen-800 to-deepGreen-600">
      <TooltipProvider>
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          className={`${neuContainerStyles({ padding: "large" })} max-w-7xl mx-auto backdrop-blur-sm bg-white/5`}
        >
          <PartnerHeader />
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="space-y-12"
          >
            <PartnerSearch 
              searchTerm={searchTerm}
              onSearchChange={setSearchTerm}
            />

            <Tabs defaultValue="all" className="w-full">
              <PartnerTabs 
                types={types} 
                selectedType={selectedType} 
                onTypeChange={handleTypeChange}
              />
              
              <TabsContent value={selectedType} className="mt-6">
                <PartnerGrid partners={filteredPartners} />
              </TabsContent>
            </Tabs>

            <ScrollButton />
          </motion.div>
        </motion.div>

        <div id="partner-profiles" className="mt-24">
          <PartnerGrid partners={partners} />
        </div>
      </TooltipProvider>
    </div>
  );
};

export default Partners;