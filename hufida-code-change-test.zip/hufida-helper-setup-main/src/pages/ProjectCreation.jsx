import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ArrowLeft, ArrowRight, FolderPlus } from 'lucide-react';
import { useAuth } from '../components/AuthProvider';
import { toast } from "sonner";
import ProjectForm from '../components/dashboard/projects/ProjectForm';

const ProjectCreation = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [showForm, setShowForm] = React.useState(false);
  
  console.log('ProjectCreation page rendering with user:', user);

  const handleCreateProject = () => {
    if (!user) {
      toast.error("Please sign in to create a project");
      navigate('/auth');
      return;
    }
    
    if (user.role !== 'partner') {
      toast("To create projects, please register as a partner", {
        action: {
          label: "Register as Partner",
          onClick: () => navigate('/auth?role=partner')
        },
      });
      return;
    }

    setShowForm(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-deepGreen-800 to-deepGreen-600 p-4 md:p-8">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="max-w-4xl mx-auto"
      >
        <Card className="backdrop-blur-sm bg-white/95 shadow-xl border-0">
          <CardHeader className="border-b border-gray-200/20">
            <div className="flex items-center gap-4">
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => showForm ? setShowForm(false) : navigate(-1)}
                className="text-deepGreen-700 hover:text-deepGreen-800 hover:bg-deepGreen-50"
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <CardTitle className="text-deepGreen-800 flex items-center gap-2 text-2xl">
                <FolderPlus className="h-6 w-6" />
                Create a New Project
              </CardTitle>
            </div>
          </CardHeader>
          <div className="max-h-[calc(100vh-12rem)] overflow-y-auto">
            <CardContent className="p-6">
              {showForm ? (
                <ProjectForm onSuccess={() => {
                  toast.success("Project created successfully!");
                  navigate('/dashboard/partner');
                }} />
              ) : (
                <div className="space-y-8 text-deepGreen-800">
                  <div className="space-y-6">
                    <h4 className="text-xl font-semibold">Project Creation Process</h4>
                    <ul className="list-disc list-inside space-y-3 text-lg">
                      <li>Share your project idea with the community</li>
                      <li>Get feedback and suggestions from potential collaborators</li>
                      <li>Refine your project based on community input</li>
                      <li>Form partnerships and build your team</li>
                      <li>Launch and track your project's impact</li>
                    </ul>
                  </div>

                  <div className="space-y-6">
                    <h4 className="text-xl font-semibold">What You'll Need</h4>
                    <ul className="list-disc list-inside text-lg space-y-3">
                      <li>Clear project title and description</li>
                      <li>Project goals and objectives</li>
                      <li>Target audience and impact metrics</li>
                      <li>Resource requirements and timeline</li>
                    </ul>
                  </div>

                  <div className="pt-6">
                    <Button 
                      onClick={handleCreateProject}
                      size="lg"
                      className="w-full bg-deepGreen-600 hover:bg-deepGreen-700 text-white group text-lg h-14"
                    >
                      <span className="flex items-center justify-center gap-2">
                        Proceed to Project Creation
                        <motion.span
                          className="inline-block"
                          animate={{ x: [0, 4, 0] }}
                          transition={{ repeat: Infinity, duration: 1.5 }}
                        >
                          <ArrowRight className="h-5 w-5" />
                        </motion.span>
                      </span>
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </div>
        </Card>
      </motion.div>
    </div>
  );
};

export default ProjectCreation;