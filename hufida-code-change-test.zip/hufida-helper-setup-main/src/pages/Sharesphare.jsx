import React from 'react';
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { neuCardStyles } from '../utils/styleUtils';
import SharesphareHeader from '../components/sharesphare/SharesphareHeader';
import SharesphareContent from '../components/sharesphare/SharesphareContent';
import { Share2, Users, BookOpen, BarChart3, MessageSquare, FolderPlus } from 'lucide-react';

const Sharesphare = () => {
  console.log('Sharesphare page rendering');

  return (
    <div className="min-h-screen bg-gradient-to-b from-deepGreen-800 to-deepGreen-600 p-4 md:p-8">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="max-w-7xl mx-auto"
      >
        <Card className={`${neuCardStyles({ elevation: "medium" })} backdrop-blur-sm bg-deepGreen-700/30`}>
          <div className="flex flex-col h-full">
            <SharesphareHeader />
            <ScrollArea className="flex-1 p-6">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ type: "spring", stiffness: 100 }}
              >
                <Tabs defaultValue="social" className="w-full">
                  <TabsList className="grid grid-cols-2 md:grid-cols-5 lg:grid-cols-5 gap-4 bg-transparent">
                    <TabsTrigger 
                      value="social"
                      className="data-[state=active]:bg-deepGreen-600 data-[state=active]:text-white"
                    >
                      <Users className="mr-2 h-4 w-4" />
                      Community
                    </TabsTrigger>
                    <TabsTrigger 
                      value="knowledge"
                      className="data-[state=active]:bg-deepGreen-600 data-[state=active]:text-white"
                    >
                      <BookOpen className="mr-2 h-4 w-4" />
                      Knowledge
                    </TabsTrigger>
                    <TabsTrigger 
                      value="projects"
                      className="data-[state=active]:bg-deepGreen-600 data-[state=active]:text-white"
                    >
                      <FolderPlus className="mr-2 h-4 w-4" />
                      Projects
                    </TabsTrigger>
                    <TabsTrigger 
                      value="impact"
                      className="data-[state=active]:bg-deepGreen-600 data-[state=active]:text-white"
                    >
                      <BarChart3 className="mr-2 h-4 w-4" />
                      Impact
                    </TabsTrigger>
                    <TabsTrigger 
                      value="messages"
                      className="data-[state=active]:bg-deepGreen-600 data-[state=active]:text-white"
                    >
                      <MessageSquare className="mr-2 h-4 w-4" />
                      Messages
                    </TabsTrigger>
                  </TabsList>
                  <SharesphareContent />
                </Tabs>
              </motion.div>
            </ScrollArea>
          </div>
        </Card>
      </motion.div>
    </div>
  );
};

export default Sharesphare;