import React from 'react';
import { Accordion } from "@/components/ui/accordion";
import ObjectivesSection from '../components/waste-management/ObjectivesSection';
import ImpactSection from '../components/waste-management/ImpactSection';
import ApproachSection from '../components/waste-management/ApproachSection';
import ChallengesSolutionsSection from '../components/waste-management/ChallengesSolutionsSection';
import FuturePlansSection from '../components/waste-management/FuturePlansSection';

const WasteManagementProject = () => {
  const project = {
    title: "Sustainable Waste Management",
    description: "Implementing an innovative waste management system in Bamenda that collects, processes, and converts waste into usable products, promoting sanitation and creating jobs.",
    objectives: [
      "Establish a comprehensive waste collection and segregation system",
      "Develop a waste-to-compost conversion facility",
      "Create employment opportunities in waste management and recycling",
      "Reduce environmental impact by minimizing landfill usage",
      "Promote public awareness about proper waste disposal and recycling"
    ],
    impact: "The Sustainable Waste Management project aims to process over 70% of Bamenda's household waste, create 200+ jobs, and significantly reduce landfill usage within the first two years of operation.",
    approach: "We're implementing a tiered pricing model for waste collection, with designated bins for organics, recyclables, and general waste. Our state-of-the-art facility will convert organic waste into high-quality compost, while recyclables will be processed and sold to manufacturers.",
    challenges: [
      "Public education on waste segregation",
      "Establishing efficient collection routes",
      "Securing partnerships with local businesses for recycled materials"
    ],
    solutions: [
      "Launch comprehensive public awareness campaigns through various media channels",
      "Implement route optimization software to enhance collection efficiency",
      "Develop strategic partnerships with local businesses and offer incentives for using recycled materials",
      "Create a mobile app for residents to access information and schedule pickups",
      "Introduce a community rewards program to encourage participation and proper waste segregation"
    ],
    future: "We envision expanding this model to neighboring communities and developing a range of eco-friendly products from recycled materials, further boosting local employment and sustainability efforts."
  };

  return (
    <div className="container mx-auto mt-8 px-4 sm:px-6 lg:px-8">
      <h1 className="text-3xl font-bold mb-6">{project.title}</h1>
      <p className="mb-8 text-lg">{project.description}</p>

      <Accordion type="single" collapsible className="w-full">
        <ObjectivesSection objectives={project.objectives} />
        <ImpactSection impact={project.impact} />
        <ApproachSection approach={project.approach} />
        <ChallengesSolutionsSection 
          challenges={project.challenges} 
          solutions={project.solutions} 
        />
        <FuturePlansSection future={project.future} />
      </Accordion>
    </div>
  );
};

export default WasteManagementProject;