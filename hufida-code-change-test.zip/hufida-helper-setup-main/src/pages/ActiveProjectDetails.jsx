import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs } from "@/components/ui/tabs";
import { supabase } from '@/lib/supabase';
import ProjectHeader from '../components/project-details/layout/ProjectHeader';
import ProjectContent from '../components/project-details/layout/ProjectContent';
import ProjectTabs from '../components/project-details/layout/ProjectTabs';
import ProjectTimeline from '../components/project-details/timeline/ProjectTimeline';
import ProjectTeam from '../components/project-details/team/ProjectTeam';
import ProjectSuggestionDialog from '../components/dialogs/ProjectSuggestionDialog';

const ActiveProjectDetails = () => {
  const { projectId } = useParams();
  const [activeTab, setActiveTab] = useState('overview');
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  console.log('Rendering ActiveProjectDetails for project:', projectId);

  // Main project query
  const { data: project, isLoading: isProjectLoading, error: projectError } = useQuery({
    queryKey: ['active-project', projectId],
    queryFn: async () => {
      console.log('Fetching project details for:', projectId);
      const { data, error } = await supabase
        .from('projects')
        .select(`
          *,
          partner:partners(
            id,
            name,
            logo_url,
            partner_type,
            website,
            description,
            location
          ),
          features:project_features(
            id,
            title,
            description,
            icon_name,
            details
          ),
          impacts:project_impacts(
            id,
            metric_name,
            current_value,
            target_value,
            unit,
            category
          ),
          objectives:project_objectives(
            id,
            title,
            description,
            status
          ),
          milestones:project_milestones(
            id,
            title,
            description,
            due_date,
            status,
            completion_percentage
          ),
          team_members:project_team_members(
            id,
            role,
            responsibilities,
            status,
            profile:profiles(
              id,
              full_name,
              avatar_url,
              contact_email,
              contact_phone
            )
          )
        `)
        .eq('id', projectId)
        .single();

      if (error) {
        console.error('Error fetching project:', error);
        throw error;
      }
      console.log('Fetched project data:', data);
      return data;
    }
  });

  // Related data query
  const { data: relatedData, isLoading: isRelatedLoading } = useQuery({
    queryKey: ['project-related-data', projectId],
    queryFn: async () => {
      console.log('Fetching related data for project:', projectId);
      
      // Fetch partner events if partner exists
      const partnerEventsPromise = project?.partner?.id 
        ? supabase
            .from('partner_events')
            .select('*')
            .eq('partner_id', project.partner.id)
            .order('event_date', { ascending: true })
            .limit(5)
        : Promise.resolve({ data: [] });

      // Fetch community engagements
      const communityEngagementsPromise = supabase
        .from('community_engagements')
        .select('*')
        .eq('project_id', projectId)
        .order('created_at', { ascending: false })
        .limit(5);

      // Fetch project updates
      const projectUpdatesPromise = supabase
        .from('project_updates')
        .select(`
          *,
          profiles:updated_by (
            full_name,
            avatar_url
          )
        `)
        .eq('project_id', projectId)
        .order('created_at', { ascending: false })
        .limit(5);

      const [partnerEvents, communityEngagements, projectUpdates] = await Promise.all([
        partnerEventsPromise,
        communityEngagementsPromise,
        projectUpdatesPromise
      ]);

      console.log('Fetched related data:', {
        partnerEvents: partnerEvents.data,
        communityEngagements: communityEngagements.data,
        projectUpdates: projectUpdates.data
      });

      return {
        partnerEvents: partnerEvents.data || [],
        communityEngagements: communityEngagements.data || [],
        projectUpdates: projectUpdates.data || []
      };
    },
    enabled: !!project?.id
  });

  if (projectError) {
    return (
      <div className="container mx-auto p-6 text-center text-red-500">
        <h1 className="text-2xl">Error loading project details</h1>
        <p>{projectError.message}</p>
      </div>
    );
  }

  const isLoading = isProjectLoading || isRelatedLoading;

  return (
    <div className="min-h-screen bg-gradient-to-b from-deepGreen-50 via-white to-deepGreen-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        <ProjectHeader setIsDialogOpen={setIsDialogOpen} />

        {isLoading ? (
          <div className="space-y-8">
            <Skeleton className="h-12 w-3/4 mx-auto" />
            <Skeleton className="h-6 w-1/2 mx-auto" />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Skeleton className="h-48" />
              <Skeleton className="h-48" />
            </div>
          </div>
        ) : project ? (
          <>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <ProjectTabs />
              <ProjectContent 
                activeTab={activeTab}
                project={project}
                relatedData={relatedData}
                projectId={projectId}
              />
            </Tabs>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
              <ProjectTimeline milestones={project.milestones} />
              <ProjectTeam teamMembers={project.team_members} />
            </div>
          </>
        ) : (
          <div className="text-center text-deepGreen-600">
            <h1 className="text-2xl">Project not found</h1>
          </div>
        )}
      </div>

      {project && (
        <ProjectSuggestionDialog
          project={project}
          projectId={projectId}
          projectTitle={project.title}
          isOpen={isDialogOpen}
          setIsOpen={setIsDialogOpen}
        />
      )}
    </div>
  );
};

export default ActiveProjectDetails;