import React, { useState } from 'react';
import { motion } from "framer-motion";
import { useProjects } from '../hooks/useProjects';
import ProjectSuggestionDialog from '../components/dialogs/ProjectSuggestionDialog';
import { TooltipProvider } from "@/components/ui/tooltip";
import { neuContainerStyles } from '../utils/styleUtils';
import ProjectsHeader from '../components/projects/ProjectsHeader';
import ProjectsSearch from '../components/projects/ProjectsSearch';
import ProjectsGrid from '../components/projects/ProjectsGrid';

const Projects = () => {
  const { searchTerm, setSearchTerm, categoryFilter, setCategoryFilter, filteredProjects } = useProjects();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedProject, setSelectedProject] = useState(null);

  const handleSuggestDirection = (project) => {
    console.log('Opening suggestion dialog for project:', project);
    setSelectedProject(project);
    setIsDialogOpen(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-deepGreen-800 to-deepGreen-600 py-12 px-4 sm:px-6 lg:px-8">
      <TooltipProvider>
        <div className={`${neuContainerStyles({ padding: "large" })} max-w-7xl mx-auto`}>
          <ProjectsHeader />
          <ProjectsSearch 
            searchTerm={searchTerm}
            setSearchTerm={setSearchTerm}
            categoryFilter={categoryFilter}
            setCategoryFilter={setCategoryFilter}
          />
          <ProjectsGrid 
            projects={filteredProjects}
            onSuggestDirection={handleSuggestDirection}
          />
          <ProjectSuggestionDialog
            isOpen={isDialogOpen}
            setIsOpen={setIsDialogOpen}
            projectId={selectedProject?.id}
            projectTitle={selectedProject?.title}
            project={selectedProject}
          />
        </div>
      </TooltipProvider>
    </div>
  );
};

export default Projects;