import React, { Suspense } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import Navigation from './components/Navigation';
import Footer from './components/Footer';
import { navItems } from './nav-items';
import Auth from './pages/Auth';
import { ProjectSkeleton } from './components/ui/skeleton-loader';
import { useAuthState } from './hooks/useAuthState';
import { useAuthSetup } from './hooks/useAuthSetup';
import { useProfileManagement } from './hooks/useProfileManagement';
import { createProtectedRoutes } from './routes/protectedRoutes';
import { publicRoutes } from './routes/publicRoutes';
import DashboardLayout from './components/dashboard/DashboardLayout';
import PartnerDashboard from './components/dashboard/PartnerDashboard';
import VolunteerDashboard from './components/dashboard/VolunteerDashboard';
import ProjectCreation from './pages/ProjectCreation';
import Index from './pages/Index';

const queryClient = new QueryClient();

function App() {
  console.log('App component rendering');
  const { user, loading, updateUser } = useAuthState();
  const { createProfileIfNeeded } = useProfileManagement();

  useAuthSetup(createProfileIfNeeded, updateUser);

  if (loading) {
    return <ProjectSkeleton />;
  }

  const hasRequiredRole = (requiredRole) => {
    return user?.role === requiredRole;
  };

  const protectedRoutes = createProtectedRoutes(hasRequiredRole);

  const getDashboardRoute = () => {
    if (!user) return '/auth';
    return user.role === 'partner' ? '/dashboard/partner' : '/dashboard/volunteer';
  };

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="flex flex-col min-h-screen">
          <Toaster />
          <Sonner />
          <Navigation />
          <main className="flex-grow">
            <Suspense fallback={<ProjectSkeleton />}>
              <Routes>
                {/* Landing page route */}
                <Route path="/" element={<Index />} />

                {/* Auth route */}
                <Route
                  path="/auth"
                  element={!user ? <Auth /> : <Navigate to={getDashboardRoute()} replace />}
                />

                {/* Project Creation route */}
                <Route path="/project-creation" element={<ProjectCreation />} />

                {/* Public routes */}
                {publicRoutes.map((route) => (
                  <Route key={route.path} path={route.path} element={route.element} />
                ))}

                {/* Nav item routes */}
                {navItems.map((item) => (
                  <Route key={item.to} path={item.to} element={item.page} />
                ))}

                {/* Dashboard routes */}
                {user && (
                  <Route path="/dashboard" element={<DashboardLayout />}>
                    <Route
                      path="partner"
                      element={
                        hasRequiredRole('partner') ? (
                          <PartnerDashboard />
                        ) : (
                          <Navigate to={getDashboardRoute()} replace />
                        )
                      }
                    />
                    <Route
                      path="volunteer"
                      element={
                        hasRequiredRole('volunteer') ? (
                          <VolunteerDashboard />
                        ) : (
                          <Navigate to={getDashboardRoute()} replace />
                        )
                      }
                    />
                  </Route>
                )}

                {/* Protected routes */}
                {user ? (
                  protectedRoutes.map((route) => (
                    <Route
                      key={route.path}
                      path={route.path}
                      element={
                        route.requiresAuth ? (
                          hasRequiredRole(route.role) ? (
                            route.element
                          ) : (
                            <Navigate to={getDashboardRoute()} replace />
                          )
                        ) : (
                          route.element
                        )
                      }
                    />
                  ))
                ) : (
                  <Route path="*" element={<Navigate to="/auth" replace />} />
                )}

                {/* Catch all route */}
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </Suspense>
          </main>
          <Footer />
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;