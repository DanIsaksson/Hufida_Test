export type CommunityEngagement = {
  id: string;
  project_id: string | null;
  title: string;
  description: string;
  engagement_type: string;
  status: string | null;
  start_date: string | null;
  end_date: string | null;
  location: string | null;
  participants_count: number | null;
  created_at: string;
  updated_at: string;
};

export type CommunityEngagementInsert = Omit<CommunityEngagement, 'id' | 'created_at' | 'updated_at'>;
export type CommunityEngagementUpdate = Partial<CommunityEngagementInsert>;