export type Profile = {
  id: string;
  username: string | null;
  full_name: string | null;
  avatar_url: string | null;
  bio: string | null;
  location: string | null;
  contact_email: string | null;
  contact_phone: string | null;
  website: string | null;
  social_media: Record<string, any> | null;
  role: string | null;
  is_approved: boolean | null;
  is_featured: boolean | null;
  skills: string[] | null;
  availability: string | null;
  created_at: string;
  updated_at: string;
  contributions: Record<string, any> | null;
  engagements: Record<string, any> | null;
};

export type ProfileInsert = Omit<Profile, 'created_at' | 'updated_at'>;
export type ProfileUpdate = Partial<ProfileInsert>;