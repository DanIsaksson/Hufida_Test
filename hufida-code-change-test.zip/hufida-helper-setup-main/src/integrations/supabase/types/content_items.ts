export type ContentItem = {
  id: string;
  creator_id: string | null;
  title: string;
  content: string;
  content_type: string;
  status: string | null;
  metadata: Record<string, any> | null;
  created_at: string;
  updated_at: string;
};

export type ContentItemInsert = Omit<ContentItem, 'id' | 'created_at' | 'updated_at'>;
export type ContentItemUpdate = Partial<ContentItemInsert>;