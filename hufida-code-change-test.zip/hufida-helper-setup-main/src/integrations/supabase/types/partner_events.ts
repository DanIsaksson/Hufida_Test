export type PartnerEvent = {
  id: string;
  partner_id: string | null;
  title: string;
  description: string | null;
  event_date: string;
  location: string | null;
  created_at: string;
  updated_at: string;
};

export type PartnerEventInsert = Omit<PartnerEvent, 'id' | 'created_at' | 'updated_at'>;
export type PartnerEventUpdate = Partial<PartnerEventInsert>;