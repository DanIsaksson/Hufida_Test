export type ProjectFile = {
  id: string;
  project_id: string | null;
  file_name: string;
  file_path: string;
  file_type: string | null;
  file_size: number | null;
  uploaded_by: string | null;
  created_at: string;
  updated_at: string;
};

export type ProjectFileInsert = Omit<ProjectFile, 'id' | 'created_at' | 'updated_at'>;
export type ProjectFileUpdate = Partial<ProjectFileInsert>;