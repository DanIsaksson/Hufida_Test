export type ProjectFeature = {
  id: string;
  project_id: string | null;
  title: string;
  description: string;
  icon_name: string | null;
  details: Record<string, any>[] | null;
  created_at: string;
  updated_at: string;
};

export type ProjectFeatureInsert = Omit<ProjectFeature, 'id' | 'created_at' | 'updated_at'>;
export type ProjectFeatureUpdate = Partial<ProjectFeatureInsert>;