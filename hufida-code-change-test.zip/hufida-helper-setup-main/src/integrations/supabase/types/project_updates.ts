export type ProjectUpdate = {
  id: string;
  project_id: string | null;
  updated_by: string | null;
  update_type: string;
  description: string;
  metadata: Record<string, any> | null;
  created_at: string;
};

export type ProjectUpdateInsert = Omit<ProjectUpdate, 'id' | 'created_at'>;
export type ProjectUpdateUpdate = Partial<ProjectUpdateInsert>;