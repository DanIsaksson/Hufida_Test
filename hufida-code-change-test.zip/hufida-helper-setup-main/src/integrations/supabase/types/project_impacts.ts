export type ProjectImpact = {
  id: string;
  project_id: string | null;
  metric_name: string;
  current_value: number | null;
  target_value: number | null;
  unit: string | null;
  category: string | null;
  created_at: string;
  updated_at: string;
};

export type ProjectImpactInsert = Omit<ProjectImpact, 'id' | 'created_at' | 'updated_at'>;
export type ProjectImpactUpdate = Partial<ProjectImpactInsert>;