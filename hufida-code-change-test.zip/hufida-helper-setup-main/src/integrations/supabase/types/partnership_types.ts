export type PartnershipType = {
  id: string;
  name: string;
  description: string | null;
  created_at: string;
};

export type PartnershipTypeInsert = Omit<PartnershipType, 'id' | 'created_at'>;
export type PartnershipTypeUpdate = Partial<PartnershipTypeInsert>;