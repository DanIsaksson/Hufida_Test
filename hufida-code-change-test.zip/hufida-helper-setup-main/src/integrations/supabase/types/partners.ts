export type Partner = {
  id: string;
  name: string;
  logo_url: string | null;
  partner_type: string;
  website: string | null;
  description: string | null;
  location: string | null;
  created_at: string;
  updated_at: string;
  is_active: boolean;
  featured: boolean;
  contact_email: string | null;
  contact_phone: string | null;
  social_media: Record<string, any> | null;
  created_by: string | null;
  project_status: string | null;
  start_date: string | null;
  end_date: string | null;
  category: string | null;
  target_audience: string[] | null;
  budget: number | null;
  funding_status: string | null;
  project_lead: string | null;
  team_members: string[] | null;
  tags: string[] | null;
  approach: string | null;
  innovation: string | null;
  vision: string | null;
  impact: string | null;
  features: Array<{
    title: string;
    description: string;
  }> | null;
};

export type PartnerInsert = Omit<Partner, 'id' | 'created_at' | 'updated_at'>;
export type PartnerUpdate = Partial<PartnerInsert>;