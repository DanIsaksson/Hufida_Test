export type ProjectObjective = {
  id: string;
  project_id: string | null;
  title: string;
  description: string;
  order_index: number;
  status: string | null;
  created_at: string;
  updated_at: string;
};

export type ProjectObjectiveInsert = Omit<ProjectObjective, 'id' | 'created_at' | 'updated_at'>;
export type ProjectObjectiveUpdate = Partial<ProjectObjectiveInsert>;