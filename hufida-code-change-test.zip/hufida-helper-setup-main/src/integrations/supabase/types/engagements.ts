export type Engagement = {
  id: string;
  creator_id: string | null;
  title: string;
  description: string;
  engagement_type: string;
  status: string | null;
  start_date: string | null;
  end_date: string | null;
  metadata: Record<string, any> | null;
  created_at: string;
  updated_at: string;
};

export type EngagementInsert = Omit<Engagement, 'id' | 'created_at' | 'updated_at'>;
export type EngagementUpdate = Partial<EngagementInsert>;