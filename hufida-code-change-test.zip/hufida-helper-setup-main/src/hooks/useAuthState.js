import { useState, useCallback, useEffect, useRef } from 'react';
import { supabase } from '../lib/supabase';

const FETCH_COOLDOWN = 2000; // 2 seconds between fetches
const FETCH_TIMEOUT = 10000; // 10 second timeout for fetches

export const useAuthState = () => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const lastFetchTimestamp = useRef(0);
  const fetchTimeoutRef = useRef(null);

  const canFetch = () => {
    const now = Date.now();
    return now - lastFetchTimestamp.current >= FETCH_COOLDOWN;
  };

  const fetchWithTimeout = async (promise) => {
    const timeoutPromise = new Promise((_, reject) => {
      fetchTimeoutRef.current = setTimeout(() => {
        reject(new Error('Fetch timeout'));
      }, FETCH_TIMEOUT);
    });

    try {
      const result = await Promise.race([promise, timeoutPromise]);
      clearTimeout(fetchTimeoutRef.current);
      return result;
    } catch (error) {
      clearTimeout(fetchTimeoutRef.current);
      throw error;
    }
  };

  // Initialize auth state
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        console.log('Initializing auth state...');
        
        if (!canFetch()) {
          console.log('Skipping fetch due to cooldown');
          return;
        }

        lastFetchTimestamp.current = Date.now();
        const { data: { session } } = await fetchWithTimeout(supabase.auth.getSession());
        
        if (session?.user) {
          console.log('Found existing session:', session.user.email);
          const { data: profile, error } = await fetchWithTimeout(
            supabase
              .from('profiles')
              .select('*')
              .eq('id', session.user.id)
              .maybeSingle()
          );

          if (error) {
            console.error('Error fetching profile:', error);
            throw error;
          }

          console.log('Setting user with profile:', profile);
          setUser({
            ...session.user,
            role: profile?.role || 'volunteer'
          });
        } else {
          console.log('No active session found');
          setUser(null);
        }
      } catch (error) {
        console.error('Error initializing auth:', error);
        setUser(null);
      } finally {
        console.log('Auth initialization complete');
        setLoading(false);
      }
    };

    initializeAuth();

    // Subscribe to auth changes with rate limiting
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      console.log('Auth state changed:', event, session?.user?.email);
      
      if (!canFetch()) {
        console.log('Skipping auth state update due to cooldown');
        return;
      }

      lastFetchTimestamp.current = Date.now();
      if (session?.user) {
        try {
          const { data: profile, error } = await fetchWithTimeout(
            supabase
              .from('profiles')
              .select('*')
              .eq('id', session.user.id)
              .maybeSingle()
          );

          if (error) {
            console.error('Error fetching profile on auth state change:', error);
            return;
          }

          setUser({
            ...session.user,
            role: profile?.role || 'volunteer'
          });
        } catch (error) {
          console.error('Error updating user state:', error);
        }
      } else {
        setUser(null);
      }
    });

    return () => {
      console.log('Cleaning up auth subscriptions');
      subscription?.unsubscribe();
      if (fetchTimeoutRef.current) {
        clearTimeout(fetchTimeoutRef.current);
      }
    };
  }, []);

  const updateUser = useCallback((newUser, profile) => {
    console.log('Updating user state:', { newUser, profile });
    if (newUser && profile) {
      setUser({
        ...newUser,
        role: profile.role || 'volunteer'
      });
    } else {
      setUser(null);
    }
  }, []);

  return {
    user,
    loading,
    updateUser
  };
};

// Add the useAuth hook that returns the user state
export const useAuth = () => {
  const { user, loading, updateUser } = useAuthState();
  return { user, loading, updateUser };
};