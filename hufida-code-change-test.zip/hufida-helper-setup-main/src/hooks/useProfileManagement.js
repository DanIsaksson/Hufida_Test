import { useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useToast } from "@/components/ui/use-toast";

export const useProfileManagement = () => {
  const navigate = useNavigate();
  const { toast } = useToast();

  const createProfileIfNeeded = useCallback(async (userId, email) => {
    if (!userId) return null;
    
    try {
      console.log('Checking if profile exists for user:', userId);
      const { data: existingProfile, error: fetchError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (fetchError) {
        console.error('Error checking existing profile:', fetchError);
        return null;
      }

      if (existingProfile) {
        console.log('Found existing profile:', existingProfile);
        if (!existingProfile.full_name || !existingProfile.role) {
          console.log('Profile incomplete, redirecting to profile page');
          navigate('/profile');
        }
        return existingProfile;
      }

      console.log('No profile found, creating new profile for user:', userId);
      const { data: newProfile, error: insertError } = await supabase
        .from('profiles')
        .insert([{
          id: userId,
          contact_email: email,
          role: 'volunteer',
          is_approved: false,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }])
        .select()
        .single();

      if (insertError) {
        console.error('Failed to create profile:', insertError);
        toast({
          title: "Error",
          description: "Failed to create user profile",
          variant: "destructive",
        });
        return null;
      }

      console.log('Successfully created new profile:', newProfile);
      navigate('/profile');
      return newProfile;
    } catch (error) {
      console.error('Unexpected error in createProfileIfNeeded:', error);
      return null;
    }
  }, [navigate, toast]);

  return {
    createProfileIfNeeded
  };
};