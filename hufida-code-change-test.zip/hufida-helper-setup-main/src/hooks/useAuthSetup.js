import { useEffect } from 'react';
import { supabase } from '../lib/supabase';

export const useAuthSetup = (createProfileIfNeeded, updateUser) => {
  useEffect(() => {
    console.log('Setting up auth state listener');
    let lastCheck = 0;
    const COOLDOWN = 1000; // Reduce cooldown to 1 second
    
    const handleAuthChange = async (session) => {
      const now = Date.now();
      if (now - lastCheck < COOLDOWN) {
        console.log('Skipping auth change handler - too soon');
        return;
      }
      lastCheck = now;
      
      try {
        if (session?.user) {
          console.log('Processing auth change for user:', session.user.email);
          const profile = await createProfileIfNeeded(session.user.id, session.user.email);
          updateUser(session.user, profile);
        } else {
          console.log('No active session, clearing user state');
          updateUser(null, null);
        }
      } catch (error) {
        console.error('Error in auth change handler:', error);
        updateUser(null, null);
      }
    };

    // Initial session check
    supabase.auth.getSession().then(({ data: { session } }) => {
      console.log('Initial session check:', session?.user?.email || 'No session');
      handleAuthChange(session);
    });

    // Subscribe to auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      console.log('Auth state changed:', event, session?.user?.email);
      handleAuthChange(session);
    });

    return () => {
      console.log('Cleaning up auth listener');
      subscription.unsubscribe();
    };
  }, [createProfileIfNeeded, updateUser]);
};