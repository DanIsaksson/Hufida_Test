import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';

export const useActiveProject = (profileId) => {
  return useQuery({
    queryKey: ['active-project', profileId],
    queryFn: async () => {
      console.log('Fetching active project for profile:', profileId);
      try {
        const { data, error } = await supabase
          .from('projects')
          .select('*')
          .eq('project_lead', profileId)
          .eq('is_active', true)
          .maybeSingle();
        
        if (error) {
          console.error('Error fetching active project:', error);
          throw error;
        }
        
        if (!data) {
          console.log('No active project found, creating default project');
          const { data: newProject, error: createError } = await supabase
            .from('projects')
            .insert({
              title: 'New Project',
              description: 'New project description',
              project_lead: profileId,
              is_active: true,
              project_status: 'draft'
            })
            .select()
            .single();

          if (createError) {
            console.error('Error creating default project:', createError);
            throw createError;
          }

          console.log('Created default project:', newProject);
          return newProject;
        }
        
        console.log('Fetched active project:', data);
        return data;
      } catch (error) {
        console.error('Failed to fetch active project:', error);
        throw error;
      }
    },
    enabled: !!profileId,
  });
};