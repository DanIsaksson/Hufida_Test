import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';

export const usePartnerProfile = () => {
  return useQuery({
    queryKey: ['profile'],
    queryFn: async () => {
      console.log('Fetching profile data for partner dashboard');
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .maybeSingle();
      
      if (error) {
        console.error('Error fetching profile:', error);
        throw error;
      }
      console.log('Fetched profile:', data);
      return data;
    },
  });
};